"""hawkes.py -- a synthetic market built on a Hawkes process (replaces downloaded historical data).

Real order flow is clustered: one trade makes the next trade more likely, and a buy tends to draw
further buys. A Hawkes process models exactly that. The generated "history" has:

  1. Self- and cross-exciting market buys and sells (bivariate Hawkes, exponential memory)
  2. An intraday U-shape: more activity near the open and the close
  3. Heavy-tailed order sizes (log-normal, not exponential)
  4. Price impact: every market order moves the mid price (so fills are followed by adverse moves)
  5. Volatility clustering: busy and quiet days persist, activity follows the U-shape, and bursts of
     orders move prices more
  6. Overnight gaps between days, so daily open/high/low/close bars are realistic (for Yang-Zhang)

The tape is generated ONCE and is independent of the market maker, so every strategy is tested
against exactly the same history.
"""
from dataclasses import dataclass

import numpy as np


@dataclass
class HawkesMarketParams:
    rate: float = 140.0            # average market orders per side per day (at normal activity)
    branching: float = 0.75        # average number of further orders each order triggers (must be < 1)
    self_share: float = 0.85       # share of that excitation that stays on the same side
    decay: float = 50.0            # how fast excitation fades, per day (about 6 minutes of a 6.5-hour day)
    u_shape: float = 0.8           # strength of the intraday U-shape (0 = flat)
    size_mean: float = 100.0       # average order size in shares
    size_sigma: float = 1.0        # log-normal shape; larger = heavier tail
    impact: float = 0.10           # price move per order, in price units, times sqrt(size / mean size)
    permanent_share: float = 0.5   # share of that move that lasts (information); the rest fades (liquidity)
    impact_memory: float = 20.0    # how fast the temporary part fades, per day (about 20 minutes)
    diffusion: float = 1.0         # volatility not caused by order flow, price units per sqrt(day)
    overnight: float = 0.6         # standard deviation of the overnight gap, price units
    activity_persistence: float = 0.85   # how strongly busy days follow busy days
    activity_vol: float = 0.40     # day-to-day swings in activity (log scale)
    s0: float = 100.0              # starting price
    n_steps: int = 200             # strategy decision points per day

    def __post_init__(self):
        if not 0 <= self.branching < 1:
            raise ValueError("branching must be in [0, 1) or the process explodes")
        if not 0 <= self.self_share <= 1:
            raise ValueError("self_share must be between 0 and 1")

    @property
    def alpha_self(self):
        return self.branching * self.decay * self.self_share

    @property
    def alpha_cross(self):
        return self.branching * self.decay * (1 - self.self_share)


@dataclass
class DayTape:
    mid: np.ndarray        # mid price at each of n_steps + 1 decision points
    ev_ptr: np.ndarray     # events of step i are ev_side[ev_ptr[i]:ev_ptr[i+1]]
    ev_side: np.ndarray    # +1 market buy, -1 market sell
    ev_size: np.ndarray    # shares
    activity: float

    def events(self, step):
        a, b = self.ev_ptr[step], self.ev_ptr[step + 1]
        return self.ev_side[a:b], self.ev_size[a:b]


@dataclass
class MarketHistory:
    params: HawkesMarketParams
    days: list

    @property
    def n_days(self):
        return len(self.days)

    @property
    def ohlc(self):
        """Daily open, high, low, close of the mid price, as arrays of length n_days."""
        return {"open": np.array([d.mid[0] for d in self.days]), "high": np.array([d.mid.max() for d in self.days]),
                "low": np.array([d.mid.min() for d in self.days]), "close": np.array([d.mid[-1] for d in self.days])}


# ----------------------------------------------------------------------------- generation
def _seasonality(u_shape, grid=1001, tau=0.10):
    """Activity multiplier over the day, average exactly 1: high near the open and close."""
    t = np.linspace(0, 1, grid)
    g = np.exp(-t / tau) + np.exp(-(1 - t) / tau)
    return (1 - u_shape) + u_shape * g / g.mean()


def _simulate_day_events(rng, p, activity, season):
    """Ogata thinning for a bivariate Hawkes process with exponential kernels on [0, 1)."""
    mu0 = p.rate * (1 - p.branching) * activity            # baseline so that the MEAN rate per side = rate * activity
    mu_max = mu0 * season.max()
    # The day opens with excitation left over from the previous close, about half what the opening peak
    # implies (calibrated so the average arrival rate matches `rate`; near-critical Hawkes processes lag).
    eb = es = p.rate * p.branching * activity * (1 + 0.5 * (season[0] - 1))
    t, times, sides = 0.0, [], []
    while True:
        bound = 2 * mu_max + eb + es                        # intensities only fall between events, so this bounds them
        wait = rng.exponential(1.0 / bound)
        t += wait
        if t >= 1.0:
            break
        decay = np.exp(-p.decay * wait)
        eb, es = eb * decay, es * decay
        mu_t = mu0 * season[int(t * (len(season) - 1))]
        rb, rs = mu_t + eb, mu_t + es
        if rng.random() * bound > rb + rs:
            continue                                        # thinned away: no event
        buy = rng.random() < rb / (rb + rs)
        if buy:
            eb, es = eb + p.alpha_self, es + p.alpha_cross
        else:
            es, eb = es + p.alpha_self, eb + p.alpha_cross
        times.append(t)
        sides.append(1 if buy else -1)
    return np.array(times), np.array(sides, dtype=int)


def generate_market(n_days, seed=0, params=None):
    """Generate `n_days` of synthetic market history."""
    p = params or HawkesMarketParams()
    rng = np.random.default_rng(seed)
    season = _seasonality(p.u_shape)
    dt = 1.0 / p.n_steps
    size_mu = np.log(p.size_mean) - p.size_sigma ** 2 / 2   # log-normal with the requested mean
    x = 0.0                                                 # log activity, an AR(1) process across days
    close, days = p.s0, []
    for d in range(n_days):
        x = p.activity_persistence * x + p.activity_vol * np.sqrt(1 - p.activity_persistence ** 2) * rng.standard_normal()
        activity = float(np.exp(x - 0.5 * p.activity_vol ** 2))
        times, sides = _simulate_day_events(rng, p, activity, season)
        sizes = np.maximum(1, np.round(np.exp(size_mu + p.size_sigma * rng.standard_normal(len(times))))).astype(int)
        step = np.minimum((times * p.n_steps).astype(int), p.n_steps - 1)
        flow = np.bincount(step, weights=sides * p.impact * np.sqrt(sizes / p.size_mean), minlength=p.n_steps)
        noise = p.diffusion * np.sqrt(activity * dt) * rng.standard_normal(p.n_steps)
        opening = close + (p.overnight * np.sqrt(activity) * rng.standard_normal() if d else 0.0)
        lasting = np.concatenate([[0.0], np.cumsum(p.permanent_share * flow + noise)])    # efficient price
        fading = np.zeros(p.n_steps + 1)                                                  # temporary impact
        keep = np.exp(-p.impact_memory * dt)
        for i in range(p.n_steps):
            fading[i + 1] = keep * fading[i] + (1 - p.permanent_share) * flow[i]
        mid = np.maximum(opening + lasting + fading, 1.0)
        counts = np.bincount(step, minlength=p.n_steps)
        days.append(DayTape(mid=mid, ev_ptr=np.concatenate([[0], np.cumsum(counts)]), ev_side=sides, ev_size=sizes,
                            activity=activity))
        close = mid[-1]
    return MarketHistory(p, days)


# ----------------------------------------------------------------------------- diagnostics
def fano_factor(history):
    """Clustering of order arrivals, with the intraday U-shape and the day's busyness removed.

    For each step, compare the actual number of orders with the number expected from the average
    intraday profile scaled to that day's total. The ratio  sum (actual - expected)^2 / sum expected
    equals 1 for Poisson (random, unclustered) arrivals and exceeds 1 when orders arrive in bursts."""
    counts = np.array([np.diff(d.ev_ptr) for d in history.days], dtype=float)       # days x steps
    totals = counts.sum(axis=1, keepdims=True)
    profile = (counts / totals).mean(axis=0, keepdims=True)
    expected = totals * profile
    return float(((counts - expected) ** 2).sum() / expected.sum())


def diagnostics(history):
    """Headline facts about the generated market, for display and for tests."""
    p, days = history.params, history.days
    ohlc = history.ohlc
    daily_ret = np.diff(np.log(ohlc["close"]))
    step_ret = np.concatenate([np.diff(np.log(d.mid)) for d in days])
    abs_ret = np.abs(step_ret)
    signs = np.concatenate([d.ev_side for d in days]).astype(float)
    ac = lambda x, lag: float(np.corrcoef(x[:-lag], x[lag:])[0, 1])
    intraday_vol = np.array([np.std(np.diff(d.mid)) * np.sqrt(p.n_steps) for d in days])
    return {
        "orders_per_day": float(np.mean([len(d.ev_side) for d in days])),
        "fano_factor": fano_factor(history),
        "sign_autocorrelation": ac(signs, 1),
        "abs_return_autocorrelation": ac(abs_ret, 1),
        "daily_vol_mean": float(np.mean(intraday_vol)),
        "daily_vol_dispersion": float(np.std(intraday_vol) / np.mean(intraday_vol)),
        "close_to_close_vol": float(np.std(daily_ret, ddof=1) * np.mean(ohlc["close"])),
        "mean_order_size": float(np.mean(np.concatenate([d.ev_size for d in days]))),
    }
