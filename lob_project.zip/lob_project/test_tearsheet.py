"""test_tearsheet.py -- tests for the tear sheet (run:  python test_tearsheet.py)"""
import numpy as np
from backtest import BacktestConfig, run_backtest
from hawkes import generate_market
from tearsheet import (drawdown_series, sharpe_ratio, sharpe_standard_error, sortino_ratio, tear_sheet, tear_sheets)

ANNUAL = np.sqrt(252)


def test_sharpe_by_hand():
    x = np.array([2, 1, 3, 0, 2, 4.0])
    assert abs(sharpe_ratio(x) - x.mean() / x.std(ddof=1) * ANNUAL) < 1e-12
    assert abs(sharpe_ratio(np.array([1.0, -1, 1, -1]))) < 1e-12           # zero mean, zero Sharpe
    assert np.isnan(sharpe_ratio(np.array([1.0, 1, 1])))                    # no variation: undefined


def test_sharpe_standard_error_shrinks_with_more_days():
    rng = np.random.default_rng(0)
    assert sharpe_standard_error(rng.normal(1, 2, 400)) < sharpe_standard_error(rng.normal(1, 2, 100))
    x = rng.normal(1, 2, 100)
    sr = x.mean() / x.std(ddof=1)
    assert abs(sharpe_standard_error(x) - np.sqrt((1 + 0.5 * sr ** 2) / 100) * ANNUAL) < 1e-12


def test_sortino_by_hand_and_no_loss_case():
    x = np.array([3, -1, 2, -2, 4.0])                  # downside deviation = sqrt((1 + 4) / 5) = 1, mean = 6 / 5
    assert abs(sortino_ratio(x) - 1.2 * ANNUAL) < 1e-12
    assert sortino_ratio(np.array([1.0, 2, 3])) == float("inf")
    assert sortino_ratio(x, target=2.0) < sortino_ratio(x)                   # a higher bar lowers it


def test_half_mean_target_makes_sortino_finite_when_there_are_no_losing_days():
    fake = _fake()
    fake["pnl"] = np.abs(np.random.default_rng(1).normal(5, 10, 40)) + 0.1   # no losing days, but a wide spread of good days
    assert tear_sheet(fake)["summary"]["sortino"] == float("inf")
    ts = tear_sheet(fake, sortino_target="half_mean")["summary"]
    assert np.isfinite(ts["sortino"]) and abs(ts["sortino_target"] - 0.5 * fake["pnl"].mean()) < 1e-12
    assert ts["sortino_zero_target"] == float("inf")


def test_sortino_ignores_upside_volatility():
    base = np.array([3, -1, 2, -2, 4.0])
    wilder_upside = np.array([30, -1, 2, -2, 40.0])
    assert abs(sortino_ratio(wilder_upside) / sortino_ratio(base) - wilder_upside.mean() / base.mean()) < 1e-12
    assert sharpe_ratio(wilder_upside) < sharpe_ratio(base) * 2            # upside swings are penalised by Sharpe only


def test_drawdown_by_hand():
    x = np.array([1, 2, -4, 1, -2, 5.0])               # cumulative 1, 3, -1, 0, -2, 3 ; peaks 1, 3, 3, 3, 3, 3
    assert np.allclose(drawdown_series(x), [0, 0, 4, 3, 5, 0])
    assert drawdown_series(np.array([-1.0, -2])).max() == 3                  # the starting zero counts as a peak


def _fake(n=40, steps=10, seed=0):
    rng = np.random.default_rng(seed)
    edge, markout, carry = rng.normal(40, 3, n), rng.normal(-8, 3, n), rng.normal(0, 6, n)
    inv = markout + carry
    q = np.cumsum(rng.integers(-1, 2, (n, steps)), axis=1)
    return dict(pnl=edge + inv, edge=edge, inv_pnl=inv, markout=markout, fills=np.full(n, 60), q_path=q, gap=np.ones(n))


def test_decomposition_adds_up_and_variance_shares_sum_to_one():
    ts = tear_sheet(_fake())
    d = ts["decomposition"]
    parts = d["spread"]["total"] + d["adverse_selection"]["total"] + d["inventory_carry"]["total"]
    assert abs(parts - d["total"]["total"]) < 1e-9
    shares = sum(d[k]["variance_share"] for k in ("spread", "adverse_selection", "inventory_carry"))
    assert abs(shares - 1) < 1e-9


def test_inventory_metrics_by_hand():
    fake = _fake(n=2, steps=3)
    fake["q_path"] = np.array([[0, 1, 2], [0, -1, -2]])
    inv = tear_sheet(fake, q_limit=2)["inventory"]
    assert abs(inv["mean_abs"] - 1.0) < 1e-12
    assert abs(inv["rms"] - np.sqrt(10 / 6)) < 1e-12
    assert inv["peak_abs"] == 2 and abs(inv["pct_flat"] - 2 / 6) < 1e-12 and abs(inv["pct_at_limit"] - 2 / 6) < 1e-12
    assert inv["end_of_day_mean_abs"] == 2


def test_summary_fields():
    fake = _fake()
    s = tear_sheet(fake)["summary"]
    pnl = fake["pnl"]
    assert s["days"] == 40 and abs(s["total_pnl"] - pnl.sum()) < 1e-9
    assert s["worst_day"] == pnl.min() and s["best_day"] == pnl.max()
    assert abs(s["win_rate"] - (pnl > 0).mean()) < 1e-12
    assert s["cvar_5"] <= s["worst_day"] + 1e-9 + (np.sort(pnl)[1] - np.sort(pnl)[0])   # mean of the worst 2 days


def test_end_to_end_on_a_real_backtest():
    result = run_backtest(generate_market(70, seed=3), BacktestConfig(train_days=30))
    sheets = tear_sheets(result)
    assert set(sheets) == {"sym", "as", "exact", "vol_aware"}
    for name, ts in sheets.items():
        assert np.isfinite(ts["summary"]["sharpe"]) and not np.isnan(ts["summary"]["sortino"])   # Sortino is +inf with no losing day
        d = ts["decomposition"]
        assert abs(d["spread"]["total"] + d["adverse_selection"]["total"] + d["inventory_carry"]["total"]
                   - d["total"]["total"]) < 1e-6
        assert d["spread"]["total"] > 0                                             # spread capture earns money
        assert d["adverse_selection"]["total"] < 0                                  # fills are followed by adverse moves
    assert sheets["sym"]["inventory"]["mean_abs"] > sheets["as"]["inventory"]["mean_abs"]   # inventory skew works


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print("PASS", t.__name__)
    print(f"All {len(tests)} tests passed.")
