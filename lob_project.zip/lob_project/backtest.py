"""backtest.py -- test the market maker against a market history, one day at a time.

The history is a fixed tape (see hawkes.py): for every decision step it holds the mid price and the
market orders that arrive. The market maker posts quotes at each step; every market order in the tape
is sent into a freshly replenished order book that contains our quotes, and the matching engine
decides whether we are filled. Prices and orders never react to us, so every strategy sees exactly the
same market.

No look-ahead: the first `train_days` days are used only to calibrate (fill curve and volatility); for
each later day, the volatility inputs use bars from earlier days only.
"""
from dataclasses import dataclass

import numpy as np

from hawkes import MarketHistory
from sim import Quoter, _fresh_book, avg_as_spread
from volatility import EwmaVolatility, yang_zhang


@dataclass
class BacktestConfig:
    gamma: float = 0.1            # the market maker's risk aversion
    tick: float = 0.1             # price grid
    bg_depth: int = 15            # shares of other traders resting on every tick level
    ewma_decay: float = 0.95      # memory of the intraday volatility estimate
    yz_window: int = 10           # days of bars in the Yang-Zhang estimate
    markout_steps: int = 5        # how long after a fill we measure the adverse price move
    q_limit: int = 20             # hard inventory limit, in shares
    train_days: int = 40          # days used for calibration only
    strategies: tuple = ("sym", "as", "exact", "vol_aware")


# ----------------------------------------------------------------------------- calibration
def calibrate_fill_curve(history, days, tick=0.1, bg_depth=15, ticks=range(2, 17)):
    """Fit  rate(delta) = A exp(-k delta)  to the tape, the way you would from your own fills.

    A one-share quote `i` ticks from the mid, with `bg_depth` shares of other traders in front of it on
    every tick, is filled by a market order of size M exactly when M > bg_depth * i. We count how often
    that happens per side per day for several distances and fit a straight line to the log of the rates."""
    sizes = np.concatenate([history.days[d].ev_size for d in days])
    per_side_days = 2.0 * len(days)
    delta, rate = [], []
    for i in ticks:
        n = int((sizes > bg_depth * i).sum())
        if n > 0:
            delta.append(i * tick)
            rate.append(n / per_side_days)
    delta, rate = np.array(delta), np.array(rate)
    slope, intercept = np.polyfit(delta, np.log(rate), 1)
    fitted = intercept + slope * delta
    ss_res = np.sum((np.log(rate) - fitted) ** 2)
    ss_tot = np.sum((np.log(rate) - np.log(rate).mean()) ** 2)
    return {"A": float(np.exp(intercept)), "k": float(-slope), "r2": float(1 - ss_res / ss_tot),
            "delta": delta, "rate": rate}


def intraday_sigma_estimates(history, window):
    """Yang-Zhang intraday volatility after each day, in price units per sqrt(day). Entry d uses bars
    up to and including day d only."""
    o = history.ohlc
    yz = yang_zhang(o["open"], o["high"], o["low"], o["close"], window=window, overnight=False)
    return yz * o["close"]


def realized_intraday_sigma(history):
    """What each day's volatility turned out to be (for comparison only; never given to a strategy)."""
    n = history.params.n_steps
    return np.array([np.std(np.diff(d.mid)) * np.sqrt(n) for d in history.days])


# ----------------------------------------------------------------------------- one day
def run_day(quoter, tape, sigma0, cfg, n_steps):
    """Trade one day of the tape. Returns the day's PnL split into its parts and the inventory path."""
    dt = 1.0 / n_steps
    estimator = EwmaVolatility(sigma0, cfg.ewma_decay)
    q, cash, edge, inv_pnl = 0, 0.0, 0.0, 0.0
    q_path, gaps, fills = np.zeros(n_steps, dtype=int), np.zeros(n_steps), []
    mid = tape.mid
    for i in range(n_steps):
        S = mid[i]
        B = int(round(S / cfg.tick))
        bid, ask = quoter.quotes(i, S, q, estimator)
        bid_i = min(int(np.floor(float(bid) / cfg.tick + 1e-9)), B)
        ask_i = max(int(np.ceil(float(ask) / cfg.tick - 1e-9)), B)
        if ask_i <= bid_i:
            ask_i = bid_i + 1
        bid_live = bid_i if q < cfg.q_limit else None
        ask_live = ask_i if q > -cfg.q_limit else None
        gaps[i] = (ask_i - bid_i) * cfg.tick

        sides, sizes = tape.events(i)
        for side, size in zip(sides, sizes):
            live = ask_live if side > 0 else bid_live
            if live is None:
                continue
            ahead = cfg.bg_depth * max((live - B) if side > 0 else (B - live), 0)
            if size <= ahead:
                continue                                    # not enough size to reach our quote
            levels = max(ask_live - B if ask_live is not None else 1, B - bid_live if bid_live is not None else 1, 1) + 2
            book = _fresh_book(B, levels, cfg.bg_depth, bid_live, ask_live)
            for f in book.add_market("bid" if side > 0 else "ask", int(size), "noise"):
                if f.resting_owner != "MM":
                    continue
                px = f.price * cfg.tick
                if f.resting_side == "bid":                 # a seller hit our bid: we buy
                    cash -= px * f.qty; q += f.qty; edge += (S - px) * f.qty; bid_live = None
                    fills.append((i, 1, f.qty))
                else:                                       # a buyer lifted our ask: we sell
                    cash += px * f.qty; q -= f.qty; edge += (px - S) * f.qty; ask_live = None
                    fills.append((i, -1, f.qty))
        q_path[i] = q
        ds = mid[i + 1] - mid[i]
        inv_pnl += q * ds
        estimator.update(ds, dt)

    pnl = cash + q * mid[-1]
    assert abs(pnl - (edge + inv_pnl)) < 1e-6, "PnL decomposition identity failed"
    markout = sum(sign * qty * (mid[min(i + cfg.markout_steps, n_steps)] - mid[i]) for i, sign, qty in fills)
    return dict(pnl=pnl, edge=edge, inv_pnl=inv_pnl, markout=markout, fills=sum(f[2] for f in fills),
                q_path=q_path, gap=float(gaps.mean()))


# ----------------------------------------------------------------------------- the whole backtest
def run_backtest(history, cfg=None, progress=None):
    """Calibrate on the first `cfg.train_days` days, then trade the remaining days with every strategy.
    `progress(done, total)` is called after each strategy-day if provided."""
    cfg = cfg or BacktestConfig()
    p = history.params
    if history.n_days <= cfg.train_days or cfg.train_days < cfg.yz_window + 1:
        raise ValueError("need more days than train_days, and train_days > yz_window")
    train = list(range(cfg.train_days))
    test = list(range(cfg.train_days, history.n_days))

    calib = calibrate_fill_curve(history, train, cfg.tick, cfg.bg_depth)
    yz = intraday_sigma_estimates(history, cfg.yz_window)
    sigma_static = float(yz[cfg.train_days - 1])            # the fixed assumption: calibrated once, never updated
    half = avg_as_spread(cfg.gamma, sigma_static, calib["k"], 1.0) / 2     # the fixed-gap strategy's half-spread

    total, done = len(cfg.strategies) * len(test), 0
    results = {}
    for strategy in cfg.strategies:
        quoter = Quoter(strategy, cfg.gamma, calib["k"], calib["A"], 1.0, p.n_steps, sigma_static, half, cfg.q_limit)
        rows = []
        for d in test:
            sigma0 = float(yz[d - 1])                       # volatility known BEFORE day d starts
            rows.append(run_day(quoter, history.days[d], sigma0, cfg, p.n_steps))
            done += 1
            if progress:
                progress(done, total)
        results[strategy] = {key: np.array([r[key] for r in rows]) for key in
                             ("pnl", "edge", "inv_pnl", "markout", "fills", "q_path", "gap")}
    realized = realized_intraday_sigma(history)
    return {"config": cfg, "calibration": calib, "sigma_static": sigma_static, "half_spread": half,
            "test_days": test, "strategies": results,
            "volatility": {"yang_zhang": np.array([yz[d - 1] for d in test]), "realized": realized[test],
                           "static": sigma_static}}
