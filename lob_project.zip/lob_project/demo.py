"""demo.py -- run ONE market-making day and show/save a 4-panel chart.

Examples:
    python demo.py                              # Level 1, Avellaneda-Stoikov, default parameters
    python demo.py --level 2 --gamma 0.3        # full order-book simulator, more risk averse
    python demo.py --strategy vol_aware --storms severe   # volatility-aware strategy in a stormy market
    python demo.py --strategy sym --seed 5      # symmetric baseline
    python demo.py --save day.png               # save instead of opening a window
"""
import argparse
import matplotlib.pyplot as plt
from sim import STRATEGIES, simulate_level1, simulate_level2, avg_as_spread
from volatility import DEFAULT_REGIME, RegimeVolatility

p = argparse.ArgumentParser(description="One simulated trading day of a market maker.")
p.add_argument("--level", type=int, choices=[1, 2], default=1, help="1 = probabilistic fills, 2 = real order book")
p.add_argument("--strategy", choices=STRATEGIES, default="as",
               help="sym = fixed gap, as = textbook formula, exact = exact formula, vol_aware = exact + measures volatility")
p.add_argument("--storms", choices=["none", "mild", "severe"], default="none", help="calm market with random volatility storms")
p.add_argument("--gamma", type=float, default=0.1, help="risk aversion")
p.add_argument("--sigma", type=float, default=2.0, help="price volatility")
p.add_argument("--k", type=float, default=1.5, help="fill-rate decay")
p.add_argument("--A", type=float, default=140.0, help="arrival rate scale")
p.add_argument("--seed", type=int, default=1)
p.add_argument("--save", default=None, help="save the chart to this file instead of showing it")
a = p.parse_args()

regime = {"none": None, "mild": DEFAULT_REGIME,
          "severe": dict(stress_mult=5.0, p_enter=0.01, p_exit=0.033)}[a.storms]
avg_sigma = RegimeVolatility(a.sigma, **regime).average_sigma if regime else a.sigma
half = avg_as_spread(a.gamma, avg_sigma, a.k, 1.0) / 2      # the 'sym' strategy gets the same average gap
if a.level == 1:
    res = simulate_level1(a.strategy, n_runs=1, seed=a.seed, gamma=a.gamma, sigma=a.sigma,
                          k=a.k, A=a.A, half_spread=half, regime=regime, record_first=True)
else:
    res = simulate_level2(a.strategy, n_runs=1, seed=a.seed, gamma=a.gamma, sigma=a.sigma,
                          k=a.k, lam=a.A, half_spread=half, regime=regime, record_first=True)
path = res["path"]

fig, ax = plt.subplots(3, 1, figsize=(9, 8), sharex=True, gridspec_kw={"height_ratios": [2.4, 1, 1]})
ax[0].plot(path["t"], path["s"], label="mid price", color="#1f3a5f")
ax[0].step(path["t"], path["bid"], label="our bid", color="#2a9d8f", lw=0.9, where="post")
ax[0].step(path["t"], path["ask"], label="our ask", color="#e07a1f", lw=0.9, where="post")
ax[0].set_ylabel("price"); ax[0].legend(ncol=3, loc="upper left")
ax[1].step(path["t"], path["q"], color="#c0392b", where="post"); ax[1].axhline(0, color="k", lw=0.6)
ax[1].set_ylabel("inventory q")
ax[2].plot(path["t"], path["pnl"], color="#1f3a5f"); ax[2].set_ylabel("wealth (PnL)"); ax[2].set_xlabel("time")
fig.suptitle(f"Level {a.level}, strategy={a.strategy}, gamma={a.gamma}, seed={a.seed}  |  "
             f"final PnL {float(res['pnl'][0]):.2f}, final inventory {int(res['q'][0])}")
for axis in ax:
    axis.grid(alpha=0.25)
fig.tight_layout()
if a.save:
    fig.savefig(a.save, dpi=150)
    print("saved", a.save)
else:
    plt.show()
