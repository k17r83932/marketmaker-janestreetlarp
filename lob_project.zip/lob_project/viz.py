"""viz.py -- small animated charts for Streamlit, drawn with plain SVG and JavaScript (no extra libraries).

What the charts do
  * Curves are drawn with monotone cubic splines, so lines flow instead of zig-zagging.
  * When the data behind a chart changes, the curve MORPHS from its previous shape to the new one.
  * A chart draws itself in from the left on first load and again each time its tab is opened.
  * Hover for exact values; click a legend entry to fade a series in or out.

Smoothing is a display choice only: the numbers in tooltips and tables are the exact data.

Usage:  chart("price", spec, theme)   where spec is built with the helpers below.
"""
import json
import time

import numpy as np
import streamlit as st


# ----------------------------------------------------------------------------- spec helpers
def _arr(v, nd=6):
    return [round(float(x), nd) for x in np.asarray(v, float).ravel()]


def thin(x, y, limit=360):
    """Keep at most `limit` points (every n-th), so charts stay light."""
    x, y = np.asarray(x, float), np.asarray(y, float)
    if len(x) <= limit:
        return x, y
    idx = np.unique(np.linspace(0, len(x) - 1, limit).astype(int))
    return x[idx], y[idx]


def line(name, x, y, color, width=2.0, smooth=True, dash=None, legend=True):
    x, y = thin(x, y)
    return dict(type="line", name=name, x=_arr(x), y=_arr(y), color=color, width=width, smooth=smooth, dash=dash, legend=legend)


def steps(name, x, y, color, width=1.6, area=True, opacity=0.14):
    x, y = thin(x, y)
    return dict(type="steps", name=name, x=_arr(x), y=_arr(y), color=color, width=width, area=area, opacity=opacity)


def area(name, x, y, color, base=0.0, opacity=0.16, width=2.0, smooth=True):
    x, y = thin(x, y)
    return dict(type="area", name=name, x=_arr(x), y=_arr(y), color=color, base=float(base), opacity=opacity, width=width, smooth=smooth)


def band(name, x, lower, upper, color, opacity=0.16):
    x, lower, upper = np.asarray(x, float), np.asarray(lower, float), np.asarray(upper, float)
    if len(x) > 360:
        idx = np.unique(np.linspace(0, len(x) - 1, 360).astype(int))
        x, lower, upper = x[idx], lower[idx], upper[idx]
    return dict(type="band", name=name, x=_arr(x), y0=_arr(lower), y=_arr(upper), color=color, opacity=opacity)


def points(name, x, y, color, r=3.2):
    return dict(type="points", name=name, x=_arr(x), y=_arr(y), color=color, r=r)


def hline(y, color, dash="4 4", name=None):
    return dict(type="hline", y=float(y), color=color, dash=dash, name=name)


def bars(name, x, y, color, width=0.6, colors=None):
    return dict(type="bars", name=name, x=_arr(x), y=_arr(y), color=color, bw=float(width), colors=colors)


def spec(series, height=300, xlabel="", ylabel="", yformat="num", xformat="num", xticks=None, ymin=None, ymax=None,
         xmin=None, xmax=None, legend=True):
    return dict(kind="xy", series=series, height=height, xlabel=xlabel, ylabel=ylabel, yformat=yformat, xformat=xformat,
                xticks=xticks, ymin=ymin, ymax=ymax, xmin=xmin, xmax=xmax, legend=legend)


def heatmap(x, y, z, ramp, height=300, xlabel="", ylabel="", zlabel="", zmin=None, zmax=None, zformat="num"):
    z = np.asarray(z, float)
    return dict(kind="heatmap", x=_arr(x), y=_arr(y), z=[_arr(r) for r in z], ramp=ramp, height=height, xlabel=xlabel,
                ylabel=ylabel, zlabel=zlabel, zmin=float(z.min() if zmin is None else zmin),
                zmax=float(z.max() if zmax is None else zmax), zformat=zformat, series=[], legend=False)


def kde(samples, grid_points=120, lo=None, hi=None, bandwidth=None):
    """Gaussian kernel density estimate on a grid, as (x, density)."""
    s = np.asarray(samples, float)
    lo = s.min() if lo is None else lo
    hi = s.max() if hi is None else hi
    if hi <= lo:
        hi = lo + 1.0
    bw = bandwidth or max(1.06 * s.std(ddof=1) * len(s) ** (-0.2), 1e-6) if len(s) > 1 else 1.0
    g = np.linspace(lo, hi, grid_points)
    d = np.exp(-0.5 * ((g[:, None] - s[None, :]) / bw) ** 2).sum(axis=1) / (len(s) * bw * np.sqrt(2 * np.pi))
    return g, d


# ----------------------------------------------------------------------------- rendering
def chart(key, chart_spec, theme, extra_height=0):
    """Draw a chart. The previous spec for this key (if it changed) is passed along so the browser can morph."""
    store = st.session_state.setdefault("_viz", {})
    entry = store.get(key)
    if entry is None:
        entry = {"spec": chart_spec, "prev": None, "stamp": time.time() * 1000}
    elif entry["spec"] != chart_spec:
        entry = {"spec": chart_spec, "prev": entry["spec"], "stamp": time.time() * 1000}
    store[key] = entry
    html = (TEMPLATE.replace("__SPEC__", json.dumps(entry["spec"], separators=(",", ":")))
            .replace("__PREV__", json.dumps(entry["prev"], separators=(",", ":")))
            .replace("__THEME__", json.dumps(theme, separators=(",", ":")))
            .replace("__STAMP__", str(int(entry["stamp"]))))
    legend_h = 30 if chart_spec.get("legend", True) else 0
    height = int(chart_spec["height"]) + legend_h + extra_height
    if hasattr(st, "iframe"):                       # current Streamlit
        st.iframe(html, width="stretch", height=height)
    else:                                           # older Streamlit
        import streamlit.components.v1 as components
        components.html(html, height=height, scrolling=False)


TEMPLATE = r"""<!doctype html><html><head><meta charset="utf-8">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600&family=Spline+Sans+Mono:wght@400;500&display=swap">
<style>
html,body{margin:0;background:transparent;font:500 12px 'Archivo','Arial Narrow',system-ui,sans-serif;color:var(--muted);overflow:hidden}
#wrap{position:relative;width:100%}
#lg{display:flex;flex-wrap:wrap;gap:4px 18px;padding:2px 2px 8px;min-height:20px}
.lgi{display:inline-flex;align-items:center;gap:7px;cursor:pointer;transition:opacity .3s;user-select:none;color:var(--muted)}
.lgi:hover{color:var(--text)}
.lgi.off{opacity:.32}
.sw{display:inline-block;width:18px;height:0;border-top:2px solid}
.sw.f{height:10px;width:12px;border:0;border-radius:2px;opacity:.55}
svg{display:block;width:100%;overflow:visible}
.grid line{stroke:var(--line);stroke-width:1;opacity:.5}
.axis text{font:400 10.5px 'Spline Sans Mono',ui-monospace,Consolas,monospace;fill:var(--muted)}
.axt{font:500 11px 'Archivo',system-ui,sans-serif;fill:var(--muted)}
.s{transition:opacity .35s}
#tip{position:absolute;pointer-events:none;background:var(--raised);border:1px solid var(--line);border-radius:4px;padding:7px 10px;
 font:400 11px/1.55 'Spline Sans Mono',ui-monospace,Consolas,monospace;color:var(--text);opacity:0;transition:opacity .18s,transform .12s;white-space:nowrap;z-index:5;box-shadow:0 8px 24px var(--shadow)}
#tip b{font-weight:500;color:var(--muted);margin-right:6px}
</style></head><body><div id="wrap"><div id="lg"></div><svg id="s"></svg><div id="tip"></div></div>
<script>
(function(){
const SPEC=__SPEC__, PREV=__PREV__, TH=__THEME__, STAMP=__STAMP__;
const R=document.documentElement; for(const k in TH) R.style.setProperty('--'+k, TH[k]);
const NS='http://www.w3.org/2000/svg', svg=document.getElementById('s'), lg=document.getElementById('lg'), tip=document.getElementById('tip'), wrap=document.getElementById('wrap');
const H=SPEC.height, HEAT=SPEC.kind==='heatmap', M={l:HEAT?58:62,r:16,t:8,b:HEAT?44:38};
let W=0, raf=0, hidden=new Set(), cur=null, shown=false;
const ease=t=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2, lerp=(a,b,t)=>a+(b-a)*t;
const el=(tag,attrs,parent)=>{const e=document.createElementNS(NS,tag);for(const k in attrs)e.setAttribute(k,attrs[k]);if(parent)parent.appendChild(e);return e;};

function nice(min,max,n){ if(!(max>min)){max=min+1;} const span=max-min, s0=span/Math.max(n,2), mag=Math.pow(10,Math.floor(Math.log10(s0))), nm=s0/mag;
  const step=(nm<1.5?1:nm<3?2:nm<7?5:10)*mag, lo=Math.floor(min/step+1e-9)*step, hi=Math.ceil(max/step-1e-9)*step, t=[];
  for(let v=lo;v<=hi+step*.5;v+=step)t.push(+v.toFixed(10)); return t; }
function fmt(v,f){ if(f==='pct')return (v*100).toFixed(0)+'%'; if(f==='int')return Math.round(v).toLocaleString();
  const a=Math.abs(v); if(a>=1000)return Math.round(v).toLocaleString(); if(a>=100)return v.toFixed(0); if(a>=10)return (+v.toFixed(1)).toString(); return (+v.toFixed(2)).toString(); }

function domain(sp){ let x0=1e300,x1=-1e300,y0=1e300,y1=-1e300;
  if(sp.kind==='heatmap'){ const xs=sp.x, ys=sp.y; return {x0:xs[0],x1:xs[xs.length-1],y0:ys[0],y1:ys[ys.length-1]}; }
  for(const s of sp.series){ if(s.type==='hline'){y0=Math.min(y0,s.y);y1=Math.max(y1,s.y);continue;}
    for(const v of s.x){x0=Math.min(x0,v);x1=Math.max(x1,v);} for(const v of s.y){y0=Math.min(y0,v);y1=Math.max(y1,v);}
    if(s.y0)for(const v of s.y0){y0=Math.min(y0,v);y1=Math.max(y1,v);}
    if((s.type==='area'||s.type==='bars')&&typeof (s.base===undefined?0:s.base)==='number'){const b=s.base===undefined?0:s.base;y0=Math.min(y0,b);y1=Math.max(y1,b);} }
  if(sp.type==='bars'){}
  const hasBars=sp.series.some(s=>s.type==='bars'); if(hasBars){ x0-=0.6; x1+=0.6; }
  if(sp.xmin!=null)x0=sp.xmin; if(sp.xmax!=null)x1=sp.xmax;
  const pad=(y1-y0)*0.07||1; y0-=pad; y1+=pad; if(sp.ymin!=null)y0=sp.ymin; if(sp.ymax!=null)y1=sp.ymax;
  if(x1===x0)x1=x0+1; return {x0,x1,y0,y1}; }

function resample(px,py,x){ const out=[]; let j=0; for(const v of x){ if(v<=px[0]){out.push(py[0]);continue;} if(v>=px[px.length-1]){out.push(py[py.length-1]);continue;}
  while(j<px.length-2&&px[j+1]<v)j++; while(j>0&&px[j]>v)j--; const t=(v-px[j])/((px[j+1]-px[j])||1); out.push(lerp(py[j],py[j+1],t)); } return out; }

function monotone(px,py){ const n=px.length; if(n<1)return ''; let d='M'+px[0].toFixed(1)+','+py[0].toFixed(1); if(n===1)return d; if(n===2)return d+'L'+px[1].toFixed(1)+','+py[1].toFixed(1);
  const dx=[],m=[],t=new Array(n); for(let i=0;i<n-1;i++){dx[i]=px[i+1]-px[i];m[i]=dx[i]===0?0:(py[i+1]-py[i])/dx[i];}
  t[0]=m[0];t[n-1]=m[n-2]; for(let i=1;i<n-1;i++){t[i]=(m[i-1]*m[i]<=0)?0:(m[i-1]+m[i])/2;}
  for(let i=0;i<n-1;i++){ if(m[i]===0){t[i]=0;t[i+1]=0;continue;} const a=t[i]/m[i],b=t[i+1]/m[i],s=a*a+b*b; if(s>9){const k=3/Math.sqrt(s);t[i]=k*a*m[i];t[i+1]=k*b*m[i];} }
  for(let i=0;i<n-1;i++){ d+='C'+(px[i]+dx[i]/3).toFixed(1)+','+(py[i]+t[i]*dx[i]/3).toFixed(1)+' '+(px[i+1]-dx[i]/3).toFixed(1)+','+(py[i+1]-t[i+1]*dx[i]/3).toFixed(1)+' '+px[i+1].toFixed(1)+','+py[i+1].toFixed(1); }
  return d; }
function linear(px,py){ let d=''; for(let i=0;i<px.length;i++)d+=(i?'L':'M')+px[i].toFixed(1)+','+py[i].toFixed(1); return d; }
function stepPath(px,py){ let d='M'+px[0].toFixed(1)+','+py[0].toFixed(1); for(let i=1;i<px.length;i++)d+='H'+px[i].toFixed(1)+'V'+py[i].toFixed(1); return d; }
function mix(c1,c2,t){ const p=c=>[1,3,5].map(i=>parseInt(c.slice(i,i+2),16)); const a=p(c1),b=p(c2); return 'rgb('+a.map((v,i)=>Math.round(lerp(v,b[i],t))).join(',')+')'; }

function legendBuild(){ lg.innerHTML=''; if(SPEC.legend===false){lg.style.display='none';return;} const seen=new Set();
  for(const s of SPEC.series){ if(!s.name||s.legend===false||seen.has(s.name))continue; seen.add(s.name);
    const it=document.createElement('span'); it.className='lgi'; const sw=document.createElement('span'); sw.className='sw'+((s.type==='band'||s.type==='bars'||s.type==='points')?' f':'');
    if(s.type==='band'||s.type==='bars'||s.type==='points'){sw.style.background=s.color;if(s.type==='points'){sw.style.borderRadius='50%';sw.style.width='9px';sw.style.height='9px';sw.style.opacity=1;}} else {sw.style.borderTopColor=s.color; if(s.dash)sw.style.borderTopStyle='dashed';}
    it.appendChild(sw); it.appendChild(document.createTextNode(s.name));
    it.onclick=()=>{ if(hidden.has(s.name))hidden.delete(s.name); else hidden.add(s.name); it.classList.toggle('off'); svg.querySelectorAll('[data-n="'+CSS.escape(s.name)+'"]').forEach(e=>e.style.opacity=hidden.has(s.name)?0:1); };
    lg.appendChild(it); } }

function frame(p,reveal){
  if(wrap.clientWidth<M.l+M.r+60)return;            // hidden or too narrow to draw (e.g. tab switched mid-animation)
  W=wrap.clientWidth; const pw=W-M.l-M.r, ph=H-M.t-M.b; svg.setAttribute('viewBox','0 0 '+W+' '+H); svg.setAttribute('height',H); svg.innerHTML='';
  const dB=domain(SPEC), dA=(PREV&&p<1)?domain(PREV):dB, D={x0:lerp(dA.x0,dB.x0,p),x1:lerp(dA.x1,dB.x1,p),y0:lerp(dA.y0,dB.y0,p),y1:lerp(dA.y1,dB.y1,p)};
  const X=v=>M.l+(v-D.x0)/((D.x1-D.x0)||1)*pw, Y=v=>M.t+(1-(v-D.y0)/((D.y1-D.y0)||1))*ph; cur={X,Y,D,pw,ph};
  const g=el('g',{class:'grid'},svg), ax=el('g',{class:'axis'},svg);
  if(!HEAT){
  const yt=nice(dB.y0,dB.y1,Math.max(3,Math.round(ph/58))); for(const v of yt){ if(v<D.y0-1e-9||v>D.y1+1e-9)continue; el('line',{x1:M.l,x2:W-M.r,y1:Y(v),y2:Y(v)},g); const t=el('text',{x:M.l-9,y:Y(v)+3.5,'text-anchor':'end'},ax); t.textContent=fmt(v,SPEC.yformat); }
  let xt; if(SPEC.xticks){ xt=SPEC.xticks; for(const o of xt){ const t=el('text',{x:X(o.pos),y:H-M.b+17,'text-anchor':'middle'},ax); t.textContent=o.label; } }
  else { const xs=nice(dB.x0,dB.x1,Math.max(3,Math.round(pw/110))); for(const v of xs){ if(v<D.x0-1e-9||v>D.x1+1e-9)continue; el('line',{x1:X(v),x2:X(v),y1:M.t,y2:H-M.b},g); const t=el('text',{x:X(v),y:H-M.b+17,'text-anchor':'middle'},ax); t.textContent=fmt(v,SPEC.xformat); } }
  }
  if(SPEC.xlabel){const t=el('text',{x:M.l+pw/2,y:H-4,'text-anchor':'middle',class:'axt'},svg); t.textContent=SPEC.xlabel;}
  if(SPEC.ylabel){const t=el('text',{transform:'translate(13,'+(M.t+ph/2)+') rotate(-90)','text-anchor':'middle',class:'axt'},svg); t.textContent=SPEC.ylabel;}
  const cid='c'+Math.random().toString(36).slice(2,8), cp=el('clipPath',{id:cid},svg); const cr=el('rect',{x:M.l-6,y:0,width:(reveal?ease(p)*(pw+22):pw+22),height:H},cp);
  const body=el('g',{'clip-path':'url(#'+cid+')'},svg);
  if(HEAT){ heat(body,p,X,Y,pw,ph); return; }
  const pmap={}; if(PREV&&p<1&&!reveal){ for(const s of PREV.series)if(s.name)pmap[s.name+'|'+s.type]=s; }
  for(const s of SPEC.series){
    if(s.type==='hline'){ el('line',{x1:M.l,x2:W-M.r,y1:Y(s.y),y2:Y(s.y),stroke:s.color,'stroke-width':1.2,'stroke-dasharray':s.dash||'4 4',opacity:.8,'data-n':s.name||''},body); continue; }
    const pv=pmap[(s.name||'')+'|'+s.type]; let ys=s.y, y0s=s.y0;
    if(pv&&p<1){ const py=pv.x.length===s.x.length?pv.y:resample(pv.x,pv.y,s.x); ys=s.y.map((v,i)=>lerp(py[i],v,ease(p)));
      if(s.y0&&pv.y0){const p0=pv.x.length===s.x.length?pv.y0:resample(pv.x,pv.y0,s.x); y0s=s.y0.map((v,i)=>lerp(p0[i],v,ease(p)));} }
    const px=s.x.map(X), py=ys.map(Y), op=hidden.has(s.name)?0:1, nm=s.name||'';
    if(s.type==='line'){ el('path',{d:s.smooth?monotone(px,py):linear(px,py),fill:'none',stroke:s.color,'stroke-width':s.width,'stroke-linecap':'round','stroke-linejoin':'round','stroke-dasharray':s.dash||'',class:'s','data-n':nm,style:'opacity:'+op},body); }
    else if(s.type==='steps'){ const d=stepPath(px,py); if(s.area){ el('path',{d:d+'L'+px[px.length-1].toFixed(1)+','+Y(0)+'L'+px[0].toFixed(1)+','+Y(0)+'Z',fill:s.color,opacity:s.opacity*op,class:'s','data-n':nm},body); }
      el('path',{d:d,fill:'none',stroke:s.color,'stroke-width':s.width,'stroke-linejoin':'round',class:'s','data-n':nm,style:'opacity:'+op},body); }
    else if(s.type==='area'){ const d=s.smooth?monotone(px,py):linear(px,py); const yb=Y(s.base);
      el('path',{d:d+'L'+px[px.length-1].toFixed(1)+','+yb.toFixed(1)+'L'+px[0].toFixed(1)+','+yb.toFixed(1)+'Z',fill:s.color,opacity:s.opacity*op,class:'s','data-n':nm},body);
      el('path',{d:d,fill:'none',stroke:s.color,'stroke-width':s.width,'stroke-linecap':'round','stroke-linejoin':'round',class:'s','data-n':nm,style:'opacity:'+op},body); }
    else if(s.type==='band'){ const lo=(y0s||s.y0).map(Y), up=py; const top=monotone(px,up); const rx=px.slice().reverse(), rl=lo.slice().reverse();
      const bot=monotone(rx,rl); el('path',{d:top+'L'+rx[0].toFixed(1)+','+rl[0].toFixed(1)+bot.replace(/^M[^C]*/,'')+'Z',fill:s.color,opacity:s.opacity*op,class:'s','data-n':nm},body); }
    else if(s.type==='bars'){ const bw=Math.abs(X(s.x[0]+s.bw)-X(s.x[0]))*0.9/1; const y0=Y(0); s.x.forEach((xv,i)=>{ const h=py[i]-y0; el('rect',{x:X(xv)-bw/2,y:Math.min(py[i],y0),width:bw,height:Math.abs(h),rx:2,fill:(s.colors&&s.colors[i])||s.color,opacity:.85*op,class:'s','data-n':nm},body); }); }
    else if(s.type==='points'){ s.x.forEach((xv,i)=>{ el('circle',{cx:X(xv),cy:py[i],r:s.r,fill:s.color,stroke:TH.bg,'stroke-width':1.2,class:'s','data-n':nm,style:'opacity:'+op},body); }); }
  }
  el('line',{x1:M.l,x2:W-M.r,y1:Y(0),y2:Y(0),stroke:TH.control,'stroke-width':1,opacity:(D.y0<0&&D.y1>0)?.7:0},body);
}

function heat(body,p,X,Y,pw,ph){ const xs=SPEC.x, ys=SPEC.y, z=SPEC.z, ramp=SPEC.ramp, zr=(SPEC.zmax-SPEC.zmin)||1; const pz=(PREV&&PREV.kind==='heatmap'&&PREV.z.length===z.length&&PREV.z[0].length===z[0].length&&p<1)?PREV.z:null;
  const cw=pw/xs.length, chh=ph/ys.length;
  for(let j=0;j<ys.length;j++)for(let i=0;i<xs.length;i++){ let v=z[j][i]; if(pz)v=lerp(pz[j][i],v,ease(p)); const t=Math.max(0,Math.min(1,(v-SPEC.zmin)/zr));
    el('rect',{x:M.l+i*cw,y:M.t+(ys.length-1-j)*chh,width:cw+0.6,height:chh+0.6,fill:mix(ramp[0],ramp[1],t)},body); }
  const g=el('g',{class:'axis'},svg); const nx=Math.min(6,xs.length);
  for(let k=0;k<nx;k++){ const i=Math.round(k*(xs.length-1)/(nx-1)); const t=el('text',{x:M.l+(i+.5)*cw,y:H-M.b+17,'text-anchor':'middle'},g); t.textContent=fmt(xs[i],SPEC.xformat||'num'); }
  const ny=Math.min(7,ys.length); for(let k=0;k<ny;k++){ const j=Math.round(k*(ys.length-1)/(ny-1)); const t=el('text',{x:M.l-9,y:M.t+(ys.length-1-j+.5)*chh+3.5,'text-anchor':'end'},g); t.textContent=fmt(ys[j],'int'); } }

function run(mode){ cancelAnimationFrame(raf); W=wrap.clientWidth; if(W<30)return; const t0=performance.now(), dur=mode==='reveal'?1100:mode==='tween'?900:0;
  if(!dur){ frame(1,false); return; } const step=now=>{ const p=Math.max(0,Math.min(1,(now-t0)/dur)); frame(mode==='reveal'?p:p,mode==='reveal'); if(p<1)raf=requestAnimationFrame(step); else frame(1,false); }; raf=requestAnimationFrame(step); }

svg.addEventListener('mousemove',e=>{ if(!cur||HEAT&&false)return; const r=svg.getBoundingClientRect(), mx=(e.clientX-r.left)*(W/r.width), my=(e.clientY-r.top)*(H/r.height);
  if(mx<M.l||mx>W-M.r){tip.style.opacity=0;return;}
  if(HEAT){ const xs=SPEC.x, ys=SPEC.y, cw=cur.pw/xs.length, chh=cur.ph/ys.length, i=Math.floor((mx-M.l)/cw), j=ys.length-1-Math.floor((my-M.t)/chh); if(i<0||i>=xs.length||j<0||j>=ys.length){tip.style.opacity=0;return;}
    tip.innerHTML='<b>'+(SPEC.xlabel||'x')+'</b>'+fmt(xs[i],'num')+'<br><b>'+(SPEC.ylabel||'y')+'</b>'+fmt(ys[j],'int')+'<br><b>'+(SPEC.zlabel||'value')+'</b>'+(+SPEC.z[j][i].toFixed(3)); }
  else { const xv=cur.D.x0+(mx-M.l)/cur.pw*(cur.D.x1-cur.D.x0); let rows=[], xl=null;
    for(const s of SPEC.series){ if(s.type==='hline'||!s.name||hidden.has(s.name))continue; let best=0,bd=1e300; for(let i=0;i<s.x.length;i++){const dd=Math.abs(s.x[i]-xv); if(dd<bd){bd=dd;best=i;}}
      if(xl===null)xl=s.x[best]; rows.push('<span style="color:'+s.color+'">&#9679;</span> <b>'+s.name+'</b>'+fmt(s.y[best],SPEC.yformat==='pct'?'pct':'num')); }
    if(!rows.length){tip.style.opacity=0;return;} const lbl=(SPEC.xticks&&SPEC.xticks.length)?(SPEC.xticks.reduce((a,o)=>Math.abs(o.pos-xl)<Math.abs(a.pos-xl)?o:a).label):fmt(xl,SPEC.xformat);
    tip.innerHTML='<b>'+(SPEC.xlabel||'x')+'</b>'+lbl+'<br>'+rows.join('<br>'); }
  const tw=tip.offsetWidth; let tx=mx+14; if(tx+tw>W)tx=mx-tw-14; tip.style.transform='translate('+tx+'px,'+(my-8+(SPEC.legend===false?0:lg.offsetHeight))+'px)'; tip.style.left='0';tip.style.top='0'; tip.style.opacity=1; });
svg.addEventListener('mouseleave',()=>{tip.style.opacity=0;});

legendBuild();
// Morph from the old data only when the data JUST changed; opening a tab later redraws from the left instead.
let lastW=0; const same=PREV&&JSON.stringify(PREV)===JSON.stringify(SPEC), fresh=PREV&&Math.abs(Date.now()-STAMP)<4000;
new ResizeObserver(()=>{ const w=wrap.clientWidth; if(w<30){lastW=w;shown=false;return;}
  if(lastW<30){ run(!shown&&fresh&&!same?'tween':'reveal'); shown=true; } else if(Math.abs(w-lastW)>1){ run('static'); }
  lastW=w; }).observe(wrap);
})();
</script></body></html>"""
