"""test_volatility.py -- tests for the volatility handling (run:  python test_volatility.py)"""
import numpy as np
from metrics import certainty_equivalent
from sim import STRATEGIES, avg_as_spread, simulate_level1, simulate_level2
from volatility import DEFAULT_REGIME, EwmaVolatility, RegimeVolatility


def test_ewma_recovers_constant_volatility():
    """On a constant-volatility price the running estimate should hover around the true sigma."""
    rng, dt, true_sigma = np.random.default_rng(0), 0.005, 2.0
    est = EwmaVolatility(sigma0=1.0, decay=0.98, size=2000)
    for _ in range(600):
        est.update(true_sigma * np.sqrt(dt) * rng.standard_normal(2000), dt)
    assert abs(est.sigma.mean() - true_sigma) < 0.15


def test_ewma_notices_a_storm():
    """When volatility triples, the estimate must follow within a few dozen steps."""
    rng, dt = np.random.default_rng(1), 0.005
    est = EwmaVolatility(sigma0=2.0, decay=0.95, size=2000)
    for _ in range(100):
        est.update(6.0 * np.sqrt(dt) * rng.standard_normal(2000), dt)
    assert est.sigma.mean() > 5.0


def test_regime_stationary_storm_fraction():
    rng = np.random.default_rng(2)
    market = RegimeVolatility(2.0, size=4000, **DEFAULT_REGIME)
    fractions = []
    for step in range(1500):
        market.step(rng)
        if step > 500:
            fractions.append(market.stressed.mean())
    assert abs(np.mean(fractions) - market.stress_fraction) < 0.02


def test_regime_volatility_values_and_average():
    market = RegimeVolatility(2.0, stress_mult=3.0, p_enter=0.01, p_exit=0.05)
    assert float(market.sigma) == 2.0                       # a day starts calm
    market.stressed = np.array(True)
    assert float(market.sigma) == 6.0
    f = 0.01 / 0.06
    assert abs(market.average_sigma - np.sqrt((1 - f) * 4 + f * 36)) < 1e-12


def test_constant_volatility_results_are_unchanged():
    """Adding volatility handling must not change the original (constant-sigma) results."""
    hs = avg_as_spread(0.1, 2.0, 1.5, 1.0) / 2
    a = simulate_level1("as", n_runs=1000, seed=11)
    b = simulate_level1("sym", n_runs=1000, seed=11, half_spread=hs)
    assert abs(a["pnl"].mean() - 57.30) < 0.01 and abs(a["pnl"].std(ddof=1) - 6.46) < 0.01
    assert abs(b["pnl"].mean() - 61.14) < 0.01 and abs(b["pnl"].std(ddof=1) - 12.46) < 0.01
    assert abs(simulate_level2("as", n_runs=20, seed=5)["n_fills"].mean() - 81.95) < 0.01


def test_vol_aware_matches_exact_when_volatility_is_constant_and_known():
    exact = simulate_level1("exact", n_runs=2000, seed=3)
    aware = simulate_level1("vol_aware", n_runs=2000, seed=3)
    assert abs(exact["pnl"].mean() - aware["pnl"].mean()) < 2.0
    assert abs(exact["pnl"].std() - aware["pnl"].std()) < 1.0


def test_vol_aware_survives_severe_storms_better_than_fixed_exact():
    """The point of the feature: in a market with severe storms, noticing the storm pays."""
    storms = dict(stress_mult=5.0, p_enter=0.01, p_exit=0.033)
    fixed = simulate_level1("exact", n_runs=3000, seed=9, regime=storms)
    aware = simulate_level1("vol_aware", n_runs=3000, seed=9, regime=storms)
    assert certainty_equivalent(aware["pnl"], 0.1) > certainty_equivalent(fixed["pnl"], 0.1) + 2.0
    assert aware["pnl"].std() < fixed["pnl"].std()


def test_exact_beats_closed_form_when_volatility_is_high():
    as_ = simulate_level1("as", n_runs=2000, seed=6, sigma=5.0)
    exact = simulate_level1("exact", n_runs=2000, seed=6, sigma=5.0)
    assert certainty_equivalent(exact["pnl"], 0.1) > certainty_equivalent(as_["pnl"], 0.1) + 5.0


def test_every_strategy_runs_in_both_simulators_with_storms():
    for strategy in STRATEGIES:
        r1 = simulate_level1(strategy, n_runs=200, seed=4, regime=DEFAULT_REGIME, half_spread=0.8)
        assert np.isfinite(r1["pnl"]).all()                 # the PnL identity is asserted inside
        r2 = simulate_level2(strategy, n_runs=3, seed=4, regime=DEFAULT_REGIME, half_spread=0.8)
        assert np.isfinite(r2["pnl"]).all()


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print("PASS", t.__name__)
    print(f"All {len(tests)} tests passed.")
