"""run_experiments.py -- runs every experiment quoted in the guide and saves figures + results.json"""
import json, math, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sim import (simulate_level1, simulate_level2, measure_fill_rate, as_quotes, avg_as_spread)

os.makedirs("figs", exist_ok=True)
NAVY, ORANGE, TEAL, GRAY, RED = "#1f3a5f", "#e07a1f", "#2a9d8f", "#6b7280", "#c0392b"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.spines.top": False,
                     "axes.spines.right": False, "axes.grid": True, "grid.alpha": 0.25,
                     "figure.dpi": 100, "savefig.dpi": 200})

G, SIG, K, A, T = 0.1, 2.0, 1.5, 140.0, 1.0
R = {}                       # everything quoted in the guide goes here


def stats(x):
    x = np.asarray(x, float)
    return dict(mean=float(x.mean()), std=float(x.std(ddof=1)), se=float(x.std(ddof=1) / math.sqrt(len(x))),
                p5=float(np.percentile(x, 5)), p50=float(np.percentile(x, 50)), p95=float(np.percentile(x, 95)),
                min=float(x.min()), max=float(x.max()))


# ------------------------------------------------------------------ E1: Level-1 AS vs symmetric
N1 = 1000
avg_sp = avg_as_spread(G, SIG, K, T)
hs = avg_sp / 2
a = simulate_level1("as", n_runs=N1, seed=11, gamma=G, sigma=SIG, k=K, A=A, T=T, record_first=True)
b = simulate_level1("sym", n_runs=N1, seed=11, half_spread=hs, sigma=SIG, k=K, A=A, T=T)
R["E1"] = dict(n_runs=N1, avg_spread=avg_sp,
               **{nm: dict(pnl=stats(r["pnl"]), q=stats(r["q"]), absq=float(np.abs(r["q"]).mean()),
                           fills=float(r["n_fills"].mean()), edge=float(r["edge"].mean()),
                           inv_pnl=float(r["inv_pnl"].mean()), inv_pnl_std=float(r["inv_pnl"].std()),
                           sharpe_like=float(r["pnl"].mean() / r["pnl"].std()))
                  for nm, r in (("as", a), ("sym", b))})

# sample path (Level 1)
p = a["path"]
fig, ax = plt.subplots(3, 1, figsize=(7.2, 6.4), sharex=True, gridspec_kw={"height_ratios": [2.2, 1, 1]})
ax[0].plot(p["t"], p["s"], color=NAVY, lw=1.4, label="mid price $s$")
ax[0].plot(p["t"], p["bid"], color=TEAL, lw=0.9, label="our bid")
ax[0].plot(p["t"], p["ask"], color=ORANGE, lw=0.9, label="our ask")
ax[0].set_ylabel("price"); ax[0].legend(ncol=3, frameon=False, loc="upper left")
ax[1].step(p["t"], p["q"], color=RED, lw=1.2, where="post"); ax[1].axhline(0, color="k", lw=0.6)
ax[1].set_ylabel("inventory $q$")
ax[2].plot(p["t"], p["pnl"], color=NAVY, lw=1.3); ax[2].set_ylabel("wealth (cash + $qs$)")
ax[2].set_xlabel("time $t$")
fig.tight_layout(); fig.savefig("figs/fig_path.png"); plt.close(fig)

# histograms
fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.9))
bins = np.linspace(min(a["pnl"].min(), b["pnl"].min()), max(a["pnl"].max(), b["pnl"].max()), 45)
ax[0].hist(b["pnl"], bins, color=ORANGE, alpha=0.6, label="symmetric")
ax[0].hist(a["pnl"], bins, color=NAVY, alpha=0.6, label="Avellaneda-Stoikov")
ax[0].set_xlabel("final PnL"); ax[0].set_ylabel("number of runs"); ax[0].legend(frameon=False)
qb = np.arange(-30, 31, 2)
ax[1].hist(b["q"], qb, color=ORANGE, alpha=0.6, label="symmetric")
ax[1].hist(a["q"], qb, color=NAVY, alpha=0.6, label="Avellaneda-Stoikov")
ax[1].set_xlabel("final inventory $q_T$"); ax[1].legend(frameon=False)
fig.tight_layout(); fig.savefig("figs/fig_hist.png"); plt.close(fig)

# decomposition
fig, ax = plt.subplots(figsize=(4.6, 2.9))
lab = ["Spread (edge)\nPnL", "Inventory\nPnL", "Total"]
xa = [R["E1"]["as"]["edge"], R["E1"]["as"]["inv_pnl"], R["E1"]["as"]["pnl"]["mean"]]
xs = [R["E1"]["sym"]["edge"], R["E1"]["sym"]["inv_pnl"], R["E1"]["sym"]["pnl"]["mean"]]
x = np.arange(3); ax.bar(x - 0.2, xs, 0.4, color=ORANGE, label="symmetric")
ax.bar(x + 0.2, xa, 0.4, color=NAVY, label="Avellaneda-Stoikov")
ax.set_xticks(x); ax.set_xticklabels(lab); ax.set_ylabel("mean PnL over runs"); ax.legend(frameon=False)
fig.tight_layout(); fig.savefig("figs/fig_decomp.png"); plt.close(fig)

# Monte-Carlo convergence of mean final PnL (AS)
x = a["pnl"]; n = np.arange(1, len(x) + 1)
rm = np.cumsum(x) / n
rs = np.sqrt(np.maximum(np.cumsum(x ** 2) / n - rm ** 2, 0) * n / np.maximum(n - 1, 1))
se = rs / np.sqrt(n)
fig, ax = plt.subplots(figsize=(6.4, 3.0))
ax.plot(n, rm, color=NAVY, lw=1.3, label="running mean of final PnL")
ax.fill_between(n[2:], (rm - 1.96 * se)[2:], (rm + 1.96 * se)[2:], color=NAVY, alpha=0.18,
                label="95% confidence band")
ax.axhline(rm[-1], color=GRAY, ls="--", lw=0.8)
ax.set_xscale("log"); ax.set_xlabel("number of Monte Carlo runs $N$"); ax.set_ylabel("estimated mean PnL")
ax.set_ylim(rm[-1] - 12, rm[-1] + 12); ax.legend(frameon=False)
fig.tight_layout(); fig.savefig("figs/fig_mc.png"); plt.close(fig)
R["MC"] = dict(se_100=float(se[99]), se_1000=float(se[-1]), mean_1000=float(rm[-1]))

# ------------------------------------------------------------------ E2: gamma sweep
rows = []
for g in [0.01, 0.05, 0.1, 0.5, 1.0]:
    sp = avg_as_spread(g, SIG, K, T)
    ra = simulate_level1("as", n_runs=N1, seed=21, gamma=g, sigma=SIG, k=K, A=A)
    rb = simulate_level1("sym", n_runs=N1, seed=21, half_spread=sp / 2, sigma=SIG, k=K, A=A)
    rows.append(dict(gamma=g, avg_spread=sp,
                     as_mean=float(ra["pnl"].mean()), as_std=float(ra["pnl"].std()), as_qstd=float(ra["q"].std()),
                     as_fills=float(ra["n_fills"].mean()),
                     sym_mean=float(rb["pnl"].mean()), sym_std=float(rb["pnl"].std()), sym_qstd=float(rb["q"].std()),
                     sym_fills=float(rb["n_fills"].mean())))
R["E2"] = rows
fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.9))
gs = [r["gamma"] for r in rows]
ax[0].plot(gs, [r["as_std"] for r in rows], "o-", color=NAVY, label="Avellaneda-Stoikov")
ax[0].plot(gs, [r["sym_std"] for r in rows], "s--", color=ORANGE, label="symmetric (same avg spread)")
ax[0].set_xscale("log"); ax[0].set_xlabel("risk aversion $\\gamma$"); ax[0].set_ylabel("std of final PnL")
ax[0].legend(frameon=False)
ax[1].plot(gs, [r["as_mean"] for r in rows], "o-", color=NAVY)
ax[1].plot(gs, [r["sym_mean"] for r in rows], "s--", color=ORANGE)
ax[1].set_xscale("log"); ax[1].set_xlabel("risk aversion $\\gamma$"); ax[1].set_ylabel("mean final PnL")
fig.tight_layout(); fig.savefig("figs/fig_gamma.png"); plt.close(fig)

# ------------------------------------------------------------------ E3: Level 2 (full order book)
N2 = 300
l2a = simulate_level2("as", n_runs=N2, seed=100, gamma=G, sigma=SIG, k=K, record_first=True)
l2b = simulate_level2("sym", n_runs=N2, seed=100, half_spread=hs, sigma=SIG, k=K)
diff = l2a["pnl"] - l2b["pnl"]
R["E3"] = dict(n_runs=N2,
               **{nm: dict(pnl=stats(r["pnl"]), q=stats(r["q"]), fills=float(r["n_fills"].mean()),
                           edge=float(r["edge"].mean()), inv_pnl=float(r["inv_pnl"].mean()))
                  for nm, r in (("as", l2a), ("sym", l2b))},
               diff_mean=float(diff.mean()), diff_se=float(diff.std(ddof=1) / math.sqrt(N2)))
fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.9))
bins = np.linspace(min(l2a["pnl"].min(), l2b["pnl"].min()), max(l2a["pnl"].max(), l2b["pnl"].max()), 35)
ax[0].hist(l2b["pnl"], bins, color=ORANGE, alpha=0.6, label="symmetric")
ax[0].hist(l2a["pnl"], bins, color=NAVY, alpha=0.6, label="Avellaneda-Stoikov")
ax[0].set_xlabel("final PnL (order-book simulator)"); ax[0].set_ylabel("number of runs"); ax[0].legend(frameon=False)
qb = np.arange(-30, 31, 2)
ax[1].hist(l2b["q"], qb, color=ORANGE, alpha=0.6); ax[1].hist(l2a["q"], qb, color=NAVY, alpha=0.6)
ax[1].set_xlabel("final inventory $q_T$")
fig.tight_layout(); fig.savefig("figs/fig_l2hist.png"); plt.close(fig)

p = l2a["path"]
fig, ax = plt.subplots(2, 1, figsize=(7.2, 4.6), sharex=True, gridspec_kw={"height_ratios": [2, 1]})
ax[0].plot(p["t"], p["s"], color=NAVY, lw=1.3, label="mid price")
ax[0].step(p["t"], p["bid"], color=TEAL, lw=0.8, where="post", label="our bid")
ax[0].step(p["t"], p["ask"], color=ORANGE, lw=0.8, where="post", label="our ask")
ax[0].legend(ncol=3, frameon=False, loc="upper left"); ax[0].set_ylabel("price")
ax[1].step(p["t"], p["q"], color=RED, lw=1.1, where="post"); ax[1].axhline(0, color="k", lw=0.6)
ax[1].set_ylabel("inventory"); ax[1].set_xlabel("time")
fig.tight_layout(); fig.savefig("figs/fig_l2path.png"); plt.close(fig)

# informed flow in the order-book simulator
inf = {}
for rate in [0.0, 20.0, 60.0]:
    ia = simulate_level2("as", n_runs=150, seed=500, gamma=G, sigma=SIG, k=K, informed_rate=rate)
    ib = simulate_level2("sym", n_runs=150, seed=500, half_spread=hs, sigma=SIG, k=K, informed_rate=rate)
    inf[str(rate)] = dict(as_mean=float(ia["pnl"].mean()), as_std=float(ia["pnl"].std()),
                          sym_mean=float(ib["pnl"].mean()), sym_std=float(ib["pnl"].std()),
                          as_inv=float(ia["inv_pnl"].mean()), sym_inv=float(ib["inv_pnl"].mean()))
R["E3_informed"] = inf

# ------------------------------------------------------------------ E4: toy adverse selection (Level 1)
etas = [0.0, 0.05, 0.1, 0.2, 0.3]
adv = []
for e in etas:
    ra = simulate_level1("as", n_runs=N1, seed=31, gamma=G, sigma=SIG, k=K, A=A, eta=e)
    rb = simulate_level1("sym", n_runs=N1, seed=31, half_spread=hs, sigma=SIG, k=K, A=A, eta=e)
    adv.append(dict(eta=e, as_mean=float(ra["pnl"].mean()), sym_mean=float(rb["pnl"].mean()),
                    as_std=float(ra["pnl"].std()), sym_std=float(rb["pnl"].std())))
R["E4"] = adv
fig, ax = plt.subplots(figsize=(4.8, 3.0))
ax.plot(etas, [r["as_mean"] for r in adv], "o-", color=NAVY, label="Avellaneda-Stoikov")
ax.plot(etas, [r["sym_mean"] for r in adv], "s--", color=ORANGE, label="symmetric")
ax.axhline(0, color="k", lw=0.6); ax.set_xlabel("adverse-selection shift $\\eta$ (price units per fill)")
ax.set_ylabel("mean final PnL"); ax.legend(frameon=False)
fig.tight_layout(); fig.savefig("figs/fig_adverse.png"); plt.close(fig)

# ------------------------------------------------------------------ E5: calibrate lambda(delta) from the order book
ticks = [2, 4, 6, 8, 10, 12, 14, 16, 18, 20]
d, rate_hat = [], []
for t_ in ticks:
    r_, f_ = measure_fill_rate(t_, n_steps=20000)
    d.append(t_ * 0.1); rate_hat.append(r_)
d, rate_hat = np.array(d), np.array(rate_hat)
slope, intercept = np.polyfit(d, np.log(rate_hat), 1)
R["E5"] = dict(delta=d.tolist(), rate=rate_hat.tolist(), k_hat=float(-slope), A_hat=float(math.exp(intercept)))
fig, ax = plt.subplots(1, 2, figsize=(7.2, 3.0))
dd = np.linspace(0.1, 2.1, 100)
ax[0].plot(dd, A * np.exp(-K * dd), color=NAVY, label="theory $140\\,e^{-1.5\\delta}$")
ax[0].plot(d, rate_hat, "o", color=ORANGE, label="measured in order-book sim")
ax[0].set_xlabel("distance $\\delta$ from mid"); ax[0].set_ylabel("fill rate $\\lambda(\\delta)$")
ax[0].legend(frameon=False)
ax[1].plot(d, np.log(rate_hat), "o", color=ORANGE)
ax[1].plot(dd, intercept + slope * dd, color=NAVY, label=f"fit: ln A = {intercept:.2f}, k = {-slope:.2f}")
ax[1].set_xlabel("distance $\\delta$"); ax[1].set_ylabel("$\\ln\\,\\lambda(\\delta)$"); ax[1].legend(frameon=False)
fig.tight_layout(); fig.savefig("figs/fig_calib.png"); plt.close(fig)

json.dump(R, open("results.json", "w"), indent=1)
print(json.dumps(R, indent=1)[:6000])
