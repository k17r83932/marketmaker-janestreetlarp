"""volatility.py -- changing market volatility, and a way for the strategy to measure it.

Two small classes, both written so they work for one path (size=None) or for many paths at once
(size=n_runs, used by the vectorised Level-1 simulator).

* RegimeVolatility  -- the REAL (hidden) volatility of the market: calm most of the time,
                       with random "storms" in which prices become several times jumpier.
* EwmaVolatility    -- what the market maker can actually SEE: an exponentially weighted moving
                       average of squared price changes, i.e. a running estimate of sigma.
"""
import numpy as np

# A sensible default storm: 3x jumpier, about 2 storms per day (of 200 steps), each lasting ~10% of a day.
DEFAULT_REGIME = dict(stress_mult=3.0, p_enter=0.01, p_exit=0.05)


class RegimeVolatility:
    """Two-state market. Each time step a calm market becomes stormy with probability `p_enter`,
    and a stormy market calms down with probability `p_exit`. A day always starts calm."""

    def __init__(self, sigma, stress_mult=3.0, p_enter=0.01, p_exit=0.05, size=None):
        self.calm, self.stormy = sigma, sigma * stress_mult
        self.p_enter, self.p_exit = p_enter, p_exit
        self.stressed = np.zeros(size if size else (), dtype=bool)

    @property
    def sigma(self):
        """The true volatility right now (what the price actually uses)."""
        return np.where(self.stressed, self.stormy, self.calm)

    def step(self, rng):
        """Possibly switch regime. Call once per time step, after the price has moved."""
        u = rng.random(self.stressed.shape)
        self.stressed = np.where(self.stressed, u >= self.p_exit, u < self.p_enter)

    # --- long-run facts, handy for choosing a fair 'fixed' volatility to compare against ---
    @property
    def stress_fraction(self):
        """Long-run fraction of time spent in a storm."""
        return self.p_enter / (self.p_enter + self.p_exit)

    @property
    def average_sigma(self):
        """The single constant sigma with the same long-run variance as the regime model."""
        f = self.stress_fraction
        return float(np.sqrt((1 - f) * self.calm ** 2 + f * self.stormy ** 2))


class EwmaVolatility:
    """Running volatility estimate:  var <- decay * var + (1 - decay) * (price change)^2 / dt.

    `decay` close to 1 = long memory (smooth but slow to notice a storm);
    `decay` smaller    = short memory (reacts fast but is noisier).
    With decay 0.95 the estimate effectively looks back about 20 steps."""

    def __init__(self, sigma0, decay=0.95, floor=0.1, size=None):
        self.decay, self.floor = decay, floor
        self.var = np.full(size if size else (), float(sigma0) ** 2)

    @property
    def sigma(self):
        return np.sqrt(np.maximum(self.var, self.floor ** 2))

    def update(self, price_change, dt):
        self.var = self.decay * self.var + (1 - self.decay) * price_change ** 2 / dt


# ============================================================================ daily-bar estimators
def yang_zhang(open_, high, low, close, window=10, overnight=True):
    """Rolling Yang-Zhang volatility from daily open/high/low/close bars (Yang and Zhang, 2000).

    Returns an array the same length as the inputs, in LOG-return units per day. The first `window`
    entries are NaN (the estimate for day t uses days t-window+1 .. t and the close of day t-window,
    because the overnight return of the first day needs the previous close).

        sigma^2 = sigma_overnight^2 + k * sigma_open_to_close^2 + (1 - k) * sigma_RS^2
        k       = 0.34 / (1.34 + (window + 1) / (window - 1))

    * sigma_overnight^2    sample variance of ln(open_t / close_{t-1})        (gaps between days)
    * sigma_open_to_close^2 sample variance of ln(close_t / open_t)           (the day's drift and noise)
    * sigma_RS^2           mean Rogers-Satchell term  ln(H/C) ln(H/O) + ln(L/C) ln(L/O)   (uses the range)
    It is unbiased when prices drift, handles overnight gaps, and is far more efficient than using
    closing prices alone.

    overnight=False drops the overnight-gap term, leaving the INTRADAY part (open to close). Use that for
    a strategy that is flat overnight: gaps between days do not hurt it, so they should not widen its quotes."""
    o, h, l, c = (np.asarray(x, float) for x in (open_, high, low, close))
    if window < 2:
        raise ValueError("window must be at least 2")
    n = len(c)
    out = np.full(n, np.nan)
    gaps = np.log(o[1:] / c[:-1])                           # index t-1 <-> day t
    open_close = np.log(c / o)
    rs = np.log(h / c) * np.log(h / o) + np.log(l / c) * np.log(l / o)
    k = 0.34 / (1.34 + (window + 1) / (window - 1))
    for t in range(window, n):
        days = slice(t - window + 1, t + 1)
        var = ((np.var(gaps[t - window:t], ddof=1) if overnight else 0.0) + k * np.var(open_close[days], ddof=1)
               + (1 - k) * np.mean(rs[days]))
        out[t] = np.sqrt(max(var, 0.0))
    return out


def close_to_close(close, window=10):
    """Rolling standard deviation of daily log returns, the naive estimator (for comparison)."""
    c = np.asarray(close, float)
    r = np.diff(np.log(c))
    out = np.full(len(c), np.nan)
    for t in range(window, len(c)):
        out[t] = np.std(r[t - window:t], ddof=1)
    return out
