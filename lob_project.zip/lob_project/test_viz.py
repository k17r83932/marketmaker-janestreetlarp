"""test_viz.py -- tests for the chart helpers and the chart engine (run:  python test_viz.py)"""
import json
import numpy as np
import viz

THEME = dict(bg="#101821", raised="#1D2935", line="#2B3A49", control="#62788F", text="#E7EDF3", muted="#A3B1BF",
             accent="#5E9BCB", shadow="rgba(0,0,0,.4)")


def test_kde_integrates_to_one_and_peaks_near_the_mean():
    x = np.random.default_rng(0).normal(5, 2, 2000)
    g, d = viz.kde(x, lo=-5, hi=15)
    assert abs(np.trapezoid(d, g) - 1) < 0.02 and abs(g[np.argmax(d)] - 5) < 0.6


def test_thin_keeps_the_ends_and_the_limit():
    x = np.arange(1000.0)
    tx, ty = viz.thin(x, x ** 2, limit=100)
    assert len(tx) <= 100 and tx[0] == 0 and tx[-1] == 999 and np.allclose(ty, tx ** 2)


def test_every_helper_produces_json_and_consistent_lengths():
    t = np.linspace(0, 1, 500)
    series = [viz.line("a", t, t, "#fff"), viz.steps("b", t, t, "#fff"), viz.area("c", t, t, "#fff"),
              viz.band("d", t, t - 1, t + 1, "#fff"), viz.points("e", t[:5], t[:5], "#fff"), viz.hline(0.5, "#fff"),
              viz.bars("f", [0, 1], [1, 2], "#fff", colors=["#111", "#222"])]
    spec = viz.spec(series, height=200)
    json.dumps(spec)
    for s in series:
        if s["type"] not in ("hline",):
            assert len(s["x"]) == len(s["y"])
    band = series[3]
    assert len(band["x"]) == len(band["y0"]) == len(band["y"]) <= 360


def test_heatmap_spec_shape_and_range():
    z = np.arange(12.0).reshape(3, 4)
    hm = viz.heatmap(np.arange(4), np.arange(3), z, ["#000000", "#ffffff"])
    assert len(hm["z"]) == 3 and len(hm["z"][0]) == 4 and hm["zmin"] == 0 and hm["zmax"] == 11
    json.dumps(hm)


def test_template_placeholders_are_all_filled():
    html = (viz.TEMPLATE.replace("__SPEC__", json.dumps(viz.spec([], height=100))).replace("__PREV__", "null")
            .replace("__THEME__", json.dumps(THEME)).replace("__STAMP__", "0"))
    assert "__" not in html.replace("__proto__", "")


def test_engine_draws_curves_without_script_errors():
    """Load a chart in a real browser, if one is installed, and check that it draws and morphs without errors."""
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        return
    t = np.linspace(0, 1, 120)
    first = viz.spec([viz.band("Spread", t, np.sin(6 * t) - .3, np.sin(6 * t) + .3, "#86B6DE"), viz.line("Price", t, np.sin(6 * t), "#fff")], height=240)
    second = viz.spec([viz.band("Spread", t, np.cos(5 * t) - .3, np.cos(5 * t) + .3, "#86B6DE"), viz.line("Price", t, np.cos(5 * t), "#fff")], height=240)
    html = (viz.TEMPLATE.replace("__SPEC__", json.dumps(second)).replace("__PREV__", json.dumps(first))
            .replace("__THEME__", json.dumps(THEME)).replace("__STAMP__", "9999999999999"))
    import os, tempfile
    path = os.path.join(tempfile.mkdtemp(), "c.html")
    open(path, "w").write(html)
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": 700, "height": 400})
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.on("console", lambda m: errors.append(m.text) if m.type == "error" and "ERR_NAME_NOT_RESOLVED" not in m.text else None)
        page.goto("file://" + path)
        page.wait_for_timeout(1500)
        assert page.evaluate("document.querySelectorAll('svg path').length") >= 2        # the band and the line
        assert page.evaluate("document.querySelectorAll('.lgi').length") == 2
        browser.close()
    assert not errors, errors


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print("PASS", t.__name__)
    print(f"All {len(tests)} tests passed.")
