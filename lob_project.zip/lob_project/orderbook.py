"""orderbook.py -- a limit order book with price-time priority.

Prices are INTEGERS (a count of ticks) so there are no floating-point surprises.
Side is the string "bid" (buy) or "ask" (sell).
"""
from collections import deque, namedtuple
import heapq

# One Fill is created every time an incoming (aggressor) order trades against a resting order.
Fill = namedtuple("Fill", "price qty resting_id resting_owner resting_side aggressor_owner")


class Order:
    __slots__ = ("id", "side", "price", "qty", "owner", "alive")

    def __init__(self, oid, side, price, qty, owner):
        self.id, self.side, self.price, self.qty, self.owner = oid, side, price, qty, owner
        self.alive = True            # becomes False when cancelled or completely filled


class OrderBook:
    def __init__(self):
        self.levels = {"bid": {}, "ask": {}}   # price -> deque of resting Orders (FIFO queue)
        self.heaps = {"bid": [], "ask": []}    # bids: heap of -price (max-heap); asks: heap of +price
        self.orders = {}                       # id -> resting Order (for O(1) cancel)
        self._next_id = 1

    # ------------------------------------------------------------------ queries
    def _clean_best(self, side):
        """Return the best live price on `side`, discarding dead orders / empty levels."""
        heap, lv = self.heaps[side], self.levels[side]
        while heap:
            price = -heap[0] if side == "bid" else heap[0]
            queue = lv[price]
            while queue and not queue[0].alive:      # lazily drop cancelled orders
                queue.popleft()
            if queue:
                return price
            del lv[price]                            # level is empty -> remove it
            heapq.heappop(heap)
        return None

    def best_bid(self):
        return self._clean_best("bid")

    def best_ask(self):
        return self._clean_best("ask")

    def mid(self):
        b, a = self.best_bid(), self.best_ask()
        return None if b is None or a is None else (b + a) / 2

    def spread(self):
        b, a = self.best_bid(), self.best_ask()
        return None if b is None or a is None else a - b

    def depth(self, side, n=5):
        """Top-n price levels as a list of (price, total_live_quantity), best first."""
        prices = sorted(self.levels[side], reverse=(side == "bid"))
        out = []
        for p in prices:
            qty = sum(o.qty for o in self.levels[side][p] if o.alive)
            if qty > 0:
                out.append((p, qty))
            if len(out) == n:
                break
        return out

    # ------------------------------------------------------------------ orders
    def add_limit(self, side, price, qty, owner="anon"):
        """Submit a limit order. Trades immediately if it crosses; any remainder rests.
        Returns (order_id, list_of_fills)."""
        oid = self._next_id
        self._next_id += 1
        order = Order(oid, side, price, qty, owner)
        fills = self._match(order, limit_price=price)
        if order.qty > 0:                            # rest the unfilled remainder
            lv = self.levels[side]
            if price not in lv:
                lv[price] = deque()
                heapq.heappush(self.heaps[side], -price if side == "bid" else price)
            lv[price].append(order)
            self.orders[oid] = order
        else:
            order.alive = False
        return oid, fills

    def add_market(self, side, qty, owner="anon"):
        """Submit a market order: trades at any price; the unfilled remainder is discarded."""
        order = Order(0, side, None, qty, owner)
        return self._match(order, limit_price=None)

    def cancel(self, oid):
        order = self.orders.pop(oid, None)
        if order is None:
            return False
        order.alive = False
        return True

    # ------------------------------------------------------------------ matching engine
    def _match(self, order, limit_price):
        fills = []
        opp = "ask" if order.side == "bid" else "bid"
        lv = self.levels[opp]
        while order.qty > 0:
            best = self._clean_best(opp)
            if best is None:
                break                                 # nothing left to trade against
            if limit_price is not None:               # limit orders respect their price
                if order.side == "bid" and best > limit_price:
                    break
                if order.side == "ask" and best < limit_price:
                    break
            queue = lv[best]
            while order.qty > 0 and queue:
                resting = queue[0]
                if not resting.alive:
                    queue.popleft()
                    continue
                traded = min(order.qty, resting.qty)
                order.qty -= traded
                resting.qty -= traded
                fills.append(Fill(best, traded, resting.id, resting.owner,
                                  resting.side, order.owner))
                if resting.qty == 0:
                    resting.alive = False
                    queue.popleft()
                    self.orders.pop(resting.id, None)
        return fills
