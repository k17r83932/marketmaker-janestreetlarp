"""test_orderbook.py -- unit tests for orderbook.py (run:  python test_orderbook.py)"""
from orderbook import OrderBook


def test_empty_book():
    b = OrderBook()
    assert b.best_bid() is None and b.best_ask() is None and b.mid() is None


def test_best_prices_spread_mid():
    b = OrderBook()
    b.add_limit("bid", 99, 10); b.add_limit("bid", 98, 5)
    b.add_limit("ask", 101, 7); b.add_limit("ask", 102, 3)
    assert b.best_bid() == 99 and b.best_ask() == 101
    assert b.spread() == 2 and b.mid() == 100.0
    assert b.depth("bid", 2) == [(99, 10), (98, 5)]
    assert b.depth("ask", 2) == [(101, 7), (102, 3)]


def test_time_priority_within_a_level():
    b = OrderBook()
    first, _ = b.add_limit("bid", 100, 5, "A")
    second, _ = b.add_limit("bid", 100, 5, "B")
    fills = b.add_market("ask", 5, "taker")
    assert len(fills) == 1 and fills[0].resting_id == first and fills[0].resting_owner == "A"
    assert b.depth("bid") == [(100, 5)]            # B's order untouched


def test_price_priority_and_partial_fill():
    b = OrderBook()
    b.add_limit("ask", 102, 10, "far"); b.add_limit("ask", 101, 4, "near")
    fills = b.add_market("bid", 6, "taker")
    assert [(f.price, f.qty, f.resting_owner) for f in fills] == [(101, 4, "near"), (102, 2, "far")]
    assert b.depth("ask") == [(102, 8)]            # far order partially filled


def test_market_order_sweeps_levels_and_leftover_discarded():
    b = OrderBook()
    b.add_limit("ask", 101, 5); b.add_limit("ask", 102, 5); b.add_limit("ask", 103, 5)
    fills = b.add_market("bid", 100)
    assert sum(f.qty for f in fills) == 15 and b.best_ask() is None


def test_crossing_limit_order_trades_then_rests():
    b = OrderBook()
    b.add_limit("ask", 101, 4); b.add_limit("ask", 102, 4); b.add_limit("ask", 103, 4)
    oid, fills = b.add_limit("bid", 102, 10, "me")
    assert [(f.price, f.qty) for f in fills] == [(101, 4), (102, 4)]   # trades at RESTING prices
    assert b.best_bid() == 102 and b.depth("bid") == [(102, 2)]        # remainder rests
    assert b.best_ask() == 103


def test_cancel():
    b = OrderBook()
    oid, _ = b.add_limit("bid", 100, 5, "A")
    b.add_limit("bid", 100, 5, "B")
    assert b.cancel(oid) is True and b.cancel(oid) is False
    fills = b.add_market("ask", 3, "taker")
    assert fills[0].resting_owner == "B"
    assert b.depth("bid") == [(100, 2)]


def test_cancel_last_order_at_best_moves_best():
    b = OrderBook()
    oid, _ = b.add_limit("bid", 100, 5); b.add_limit("bid", 99, 5)
    b.cancel(oid)
    assert b.best_bid() == 99


def test_market_order_on_empty_side():
    b = OrderBook()
    assert b.add_market("bid", 10) == []


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print("PASS", t.__name__)
    print(f"All {len(tests)} tests passed.")
