# Market Maker Simulator

A limit order book market maker, tested against simulated markets, with a minimal Streamlit interface.

## What is in the box
| File | Purpose |
|---|---|
| `app.py` | The interface: Simulator, Compare, Backtest (with tear sheet), Method |
| `orderbook.py` | Limit order book and matching engine (price-time priority) |
| `sim.py` | Strategies (fixed gap, textbook, exact, volatility-aware) and the two simulators |
| `optimal.py` | Exact optimal quotes of the Avellaneda-Stoikov model, tabulated over volatility |
| `volatility.py` | Volatility storms, the running (EWMA) estimate, and the Yang-Zhang estimator |
| `hawkes.py` | Synthetic market: Hawkes order flow, price impact, volatility clustering, overnight gaps |
| `backtest.py` | Calibrates on early days, then trades the rest of a Hawkes history with no look-ahead |
| `tearsheet.py` | Sharpe, Sortino, drawdown, PnL decomposition, inventory risk |
| `metrics.py` | Certainty-equivalent score used on the Compare page |
| `test_*.py` | 50 automated tests |
| `run_*.py`, `demo.py` | Reproduce the reported experiments; draw one day from the command line |
| `.streamlit/config.toml` | Theme colours from DESIGN.md |

## Run it
1. Install Python 3.9 or newer from https://www.python.org/downloads/ (on Windows tick "Add Python to PATH").
2. Put all files in one folder, keeping the `.streamlit` folder inside it.
3. Open a terminal in that folder and install the libraries:
   ```
   pip install -r requirements.txt
   ```
4. Check everything works (each line should end with "tests passed"):
   ```
   python test_orderbook.py
   python test_optimal.py
   python test_volatility.py
   python test_yang_zhang.py
   python test_hawkes.py
   python test_tearsheet.py
   ```
5. Start the app:
   ```
   python -m streamlit run app.py
   ```
   It opens at http://localhost:8501. Press Ctrl+C in the terminal to stop it.
   (Or double-click `start_app.bat` on Windows, or run `bash start_app.sh` on Mac or Linux.)

## Using it well
1. **Backtest page first.** Press *Run backtest* with the defaults (about 5 seconds). Read the warning, then the market panel: order clustering above 1 and positive buy/sell persistence show the Hawkes flow is doing its job.
2. In the **tear sheet**, switch strategies with the radio buttons and compare the PnL decomposition, the inventory risk panel and the table at the bottom.
3. Open **Market realism** and set *Order clustering* to 0. Orders become random and the history loses its bursts. Rerun and see what changes.
4. Change the **history seed** and rerun a few times. One history proves little; the differences between strategies that survive many seeds are the real ones (`python run_backtest_experiment.py` does 8 histories at once).
5. The **Simulator** and **Compare** pages use the textbook random-walk market, with optional volatile periods. The settings rail on the left applies to them and to the caution setting in the backtest.

## Notes
- Fonts and the icon set load from Google Fonts, so the first load needs internet. Without it the app falls back to system fonts.
- Light or dark follows your system setting. To force one, use the menu at the top right, then Settings.
- Sharpe and Sortino here are far higher than anything real: no fees, no competing market makers, perfect refilling of the book. Compare strategies with each other only.
- `DESIGN.md` (in the `design` folder) is the style guide the interface follows.

## Reproduce the experiments
```
python run_backtest_experiment.py     # 8 Hawkes histories, writes results_backtest.json
python run_volatility_experiment.py   # exact vs textbook, and the volatility-aware strategy in storms
python run_experiments.py             # the original experiments (takes a few minutes)
```
