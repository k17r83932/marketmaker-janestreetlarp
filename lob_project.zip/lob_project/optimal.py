"""optimal.py -- the EXACT optimal quotes of the Avellaneda-Stoikov model (no small-q approximation).

Background (Chapter 10 of the guide): the best quotes are
        bid distance  = L - [phi(q+1) - phi(q)]            ask distance = L + [phi(q) - phi(q-1)]
with L = ln(1 + gamma/k) / gamma, where phi(q, t) solves a system of ODEs, one per inventory q:

        phi_t = (1/2) gamma sigma^2 q^2 - C [ exp(k(phi(q+1)-phi(q))) + exp(k(phi(q-1)-phi(q))) ],
        phi(q, T) = 0,        C = A / (k + gamma) * (1 + gamma/k)^(-k/gamma).

Substituting g_q = exp(k * phi_q) turns this into a LINEAR system   g' = M g   with
        M[q, q] = (1/2) k gamma sigma^2 q^2,        M[q, q+-1] = -k C,        g(T) = 1.
M is symmetric, so  g(t) = exp(-M tau) 1  (tau = T - t)  is computed with an eigen-decomposition.
Inventory is limited to |q| <= q_max (no bid at +q_max, no ask at -q_max).

Because the quotes depend on (sigma, tau, q) only, we tabulate them once for a grid of sigma values
and then look them up (with interpolation in sigma) while simulating. That is how the strategy can
react to a volatility estimate that changes from step to step.
"""
import numpy as np

NO_QUOTE = 50.0          # a distance so large that the quote is never filled (the side is switched off)


class ExactQuoteTable:
    def __init__(self, gamma, k, A, T, n_steps, q_max=20, sigma_grid=None):
        self.gamma, self.k, self.A, self.T, self.n_steps, self.q_max = gamma, k, A, T, n_steps, q_max
        self.sigma_grid = np.geomspace(0.25, 32.0, 48) if sigma_grid is None else np.asarray(sigma_grid, float)
        self.L = np.log1p(gamma / k) / gamma
        C = A / (k + gamma) * (1 + gamma / k) ** (-k / gamma)
        qs = np.arange(-q_max, q_max + 1)
        taus = T - np.arange(n_steps + 1) * (T / n_steps)           # time left at the start of each step
        n_q = len(qs)
        self.bid = np.empty((len(self.sigma_grid), n_steps + 1, n_q))
        self.ask = np.empty_like(self.bid)
        off = -k * C * (np.eye(n_q, k=1) + np.eye(n_q, k=-1))        # tridiagonal off-diagonal part of M
        for a, sigma in enumerate(self.sigma_grid):
            M = np.diag(0.5 * k * gamma * sigma ** 2 * qs ** 2) + off
            w, V = np.linalg.eigh(M)
            coeff = V.T @ np.ones(n_q)
            for i, tau in enumerate(taus):
                g = V @ (np.exp(-(w - w.min()) * tau) * coeff)        # shifted exponent avoids overflow;
                g = np.maximum(g, 1e-300)                             # the common factor cancels in ratios
                up = np.append(g[1:] / g[:-1], 0.0)                   # g_{q+1} / g_q   (0 beyond +q_max)
                down = np.append(0.0, g[1:] / g[:-1])                 # g_q / g_{q-1}   (undefined at -q_max)
                with np.errstate(divide="ignore"):
                    bid = self.L - np.log(up) / k
                    ask = self.L + np.log(down) / k
                self.bid[a, i] = np.where(up > 0, bid, NO_QUOTE)      # no bid at +q_max
                self.ask[a, i] = np.where(down > 0, ask, NO_QUOTE)    # no ask at -q_max

    def distances(self, step, q, sigma):
        """Bid and ask distances from the mid for inventory q (array or int), a step index and a
        volatility sigma (array or float). Linear interpolation between the tabulated sigmas."""
        qi = np.clip(np.asarray(q, dtype=int), -self.q_max, self.q_max) + self.q_max
        s = np.clip(np.asarray(sigma, dtype=float), self.sigma_grid[0], self.sigma_grid[-1])
        hi = np.clip(np.searchsorted(self.sigma_grid, s), 1, len(self.sigma_grid) - 1)
        lo = hi - 1
        w = (s - self.sigma_grid[lo]) / (self.sigma_grid[hi] - self.sigma_grid[lo])
        step = min(step, self.n_steps)
        bid = (1 - w) * self.bid[lo, step, qi] + w * self.bid[hi, step, qi]
        ask = (1 - w) * self.ask[lo, step, qi] + w * self.ask[hi, step, qi]
        return bid, ask
