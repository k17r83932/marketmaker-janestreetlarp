"""tearsheet.py -- performance report for one strategy from a backtest.

Everything is computed from the daily results in backtest.run_backtest():
  * summary        average and spread of daily PnL, Sharpe, Sortino, drawdown, hit rate, tail loss
  * decomposition  PnL = spread capture + adverse selection + inventory carry   (adds up exactly)
  * inventory      how many shares the market maker held, for how long, and what that risk cost
  * series         cumulative PnL (total and by component) and drawdown, for charts

Ratios use daily PnL with a constant capital base (so they do not depend on the unit of money) and are
annualised with 252 trading days.
"""
import numpy as np

TRADING_DAYS = 252


def sharpe_ratio(x, periods=TRADING_DAYS):
    """Mean over standard deviation of daily PnL, annualised."""
    x = np.asarray(x, float)
    sd = x.std(ddof=1)
    return float(x.mean() / sd * np.sqrt(periods)) if sd > 0 else float("nan")


def sharpe_standard_error(x, periods=TRADING_DAYS):
    """Approximate standard error of the annualised Sharpe ratio for independent daily results (Lo, 2002)."""
    x = np.asarray(x, float)
    sd = x.std(ddof=1)
    if sd == 0:
        return float("nan")
    daily = x.mean() / sd
    return float(np.sqrt((1 + 0.5 * daily ** 2) / len(x)) * np.sqrt(periods))


def sortino_ratio(x, periods=TRADING_DAYS, target=0.0):
    """Mean excess PnL over downside deviation (only days below `target` count as risk), annualised.
    Infinite when there is no losing day."""
    x = np.asarray(x, float)
    downside = np.sqrt(np.mean(np.minimum(x - target, 0.0) ** 2))
    return float((x.mean() - target) / downside * np.sqrt(periods)) if downside > 0 else float("inf")


def drawdown_series(x):
    """Peak-to-trough fall of cumulative PnL after each day (>= 0), starting from zero."""
    cum = np.cumsum(np.asarray(x, float))
    peak = np.maximum.accumulate(np.concatenate([[0.0], cum]))[1:]
    return peak - cum


def _variance_share(component, total):
    """Share of the variance of total PnL attributable to a component: Cov(component, total) / Var(total).
    The shares of components that add up to the total add up to exactly 1."""
    v = np.var(total, ddof=1)
    return float(np.cov(component, total, ddof=1)[0, 1] / v) if v > 0 else float("nan")


def tear_sheet(strategy_results, q_limit=20, periods=TRADING_DAYS, sortino_target=0.0):
    """strategy_results: one entry of run_backtest(...)["strategies"].

    sortino_target: the daily PnL below which a day counts as a bad day. A number, or "half_mean" for half of
    this strategy's own average day (useful when losing days are rare, which makes the target-zero ratio infinite)."""
    pnl = np.asarray(strategy_results["pnl"], float)
    edge = np.asarray(strategy_results["edge"], float)
    markout = np.asarray(strategy_results["markout"], float)
    inv = np.asarray(strategy_results["inv_pnl"], float)
    q = np.asarray(strategy_results["q_path"], float)
    carry = inv - markout                                   # the part of inventory PnL not explained by the markout

    target = 0.5 * pnl.mean() if sortino_target == "half_mean" else float(sortino_target)
    n_tail = max(1, int(np.ceil(0.05 * len(pnl))))
    dd = drawdown_series(pnl)
    summary = {
        "days": len(pnl), "total_pnl": float(pnl.sum()), "mean_daily": float(pnl.mean()),
        "std_daily": float(pnl.std(ddof=1)), "sharpe": sharpe_ratio(pnl, periods),
        "sharpe_se": sharpe_standard_error(pnl, periods), "sortino": sortino_ratio(pnl, periods, target),
        "sortino_target": target, "sortino_zero_target": sortino_ratio(pnl, periods, 0.0),
        "downside_days": float((pnl < target).mean()),
        "max_drawdown": float(dd.max()), "win_rate": float((pnl > 0).mean()), "best_day": float(pnl.max()),
        "worst_day": float(pnl.min()), "cvar_5": float(np.sort(pnl)[:n_tail].mean()),
        "fills_per_day": float(np.mean(strategy_results["fills"])),
    }
    parts = {"spread": edge, "adverse_selection": markout, "inventory_carry": carry}
    decomposition = {name: {"total": float(v.sum()), "per_day": float(v.mean()), "std": float(v.std(ddof=1)),
                            "variance_share": _variance_share(v, pnl)} for name, v in parts.items()}
    decomposition["total"] = {"total": float(pnl.sum()), "per_day": float(pnl.mean()), "std": float(pnl.std(ddof=1)),
                              "variance_share": 1.0}
    inventory = {
        "mean_abs": float(np.abs(q).mean()), "rms": float(np.sqrt((q ** 2).mean())), "peak_abs": float(np.abs(q).max()),
        "pct_flat": float((q == 0).mean()), "pct_at_limit": float((np.abs(q) >= q_limit).mean()),
        "end_of_day_mean_abs": float(np.abs(q[:, -1]).mean()), "inv_pnl_std": float(inv.std(ddof=1)),
        "inv_pnl_variance_share": _variance_share(inv, pnl),
    }
    series = {"cum_pnl": np.cumsum(pnl), "drawdown": dd, "cum_spread": np.cumsum(edge),
              "cum_adverse": np.cumsum(markout), "cum_carry": np.cumsum(carry)}
    return {"summary": summary, "decomposition": decomposition, "inventory": inventory, "series": series}


def tear_sheets(backtest_result, periods=TRADING_DAYS, sortino_target=0.0):
    """A tear sheet for every strategy in a backtest."""
    q_limit = backtest_result["config"].q_limit
    return {name: tear_sheet(res, q_limit, periods, sortino_target) for name, res in backtest_result["strategies"].items()}
