# DESIGN.md: Market Maker Simulator

Single source of truth for the visual system and interface of the Market Maker Simulator.
Status: **draft for approval**. No full pages are built until this file is approved.
Companion file: `design-preview.html` (tokens, components and the hero, rendered).

---

## 1. Product definition

| Item | Decision |
|---|---|
| Product | A Python simulator of a market maker working a limit order book, with a Streamlit interface |
| Audience | Recruiters and academic reviewers looking at a student portfolio piece |
| Primary job of the interface | Let a reviewer see, within one minute, that the work is rigorous: a correct model, verified code, results with their source stated |
| Mood | Dense and technical, a data desk. Calm, exact, no decoration |
| Front end | Streamlit, restyled with a theme file and injected CSS |
| Themes | Dark by default, light available (toggle) |
| Accent | Steel blue |
| Memorable element | One thing: the simulated trading day, plotted large in the hero. Everything else stays quiet |

### What a reviewer must be able to do
1. Understand what the project is in one screen (hero).
2. Watch one simulated day and read the chart without a legend hunt.
3. Compare strategies with a table whose numbers say where they came from.
4. See a backtest on real daily prices, with a plain statement of what is real and what is simulated.
5. Read the method (model, derivation, limits) in one place.

---

## 2. Principles

1. **Structure carries information.** Borders, rules and panels exist to group related data, never to decorate. If a rule does not separate two things, remove it.
2. **One loud element.** The hero chart is the only large visual moment. Everything else is flat and quiet.
3. **Numbers come with provenance.** Every figure on screen has a source line (what produced it, seed or data range, date). No unsourced numbers anywhere.
4. **Density without clutter.** Small type, tight spacing, strict alignment on a 4 px grid. Whitespace is used to separate groups, not to fill the screen.
5. **Left-aligned, ragged-right.** All body copy is left-aligned with a maximum line length of 68 characters.
6. **Sentence case everywhere.** No all-caps labels, no tracked-out eyebrows, no numbered markers unless the content is a real sequence.
7. **Colour means something.** Steel blue marks what you can act on. Series colours mark data (the volatility series uses a lighter steel blue, inside charts only, and is distinguished by context and line style). Semantic colours mark status. Roles never swap.

---

## 3. Hard constraints (do not violate)

- No purple-to-blue gradients. **No gradients at all.**
- No generic SaaS hero (centred headline, two buttons, logo strip) and no default three-card feature grid.
- Main font is **not** Inter or Fraunces.
- **No emojis anywhere in the interface.** Icons come from one set only (section 4.9).
- No centred-everything layouts. Content sits on an intentional 12-column grid; body copy is left-aligned.
- No fake testimonials, fake metrics or generic filler copy. Placeholders are written as `[LIKE THIS]` and listed in section 10.
- Also avoid: arrows appended to button text, middle-dot meta strings, spaced em-dash labels, identical rounded cards with matching soft shadows.

---

## 4. Tokens

All tokens are defined once as CSS custom properties (and mirrored in the Streamlit theme file, section 9).

### 4.1 Colour: dark theme (default)

| Token | Hex | Use |
|---|---|---|
| `--bg` | `#101821` | Page background |
| `--surface` | `#16202B` | Panels, table body, inputs |
| `--surface-raised` | `#1D2935` | Table header, hover rows, popovers |
| `--line` | `#2B3A49` | Dividers and panel borders |
| `--line-control` | `#62788F` | Borders of interactive controls (meets 3:1) |
| `--text` | `#E7EDF3` | Primary text |
| `--text-muted` | `#A3B1BF` | Secondary text, captions, axis labels |
| `--text-faint` | `#7A8997` | Disabled text and non-essential hints only |
| `--accent` | `#5E9BCB` | Primary button fill, selected state, focus |
| `--accent-hover` | `#74AEDB` | Hover |
| `--accent-press` | `#4C88B8` | Pressed |
| `--accent-text` | `#86B6DE` | Links and accent-coloured text |
| `--on-accent` | `#0C141C` | Text on an accent fill |
| `--positive` | `#5DBB8A` | Success, gains |
| `--negative` | `#E8756A` | Errors, losses |
| `--warning` | `#E2B04A` | Cautions |

### 4.2 Colour: light theme

| Token | Hex |
|---|---|
| `--bg` | `#F3F5F8` |
| `--surface` | `#FFFFFF` |
| `--surface-raised` | `#F9FAFC` |
| `--line` | `#D3DAE2` |
| `--line-control` | `#75889C` |
| `--text` | `#14202B` |
| `--text-muted` | `#44566A` |
| `--text-faint` | `#5E6F82` |
| `--accent` | `#2E6597` |
| `--accent-hover` | `#24537D` |
| `--accent-press` | `#1C4666` |
| `--accent-text` | `#2A6092` |
| `--on-accent` | `#FFFFFF` |
| `--positive` | `#1E7F52` |
| `--negative` | `#B83C32` |
| `--warning` | `#8A5A00` |

### 4.3 Data series colours

Fixed roles, used in every chart, legend and table swatch. They stay in the same role in both themes.

| Series | Dark | Light | Line style |
|---|---|---|---|
| Market price | `#DCE4EC` | `#14202B` | 1.75 px solid |
| Our bid | `#4DB6A9` | `#1F8A7E` | 1.25 px solid |
| Our ask | `#E3A24A` | `#B86A0A` | 1.25 px solid |
| Shares held | `#E8756A` | `#B83C32` | 1.5 px stepped |
| Volatility | `#86B6DE` | `#2E6597` | 1.5 px solid |
| Baseline or reference | `#8895A3` | `#66778A` | 1.25 px dashed |

Series are also distinguished by line style, not colour alone.

### 4.4 Verified contrast (WCAG 2.x, computed from the values above)

| Pair | Dark | Light | Requirement |
|---|---|---|---|
| Text on background | 15.16 | 15.12 | 4.5 |
| Text on surface | 13.96 | 16.52 | 4.5 |
| Muted text on surface | 7.52 | 7.54 | 4.5 |
| Faint text on background | 4.98 | 4.72 | 4.5 |
| Accent text on background | 8.31 | 6.03 | 4.5 |
| On-accent text on accent fill | 6.20 | 6.13 | 4.5 |
| Control border on surface | 3.61 | 3.65 | 3.0 |
| Positive / negative / warning on surface | 7.01 / 5.63 / 8.26 | 4.98 / 5.63 / 5.93 | 4.5 |
| Series price / bid / ask / shares / volatility on surface | 12.82 / 6.73 / 7.47 / 5.63 / 7.65 | 16.52 / 4.20 / 4.11 / 5.63 / 6.13 | 3.0 |

### 4.5 Typography

Pairing: **Archivo** (headings and body, using its width axis) and **Spline Sans Mono** (numbers, code, source lines).
Reasoning: a condensed, heavy Archivo gives headlines a compact data-desk voice that contrasts clearly with the regular-width body, and the monospaced face is reserved for what must align: numerals, code and provenance lines. Labels are set in the sans, in sentence case.

| Role | Family | Size / line height | Weight | Width | Notes |
|---|---|---|---|---|---|
| Display (hero title) | Archivo | 46 / 48 px | 700 | 80% | letter-spacing -0.01em |
| Page title (h1) | Archivo | 32 / 36 px | 700 | 82% | |
| Section title (h2) | Archivo | 22 / 28 px | 650 | 88% | |
| Panel title (h3) | Archivo | 15 / 20 px | 600 | 100% | |
| Body | Archivo | 14 / 21 px | 400 | 100% | max 68 characters per line |
| Body small | Archivo | 12.5 / 18 px | 400 | 100% | captions |
| Label | Archivo | 12.5 / 16 px | 500 | 100% | sentence case, no tracking |
| Data | Spline Sans Mono | 13 / 20 px | 400 | n/a | tabular figures, right-aligned in tables |
| Data large (readouts) | Spline Sans Mono | 26 / 30 px | 500 | n/a | |
| Code | Spline Sans Mono | 12.5 / 19 px | 400 | n/a | |
| Source line | Spline Sans Mono | 11.5 / 16 px | 400 | n/a | muted, under every chart and table |

Fallback stacks: Archivo falls back to `"Arial Narrow", system-ui, sans-serif`; Spline Sans Mono to `ui-monospace, "SF Mono", Consolas, monospace`.
Fonts load from Google Fonts; the app must stay readable if they fail to load.

### 4.6 Spacing

4 px base unit with a 2 px half step.

| Token | Value | | Token | Value |
|---|---|---|---|---|
| `--space-1` | 2 px | | `--space-6` | 24 px |
| `--space-2` | 4 px | | `--space-7` | 32 px |
| `--space-3` | 8 px | | `--space-8` | 48 px |
| `--space-4` | 12 px | | `--space-9` | 64 px |
| `--space-5` | 16 px | | | |

### 4.7 Radius, borders, elevation

Radius follows hierarchy, so it is not one value on everything.

| Token | Value | Used on |
|---|---|---|
| `--radius-sm` | 2 px | Tags, swatches, table cells |
| `--radius-md` | 4 px | Buttons, inputs, tabs, notices |
| `--radius-lg` | 8 px | Panels |

- Borders are 1 px. Panels use `--line`; controls use `--line-control`.
- **No shadows on panels or buttons.** The only elevation is a popover shadow: `0 8px 24px rgba(0,0,0,0.35)` (dark) or `0 8px 24px rgba(20,32,43,0.14)` (light), used for tooltips and menus.

### 4.8 Motion

| Token | Value | Use |
|---|---|---|
| `--motion-fast` | 120 ms ease-out | Hover, focus, press |
| `--motion-medium` | 200 ms ease-out | Expanders, tab underline |
| Hero chart reveal | 900 ms, once on first load | The price line draws left to right |

No other non-user-triggered motion. Everything is disabled under `prefers-reduced-motion`.

### 4.9 Icons

One set: **Material Symbols (Rounded)**, weight 300, optical size 20, never filled except for a selected state. This is the set Streamlit uses for its own `:material/name:` icons, so the app's native widgets and custom pieces match. Icons are always paired with text or an accessible name. No emoji, no mixed sets.

Icons in use: `home` (overview), `play_arrow` (run), `candlestick_chart` (backtest), `show_chart` (simulator), `compare_arrows` (compare), `menu_book` (method), `dark_mode` and `light_mode` (theme), `download`, `info`, `warning`, `error`, `check_circle`, `expand_more`, `refresh`.

### 4.10 Grid and breakpoints

- Container maximum width 1360 px; 12 columns; gutter 24 px; page margin 32 px (16 px below 640 px).
- Breakpoints: 640, 960, 1280 px.
- App shell: top bar 48 px; settings rail 288 px on the left; content on the 12-column grid.

---

## 5. Components

Every component has the states listed. States are shown in the preview.

**Button** (heights 32 compact, 36 default; padding 0 14 px; radius md)
- Primary: accent fill, on-accent text. Secondary: transparent, control border, text colour. Ghost: no border, accent text.
- States: default, hover (accent-hover or surface-raised), pressed (accent-press), focus-visible (2 px accent-text outline, 2 px offset), disabled (45% opacity, no pointer), loading (label replaced by "Running", indeterminate 2 px bar along the bottom edge).
- Button text says what happens: "Open simulator", "Run comparison", "Run backtest", "Download results". No arrows, no "Submit".

**Text input, number input, select** (height 32, surface fill, control border, radius md)
- States: default, hover (border text-muted), focus (accent border plus 2 px ring), disabled, error (negative border, message below in negative, with an `error` icon).

**Slider**: 3 px track in `--line-control`, filled portion in accent, 14 px thumb with a 2 px surface border, current value in Data type to the right.

**Toggle**: 32 x 18 px, off in `--line-control`, on in accent, label to the right.

**Tabs**: text tabs on a 1 px baseline; active tab has a 2 px accent underline and `--text`; inactive `--text-muted`; hover `--text`.

**Panel**: surface fill, 1 px `--line` border, radius lg. Optional 36 px header strip with an h3 title on the left and an action (ghost button or icon button) on the right. A source line may sit in a 28 px footer strip.

**Readout** (replaces "metric cards"): a label in Label type over a value in Data large. Readouts sit in a single ruled row inside a panel, separated by 1 px vertical lines, never as separate floating cards. Optional delta in Data type with a positive or negative colour and a sign.

**Data table**: header row on `--surface-raised`, 13 px Data type, numbers right-aligned with tabular figures, text left-aligned, rows 32 px, hover row `--surface-raised`, best value in a column marked with a 2 px accent bar at the cell's left edge (not by colour alone).

**Notice**: surface-raised fill, 3 px left stripe in the semantic colour, icon, text. Variants: info (accent), success, warning, error. Errors say what went wrong and how to fix it, with no apology.

**Tag**: 11.5 px Label type, 1 px control border, radius sm, optional leading swatch.

**Chart frame**: a panel; legend as short line samples (matching the series line style) in Label type; axis text in Data type at `--text-muted`; gridlines `--line` at 60% opacity; source line below.

**Source line**: Source line type, `--text-muted`. Format: `Source: simulation, volatility-aware strategy, seed 7, 1 day, sim.py` or `Source: yfinance, SPY, daily bars 2020-02-03 to 2020-04-30, retrieved [DATE]`. Required under every chart and table.

**Expander**: panel with a 36 px header row, `expand_more` icon rotating 180 degrees in 200 ms.

**Tooltip**: popover (the only shadowed element), 12.5 px, max width 260 px.

**Code block**: surface-raised fill, 1 px line border, radius md, Code type, horizontal scroll, no wrapping.

**Empty state**: one sentence saying what is missing and one action. Example: "No backtest yet. Choose a ticker and dates, then run it."

---

## 6. Layout and page templates

### 6.1 Shell

```
+----------------------------------------------------------------------------------+
| Market Maker Simulator    Overview  Simulator  Compare  Backtest  Method   [theme] |  48 px bar
+---------------+------------------------------------------------------------------+
| Settings rail |  Page title (h1, left)                                           |
| 288 px        |  One-line description (body, max 68 ch)                          |
| controls,     |  ----------------------------------------------------------------|
| grouped with  |  12-column content grid: panels separated by 24 px gutters       |
| h3 headings   |                                                                  |
+---------------+------------------------------------------------------------------+
```

### 6.2 Overview (hero)

```
+------------------------------------------+---------------------------------------+
| Title (display, cols 1-5)                | Panel: one simulated day (cols 6-12)  |
| Description (body, 68 ch)                |  price / bid / ask chart, large       |
| Facts list (definition list)             |  shares-held strip under it           |
| [Open simulator]  [Read the method]      |  readout row, source line             |
+------------------------------------------+---------------------------------------+
```
Text on the left, the chart on the right and wider than the text. Left edges align to the grid. Nothing is centred.

### 6.3 Simulator

```
| Readout row (profit, shares left, trades, average gap)                            |
| Panel: price, bid, ask (cols 1-12, tall)                                          |
| Panel: shares held (cols 1-6)           | Panel: profit so far (cols 7-12)        |
| Panel: volatility, real and estimated (cols 1-12, only when storms are on)        |
```

### 6.4 Compare

```
| Panel: results table (cols 1-12), best value in each column marked                |
| Panel: profit distribution (cols 1-6)   | Panel: shares left over (cols 7-12)     |
| Notice: plain-words verdict                                                       |
```

### 6.5 Backtest

```
| Panel: inputs in one row: ticker, start, end, strategy, run button                |
| Notice: what is real (daily prices) and what is simulated (intraday path, fills)  |
| Panel: real price with simulated quotes (cols 1-12)                               |
| Readout row | Panel: daily profit (cols 1-6) | Panel: running shares (cols 7-12)    |
| Panel: per-day table with download                                                |
```

### 6.6 Method

Single column, 68 characters wide, left-aligned, with a sticky contents list in the rail. Equations set in the Data face's neighbour, Archivo italic, at body size or larger.

---

## 7. Content and voice

- Sentence case. Plain verbs. Active voice. No filler.
- Name things by what a reviewer understands: "shares left over", not "terminal inventory"; keep the technical term in a tooltip.
- Actions keep one name through the flow: "Run backtest" produces "Backtest finished".
- Errors explain the cause and the fix: "No daily prices found for XYZ between these dates. Check the ticker symbol, or choose a longer period."
- **Provenance rule:** a number appears only with a source line. Simulated numbers say "simulation" and give the seed. Real-data numbers name the data source, date range and retrieval date.
- No claims the code does not support. Planned features are labelled "in progress".

### Draft hero copy (written from the project's real facts; replace with your own wording)

- Title: `Limit order book market-making simulator`
- Description: `A Python simulator in which a market maker quotes a bid and an ask, earns the spread, and manages the risk of the shares it ends up holding. It implements the Avellaneda-Stoikov model, solves the model's exact quotes, and adapts them when volatility changes.`
- Facts list:
  - Model: Avellaneda-Stoikov (2008)
  - Simulators: random fills, and a matching engine with price-time priority
  - Strategies: fixed gap, textbook formula, exact formula, volatility-aware
  - Verification: 24 automated tests pass
  - Historical data: backtest on yfinance daily prices, in progress
- Buttons: `Open simulator`, `Read the method`
- Chart source line: `Source: simulation, volatility-aware strategy, seed 7, stormy market, sim.py. Simulated prices, not market data.`

---

## 8. Accessibility

- Contrast values in section 4.4 are the floor; any new colour must be checked before it is added.
- Visible focus on every interactive element (2 px outline, 2 px offset).
- Colour is never the only carrier of meaning: series differ by line style, best table values carry a marker, notices carry an icon and a word.
- Keyboard: tab order follows visual order; the theme toggle has `aria-pressed`.
- `prefers-reduced-motion` disables the hero reveal and all transitions.
- Charts need a text alternative: the readout row and the source line state the same facts in words.
- Minimum target size 32 px; text never below 11.5 px.

---

## 9. Streamlit implementation map

| Design element | Mechanism |
|---|---|
| Colours, light and dark | `.streamlit/config.toml` with `[theme.dark]` and `[theme.light]` sections (both exist in the installed Streamlit); Streamlit's own settings menu then switches theme. Exact keys to be confirmed against the installed version when building |
| Fonts | `@import` of Archivo and Spline Sans Mono in injected CSS, applied to the app container |
| Icons | Streamlit's native `:material/name:` syntax in buttons, tabs and expanders |
| Hero, readout row, source line, notices | `st.markdown(..., unsafe_allow_html=True)` with classes defined in one CSS block |
| Panels | `st.container(border=True)` plus CSS for radius and header strip |
| Charts | Matplotlib figures styled from the series tokens (same hex values), transparent background, no chart-junk |
| Tables | `st.dataframe` with custom CSS for header, row height and numeric alignment, or an HTML table when markers are needed |
| Tabs | `st.tabs`, styled with the underline treatment |

Known limit: Streamlit controls the width of its sidebar and some widget internals; where a component cannot be matched exactly, the nearest achievable treatment is used and noted here.

---

## 10. Placeholders and open items

| Placeholder | Needed from you |
|---|---|
| `[YOUR NAME]` | Name for the top-bar credit, if wanted |
| `[UNIVERSITY]` | Institution line, if wanted |
| `[GITHUB URL]`, `[LINKEDIN URL]` | Profile links, if wanted |
| `[HERO COPY]` | Your own wording to replace the draft in section 7 |
| `[DATE]` | Filled automatically with the retrieval date on backtest source lines |

---

## 11. Change log

| Date | Change |
|---|---|
| 2026-11-20 | First draft: direction chosen (portfolio audience, data-desk mood, Streamlit, dark with light toggle, steel blue). Contrast values computed. Awaiting approval |
| 2026-11-21 | Treated as approved by the instruction to keep the design and make it minimal. Implemented in `app.py`: top-level pages are Simulator, Compare, Backtest, Method; the settings rail holds three controls with the rest under Advanced; presets, banners and the hero were removed. The planned yfinance backtest was replaced by a Hawkes-process market. Theme sections for dark and light are in `.streamlit/config.toml`; Streamlit follows the system setting unless the user picks one in Settings |
