"""app.py -- Market Maker Simulator (minimal interface, styled from DESIGN.md).

Run it with:   python -m streamlit run app.py
"""
import io

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import streamlit as st

from backtest import BacktestConfig, run_backtest
from hawkes import HawkesMarketParams, diagnostics, fano_factor, generate_market
from metrics import summarize
from sim import DEFAULT_STEPS, avg_as_spread, simulate_level1, simulate_level2
from tearsheet import tear_sheets
from volatility import RegimeVolatility

# ----------------------------------------------------------------------------- design tokens (DESIGN.md)
THEMES = {
    "dark": dict(bg="#101821", surface="#16202B", raised="#1D2935", line="#2B3A49", control="#62788F",
                 text="#E7EDF3", muted="#A3B1BF", accent="#5E9BCB", accent_text="#86B6DE", on_accent="#0C141C",
                 positive="#5DBB8A", negative="#E8756A", price="#DCE4EC", bid="#4DB6A9", ask="#E3A24A",
                 inv="#E8756A", vol="#86B6DE", base="#8895A3", shadow="rgba(0,0,0,0.35)"),
    "light": dict(bg="#F3F5F8", surface="#FFFFFF", raised="#F9FAFC", line="#D3DAE2", control="#75889C",
                  text="#14202B", muted="#44566A", accent="#2E6597", accent_text="#2A6092", on_accent="#FFFFFF",
                  positive="#1E7F52", negative="#B83C32", price="#14202B", bid="#1F8A7E", ask="#B86A0A",
                  inv="#B83C32", vol="#2E6597", base="#66778A", shadow="rgba(20,32,43,0.14)"),
}
STRATEGIES = {"sym": "Fixed gap", "as": "Textbook formula", "exact": "Exact formula", "vol_aware": "Volatility-aware"}
STRATEGY_HELP = {
    "sym": "Quotes the same gap around the price and ignores how many shares it holds.",
    "as": "The classic Avellaneda-Stoikov formula, with a fixed volatility assumption.",
    "exact": "The same model solved exactly, still with a fixed volatility assumption.",
    "vol_aware": "The exact solution, fed by a Yang-Zhang volatility estimate that updates through the day.",
}


def current_theme():
    try:
        return "light" if st.context.theme.type == "light" else "dark"
    except Exception:
        return "dark"


T = THEMES[current_theme()]
SERIES = {"sym": T["ask"], "as": T["base"], "exact": T["bid"], "vol_aware": T["accent_text"]}

# ----------------------------------------------------------------------------- page setup
st.set_page_config(page_title="Market Maker Simulator", page_icon=":material/candlestick_chart:", layout="wide")
plt.rcParams.update({"font.size": 9, "text.color": T["muted"], "axes.labelcolor": T["muted"], "xtick.color": T["muted"],
                     "ytick.color": T["muted"], "axes.edgecolor": T["line"], "axes.spines.top": False,
                     "axes.spines.right": False, "axes.grid": True, "grid.color": T["line"], "grid.alpha": 0.6,
                     "grid.linewidth": 0.8, "font.family": "DejaVu Sans"})

st.markdown(
    f"""
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Archivo:wdth,wght@62..125,100..900&family=Spline+Sans+Mono:wght@400;500;600&display=swap');
      .stApp p, .stApp li, .stApp label, .stApp [data-testid="stWidgetLabel"] p, .stApp [data-testid="stCaptionContainer"],
      .stApp button p, .stApp [data-baseweb="tab"] p, .stApp [data-testid="stMarkdownContainer"] {{
          font-family: 'Archivo', 'Arial Narrow', system-ui, sans-serif; }}
      .stApp h1, .stApp h2, .stApp h3, .stApp h4 {{ font-family: 'Archivo', 'Arial Narrow', system-ui, sans-serif;
          font-stretch: 85%; font-weight: 700; letter-spacing: -0.01em; }}
      .stApp [data-testid="stMetricValue"], .stApp [data-testid="stDataFrame"], .stApp code, .stApp .source {{
          font-family: 'Spline Sans Mono', ui-monospace, 'SF Mono', Consolas, monospace; font-variant-numeric: tabular-nums; }}
      .stApp [data-testid="stMetricValue"] {{ font-size: 1.55rem; font-weight: 500; }}
      .stApp [data-testid="stMetricLabel"] p {{ color: {T['muted']}; font-size: 0.8rem; font-weight: 500; }}
      .block-container {{ padding-top: 2.2rem; max-width: 1360px; }}
      header[data-testid="stHeader"] {{ background: transparent; }}
      [data-testid="stSidebar"] {{ border-right: 1px solid {T['line']}; }}
      [data-testid="stVerticalBlockBorderWrapper"] {{ border-radius: 8px; border-color: {T['line']}; }}
      .stButton button, .stDownloadButton button {{ border-radius: 4px; height: 2.25rem; box-shadow: none; }}
      div[data-baseweb="tab-list"] {{ gap: 1.25rem; border-bottom: 1px solid {T['line']}; }}
      .brand {{ font: 700 1.55rem/1.2 'Archivo', 'Arial Narrow', sans-serif; font-stretch: 85%; margin: 0; }}
      .tagline {{ color: {T['muted']}; margin: 0.2rem 0 1.4rem 0; max-width: 68ch; }}
      .stApp p.source {{ color: {T['muted']}; font-size: 0.74rem !important; line-height: 1.45; margin: 0.35rem 0 0.9rem 0; }}
      .stApp h4 {{ font-size: 1.15rem; margin-top: 1.4rem; }}
      .note {{ background: {T['raised']}; border: 1px solid {T['line']}; border-left: 3px solid {T['accent_text']};
               border-radius: 4px; padding: 0.7rem 1rem; margin: 0.5rem 0 1rem 0; font-size: 0.9rem; }}
      .note.warn {{ border-left-color: {T['ask']}; }}
      .rowlabel {{ color: {T['muted']}; font-size: 0.8rem; font-weight: 500; margin: 0 0 0.2rem 0; }}
    </style>
    <p class="brand">Market Maker Simulator</p>
    <p class="tagline">A limit order book market maker, tested against simulated and Hawkes-process markets.</p>
    """,
    unsafe_allow_html=True,
)

# ----------------------------------------------------------------------------- settings rail
DEFAULTS = dict(gamma=0.10, sigma=2.0, storms=False, storm_mult=3.0, storms_per_day=2.0, storm_len=10, A=140, k=1.5,
                seed=7, engine="Quick")
for key, val in DEFAULTS.items():
    st.session_state.setdefault(key, val)


def reset():
    st.session_state.update(DEFAULTS)


def new_seed():
    st.session_state["seed"] = int(np.random.default_rng().integers(1, 100000))


with st.sidebar:
    st.markdown("### Settings")
    st.slider("Caution about holding shares", 0.01, 1.00, key="gamma", step=0.01,
              help="Higher means the market maker works harder to keep its shares near zero: less risk, lower average profit.")
    st.slider("Price jumpiness", 0.5, 5.0, key="sigma", step=0.1,
              help="How violently the price moves. Higher means holding shares is riskier.")
    st.toggle("Add volatile periods", key="storms",
              help="The market is calm most of the time but randomly enters stormy periods.")
    if st.session_state["storms"]:
        with st.expander("Storm settings"):
            st.slider("Strength (times jumpier)", 1.5, 6.0, key="storm_mult", step=0.5)
            st.slider("Storms per day", 0.5, 5.0, key="storms_per_day", step=0.5)
            st.slider("Length (% of a day)", 3, 30, key="storm_len", step=1)
    with st.expander("Advanced"):
        st.slider("Market activity", 20, 300, key="A", step=10, help="Roughly how many buy and sell orders arrive per day.")
        st.slider("Price sensitivity of traders", 0.5, 3.0, key="k", step=0.1,
                  help="Higher means business disappears faster as your prices get worse.")
        st.radio("Simulation type", ["Quick", "Order book"], key="engine", horizontal=True,
                 help="Quick uses a probability formula. Order book matches orders one by one (slower).")
        st.number_input("Random seed", 1, 99999, key="seed")
        st.button("New random seed", on_click=new_seed, icon=":material/refresh:", type="tertiary")
    st.button("Reset settings", on_click=reset, type="tertiary")

gamma, sigma, k, A = (st.session_state[x] for x in ("gamma", "sigma", "k", "A"))
seed, storms, ORDER_BOOK = int(st.session_state["seed"]), st.session_state["storms"], st.session_state["engine"] == "Order book"
regime_key = ((st.session_state["storm_mult"], st.session_state["storms_per_day"] / DEFAULT_STEPS,
               1.0 / (st.session_state["storm_len"] / 100 * DEFAULT_STEPS)) if storms else None)
avg_sigma = RegimeVolatility(sigma, *regime_key).average_sigma if regime_key else sigma
half_spread = avg_as_spread(gamma, avg_sigma, k, 1.0) / 2


# ----------------------------------------------------------------------------- helpers
def source(text):
    st.markdown(f'<p class="source">{text}</p>', unsafe_allow_html=True)


def note(text, warn=False):
    st.markdown(f'<div class="note{" warn" if warn else ""}">{text}</div>', unsafe_allow_html=True)


def fmt(x, nd=1, signed=False):
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return "n/a"
    if isinstance(x, float) and np.isinf(x):
        return "no losing days"
    return f"{x:+,.{nd}f}" if signed else f"{x:,.{nd}f}"


@st.cache_data(show_spinner=False)
def run_sim(level2, strategy, n_runs, seed, gamma, sigma, k, A, regime_key, half_spread, record):
    regime = dict(stress_mult=regime_key[0], p_enter=regime_key[1], p_exit=regime_key[2]) if regime_key else None
    if level2:
        return simulate_level2(strategy, n_runs=n_runs, seed=seed, gamma=gamma, sigma=sigma, k=k, lam=float(A),
                               half_spread=half_spread, regime=regime, record_first=record)
    return simulate_level1(strategy, n_runs=n_runs, seed=seed, gamma=gamma, sigma=sigma, k=k, A=float(A),
                           half_spread=half_spread, regime=regime, record_first=record)


def new_axes(rows=1, cols=1, height=3.0, width=8.6, **kw):
    fig, ax = plt.subplots(rows, cols, figsize=(width, height), **kw)
    fig.patch.set_alpha(0)
    for a in np.atleast_1d(ax).ravel():
        a.set_facecolor("none")
    return fig, ax


def finish(fig):
    """Draw a chart with a transparent background so it takes on the active theme."""
    fig.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png", transparent=True, dpi=200, bbox_inches="tight")
    plt.close(fig)
    st.image(buf)


def legend(ax, **kw):
    """Legend above the plot area, so it never covers data."""
    kw.pop("loc", None)
    ncol = kw.pop("ncol", 4)
    leg = ax.legend(frameon=False, loc="lower left", bbox_to_anchor=(0, 1.0), ncol=ncol, borderaxespad=0.2, **kw)
    for t in leg.get_texts():
        t.set_color(T["muted"])


# ----------------------------------------------------------------------------- pages
tab_sim, tab_cmp, tab_bt, tab_method = st.tabs([":material/show_chart: Simulator", ":material/compare_arrows: Compare",
                                                ":material/candlestick_chart: Backtest", ":material/menu_book: Method"])

# ============================================================== Simulator
with tab_sim:
    strategy = st.radio("Strategy", list(STRATEGIES), format_func=STRATEGIES.get, horizontal=True, key="watch")
    st.caption(STRATEGY_HELP[strategy])
    res = run_sim(ORDER_BOOK, strategy, 1, seed, gamma, sigma, k, A, regime_key, half_spread, True)
    path = res["path"]
    with st.container(border=True):
        c = st.columns(4)
        c[0].metric("Profit at close", fmt(float(res["pnl"][0]), 1, True))
        c[1].metric("Shares at close", f"{int(res['q'][0]):+d}")
        c[2].metric("Trades made", f"{int(res['n_fills'][0])}")
        c[3].metric("Average gap", f"{float(np.mean(path['ask'] - path['bid'])):.2f}")
    fig, ax = new_axes(height=3.4)
    ax.plot(path["t"], path["s"], color=T["price"], lw=1.75, label="Market price")
    ax.step(path["t"], path["bid"], color=T["bid"], lw=1.2, where="post", label="Our bid")
    ax.step(path["t"], path["ask"], color=T["ask"], lw=1.2, where="post", label="Our ask")
    ax.set_xlabel("Time through the trading day"); ax.set_ylabel("Price")
    legend(ax, ncol=3, loc="upper left")
    finish(fig)
    left, right = st.columns(2)
    with left:
        fig, ax = new_axes(height=2.6, width=4.6)
        ax.step(path["t"], path["q"], color=T["inv"], lw=1.5, where="post"); ax.axhline(0, color=T["control"], lw=0.8)
        ax.set_ylabel("Shares held"); ax.set_xlabel("Time")
        finish(fig)
    with right:
        fig, ax = new_axes(height=2.6, width=4.6)
        ax.plot(path["t"], path["pnl"], color=T["price"], lw=1.75); ax.axhline(0, color=T["control"], lw=0.8)
        ax.set_ylabel("Profit so far"); ax.set_xlabel("Time")
        finish(fig)
    if storms:
        fig, ax = new_axes(height=2.2)
        ax.fill_between(path["t"], 0, path["sigma"], step="post", color=T["vol"], alpha=0.25, label="Actual jumpiness (hidden)")
        if strategy == "vol_aware":
            ax.plot(path["t"], path["sigma_hat"], color=T["vol"], lw=1.5, label="Strategy's estimate")
        ax.set_ylabel("Jumpiness"); ax.set_xlabel("Time")
        legend(ax, loc="upper left")
        finish(fig)
    source(f"Source: simulation, {'order-book' if ORDER_BOOK else 'quick'} engine, {STRATEGIES[strategy].lower()}, seed {seed}. Simulated prices, not market data.")

# ============================================================== Compare
with tab_cmp:
    if ORDER_BOOK:
        n_days = st.slider("Days to simulate", 20, 150, 40, step=10)
        go = st.button("Run comparison", type="primary", icon=":material/play_arrow:")
        key = (n_days, seed, gamma, sigma, k, A, regime_key)
        if go:
            with st.spinner("Simulating"):
                st.session_state["cmp"] = (key, {s: run_sim(True, s, n_days, seed, gamma, sigma, k, A, regime_key, half_spread, False)
                                                 for s in STRATEGIES})
        stored = st.session_state.get("cmp")
        results = stored[1] if stored and stored[0] == key else None
        if results is None:
            note("Press Run comparison. Changing a setting clears the previous result.")
    else:
        n_days = st.slider("Days to simulate", 200, 4000, 2000, step=200)
        results = {s: run_sim(False, s, n_days, seed, gamma, sigma, k, A, regime_key, half_spread, False) for s in STRATEGIES}
    if results is not None:
        stats = {s: summarize(r, gamma) for s, r in results.items()}
        best = max(stats, key=lambda s: stats[s]["score"])
        table = pd.DataFrame({"Strategy": [STRATEGIES[s] for s in stats],
                              "Average profit": [fmt(v["mean"]) for v in stats.values()],
                              "Typical swing": [fmt(v["std"]) for v in stats.values()],
                              "Worst day": [fmt(v["worst"]) for v in stats.values()],
                              "Shares left over": [fmt(v["mean_abs_q"]) for v in stats.values()],
                              "Risk-adjusted score": [fmt(v["score"]) for v in stats.values()]})
        with st.container(border=True):
            st.dataframe(table, hide_index=True)
        note(f"{STRATEGIES[best]} has the best risk-adjusted score. The score is average profit minus a penalty for ups and downs; "
             f"the penalty grows with the caution setting.")
        a, b = st.columns(2)
        for col, key_, label in ((a, "pnl", "Profit at close"), (b, "q", "Shares left over")):
            with col:
                fig, ax = new_axes(height=3.0, width=4.6)
                box = ax.boxplot([results[s][key_] for s in stats], patch_artist=True, showfliers=False,
                                 medianprops=dict(color=T["text"]), whiskerprops=dict(color=T["control"]), capprops=dict(color=T["control"]))
                for patch, s in zip(box["boxes"], stats):
                    patch.set_facecolor(SERIES[s]); patch.set_alpha(0.55); patch.set_edgecolor(SERIES[s])
                ax.set_xticks(range(1, len(stats) + 1)); ax.set_xticklabels([STRATEGIES[s].replace(" ", "\n", 1) for s in stats], fontsize=8)
                ax.set_ylabel(label)
                finish(fig)
        source(f"Source: simulation, {n_days} days per strategy, seed {seed}, identical random numbers for every strategy.")

# ============================================================== Backtest
with tab_bt:
    st.markdown("Test the market maker against a synthetic market whose order flow comes from a **Hawkes process**: trades cluster, "
                "buys and sells excite each other, and orders move the price. Every strategy trades the same history.")
    with st.container(border=True):
        c1, c2, c3, c4 = st.columns([1, 1, 1, 1])
        bt_days = c1.slider("Days of history", 80, 300, 160, step=10)
        train_days = c2.slider("Calibration days", 20, 60, 40, step=5, help="Used only to calibrate the fill curve and volatility.")
        bt_seed = c3.number_input("History seed", 1, 99999, 11)
        c4.write("")
        run_it = c4.button("Run backtest", type="primary", icon=":material/play_arrow:")
        with st.expander("Market realism"):
            e1, e2, e3, e4 = st.columns(4)
            branching = e1.slider("Order clustering", 0.0, 0.9, 0.75, step=0.05,
                                  help="Average number of further orders each order triggers. Zero means orders arrive at random.")
            self_share = e2.slider("Same-side share", 0.5, 1.0, 0.85, step=0.05, help="How much of the clustering stays on the same side (buys follow buys).")
            impact = e3.slider("Price impact", 0.0, 0.30, 0.10, step=0.01, help="How far each order moves the price.")
            act_vol = e4.slider("Day-to-day swings", 0.0, 0.8, 0.40, step=0.05, help="How much busy and quiet days differ.")

    bt_key = (bt_days, train_days, int(bt_seed), branching, self_share, impact, act_vol, gamma)
    if run_it:
        params = HawkesMarketParams(branching=branching, self_share=self_share, impact=impact, activity_vol=act_vol)
        bar = st.progress(0, text="Generating the Hawkes market")
        history = generate_market(bt_days, seed=int(bt_seed), params=params)
        cfg = BacktestConfig(gamma=gamma, train_days=train_days)
        result = run_backtest(history, cfg, progress=lambda done, total: bar.progress(done / total, text="Trading the history"))
        bar.empty()
        poisson_fano = fano_factor(generate_market(40, seed=int(bt_seed), params=HawkesMarketParams(branching=0.0)))
        st.session_state["bt"] = dict(key=bt_key, history=history, result=result, facts=diagnostics(history), poisson_fano=poisson_fano)
    bt = st.session_state.get("bt")
    if not bt or bt["key"] != bt_key:
        note("Press Run backtest. Changing a setting clears the previous result.")
    else:
        result, facts = bt["result"], bt["facts"]
        n_test = len(result["test_days"])
        note("Prices and orders are generated by the Hawkes process, not downloaded. Fills are simulated against the order book. "
             "Ratios here are far higher than any real market maker could achieve, because the simulation has no fees, no competing "
             "market makers and perfect refilling of the book. Use them to compare strategies, not as forecasts.", warn=True)

        # ---- the market
        st.markdown("#### The market")
        with st.container(border=True):
            c = st.columns(5)
            c[0].metric("Orders per day", f"{facts['orders_per_day']:.0f}")
            c[1].metric("Order clustering", f"{facts['fano_factor']:.2f}", help=f"1.00 means orders arrive at random; this market is clustered. Unclustered reference: {bt['poisson_fano']:.2f}.")
            c[2].metric("Buy/sell persistence", f"{facts['sign_autocorrelation']:+.2f}", help="Correlation between consecutive order directions. Zero for random arrivals.")
            c[3].metric("Daily volatility", f"{facts['daily_vol_mean']:.2f}")
            c[4].metric("Volatility clustering", f"{facts['abs_return_autocorrelation']:.2f}", help="Correlation of consecutive absolute price moves.")
        vol = result["volatility"]
        fig, ax = new_axes(height=2.6)
        x = np.arange(1, n_test + 1)
        ax.plot(x, vol["realized"], color=T["muted"], lw=1.0, label="Actual volatility that day")
        ax.plot(x, vol["yang_zhang"], color=T["vol"], lw=1.75, label=f"Yang-Zhang estimate ({result['config'].yz_window}-day, known at the open)")
        ax.axhline(vol["static"], color=T["base"], lw=1.2, ls="--", label="Fixed assumption from calibration")
        ax.set_xlabel("Test day"); ax.set_ylabel("Volatility (price units)")
        legend(ax, ncol=1, loc="upper left", fontsize=8)
        finish(fig)
        cal = result["calibration"]
        source(f"Source: Hawkes market, seed {int(bt_seed)}, {bt_days} days ({train_days} calibration, {n_test} test). "
               f"Fill curve calibrated on the calibration days: A = {cal['A']:.0f}, k = {cal['k']:.2f}, fit R squared {cal['r2']:.3f}.")

        # ---- tear sheet
        st.markdown("#### Tear sheet")
        t1, t2 = st.columns([3, 2])
        pick = t1.radio("Strategy", list(STRATEGIES), format_func=STRATEGIES.get, horizontal=True, index=3, key="tear_pick")
        target_mode = t2.selectbox("Sortino target", ["Half of the average day", "Zero"], help="Days below the target count as bad days.")
        sheets = tear_sheets(result, sortino_target="half_mean" if target_mode.startswith("Half") else 0.0)
        ts = sheets[pick]
        s, d, iv, ser = ts["summary"], ts["decomposition"], ts["inventory"], ts["series"]

        st.markdown('<p class="rowlabel">Performance</p>', unsafe_allow_html=True)
        with st.container(border=True):
            c = st.columns(6)
            c[0].metric("Average daily PnL", fmt(s["mean_daily"], 1, True))
            c[1].metric("Sharpe ratio", fmt(s["sharpe"], 1), help=f"Annualised with 252 days. Standard error about {s['sharpe_se']:.1f}.")
            c[2].metric("Sortino ratio", fmt(s["sortino"], 1), help=f"Target: {s['sortino_target']:.1f} per day. {s['downside_days']:.0%} of days fell below it.")
            c[3].metric("Maximum drawdown", fmt(s["max_drawdown"], 1))
            c[4].metric("Worst day", fmt(s["worst_day"], 1, True))
            c[5].metric("Days with a profit", f"{s['win_rate']:.0%}")

        fig, ax = new_axes(height=2.9)
        for name, sheet in sheets.items():
            ax.plot(np.arange(1, n_test + 1), sheet["series"]["cum_pnl"], color=SERIES[name], lw=2.2 if name == pick else 1.1,
                    alpha=1.0 if name == pick else 0.7, label=STRATEGIES[name])
        ax.set_xlabel("Test day"); ax.set_ylabel("Cumulative PnL")
        legend(ax, ncol=4, loc="upper left")
        finish(fig)

        st.markdown('<p class="rowlabel">PnL decomposition</p>', unsafe_allow_html=True)
        a, b = st.columns([2, 3])
        with a:
            with st.container(border=True):
                dec = pd.DataFrame({
                    "Component": ["Spread captured", "Adverse selection", "Inventory carry", "Total"],
                    "Per day": [fmt(d[k_]["per_day"], 2, True) for k_ in ("spread", "adverse_selection", "inventory_carry", "total")],
                    "Share of variance": [f"{d[k_]['variance_share']:.0%}" for k_ in ("spread", "adverse_selection", "inventory_carry", "total")]})
                st.dataframe(dec, hide_index=True)
            st.caption("Spread captured is the gap earned on fills. Adverse selection is the price move over the next "
                       f"{result['config'].markout_steps} steps after each fill. Inventory carry is the rest of the profit and loss from holding shares.")
        with b:
            fig, ax = new_axes(height=3.0, width=6.0)
            days = np.arange(1, n_test + 1)
            ax.plot(days, ser["cum_spread"], color=T["bid"], lw=1.6, label="Spread captured")
            ax.plot(days, ser["cum_adverse"], color=T["ask"], lw=1.6, label="Adverse selection")
            ax.plot(days, ser["cum_carry"], color=T["inv"], lw=1.6, label="Inventory carry")
            ax.plot(days, ser["cum_pnl"], color=T["price"], lw=2.0, ls="--", label="Total")
            ax.axhline(0, color=T["control"], lw=0.8); ax.set_xlabel("Test day"); ax.set_ylabel("Cumulative")
            legend(ax, ncol=2, loc="upper left", fontsize=8)
            finish(fig)

        st.markdown('<p class="rowlabel">Inventory risk</p>', unsafe_allow_html=True)
        with st.container(border=True):
            c = st.columns(6)
            c[0].metric("Avg shares", f"{iv['mean_abs']:.1f}", help="Mean of the absolute number of shares held, over every decision step.")
            c[1].metric("RMS shares", f"{iv['rms']:.1f}", help="Root mean square: weights large positions more heavily.")
            c[2].metric("Peak", f"{iv['peak_abs']:.0f}")
            c[3].metric("Time flat", f"{iv['pct_flat']:.0%}")
            c[4].metric("Time at limit", f"{iv['pct_at_limit']:.1%}")
            c[5].metric("Variance share", f"{iv['inv_pnl_variance_share']:.0%}", help="How much of the day-to-day variation in profit comes from price moves on held shares.")
        fig, ax = new_axes(height=2.6)
        qmax = 12
        for name in STRATEGIES:
            qs = result["strategies"][name]["q_path"].ravel()
            counts, edges = np.histogram(np.clip(qs, -qmax, qmax), bins=np.arange(-qmax - 0.5, qmax + 1.5, 1))
            ax.plot(np.arange(-qmax, qmax + 1), counts / counts.sum(), color=SERIES[name], lw=2.0 if name == pick else 1.0,
                    alpha=1.0 if name == pick else 0.7, label=STRATEGIES[name])
        ax.set_xlabel("Shares held (capped at 12 either way)"); ax.set_ylabel("Share of time")
        legend(ax, ncol=4, loc="upper left", fontsize=8)
        finish(fig)

        st.markdown('<p class="rowlabel">All strategies</p>', unsafe_allow_html=True)
        rows = []
        for name, sheet in sheets.items():
            su, de, inv_ = sheet["summary"], sheet["decomposition"], sheet["inventory"]
            rows.append({"Strategy": STRATEGIES[name], "PnL per day": fmt(su["mean_daily"]), "Swing": fmt(su["std_daily"]),
                         "Sharpe": fmt(su["sharpe"]), "Sortino": fmt(su["sortino"]), "Max drawdown": fmt(su["max_drawdown"]),
                         "Spread": fmt(de["spread"]["per_day"]), "Adverse": fmt(de["adverse_selection"]["per_day"]),
                         "Carry": fmt(de["inventory_carry"]["per_day"]), "Avg shares": fmt(inv_["mean_abs"]),
                         "Trades": fmt(su["fills_per_day"], 0)})
        with st.container(border=True):
            st.dataframe(pd.DataFrame(rows), hide_index=True)
        raw = result["strategies"][pick]
        export = pd.DataFrame({"test_day": np.arange(1, n_test + 1), "pnl": raw["pnl"], "spread": raw["edge"], "adverse_selection": raw["markout"],
                               "inventory_carry": raw["inv_pnl"] - raw["markout"], "fills": raw["fills"],
                               "mean_abs_shares": np.abs(raw["q_path"]).mean(axis=1)})
        st.download_button("Download daily results", export.to_csv(index=False), f"backtest_{pick}.csv", "text/csv", icon=":material/download:")
        source(f"Source: Hawkes market, seed {int(bt_seed)}, {n_test} test days, {STRATEGIES[pick].lower()}. Sharpe and Sortino use daily PnL with constant capital, "
               f"annualised with 252 days. Sharpe standard error {s['sharpe_se']:.1f}.")

# ============================================================== Method
with tab_method:
    left, right = st.columns([1, 2])
    with left:
        st.markdown("### Method")
        st.caption("How the market maker, the market and the report work.")
    with right:
        with st.expander("What a market maker does", expanded=True):
            st.markdown("A market maker keeps a **bid** (a price to buy) and an **ask** (a price to sell) in the order book, and earns the "
                        "gap between them each time both are used. The risk is the shares it ends up holding: if the price moves against that "
                        "inventory, it loses money.")
        with st.expander("The four strategies"):
            st.markdown("- **Fixed gap** quotes symmetrically around the price.\n"
                        "- **Textbook formula** is the Avellaneda-Stoikov closed form. It shifts both quotes against its inventory.\n"
                        "- **Exact formula** solves the same model without the small-inventory approximation. The textbook gap grows too wide when volatility is high.\n"
                        "- **Volatility-aware** is the exact solution fed with a running volatility estimate.")
            st.latex(r"r = s - q\,\gamma\,\sigma^{2}(T-t),\qquad \text{gap} = \gamma\sigma^{2}(T-t) + \tfrac{2}{\gamma}\ln\!\left(1+\tfrac{\gamma}{k}\right)")
        with st.expander("Yang-Zhang volatility"):
            st.markdown("The estimate combines three pieces from daily open, high, low and close prices: the variance of overnight gaps, the variance of open-to-close "
                        "returns, and the Rogers-Satchell range term. It is accurate when prices drift and gap, and far steadier than using closing prices alone. "
                        "The backtest drops the overnight term, because the market maker is flat overnight, and uses the estimate from earlier days as the starting "
                        "volatility each morning. An exponential moving average then updates it through the day.")
            st.latex(r"\sigma^{2}_{YZ} = \sigma^{2}_{o} + k\,\sigma^{2}_{c} + (1-k)\,\sigma^{2}_{RS},\qquad k = \frac{0.34}{1.34 + (n+1)/(n-1)}")
        with st.expander("The Hawkes market"):
            st.markdown("A Hawkes process is a random sequence of events in which each event raises the chance of more events for a while. Here buys and sells "
                        "both excite buys and sells, with most of the excitation staying on the same side. The generated market also has a busy open and close, "
                        "heavy-tailed order sizes, price impact that is partly permanent and partly temporary, busy and quiet days that persist, and overnight gaps. "
                        "The history is generated once, so every strategy sees identical orders and prices.")
        with st.expander("The tear sheet"):
            st.markdown("- **Sharpe ratio:** average daily PnL over its standard deviation, annualised with 252 days.\n"
                        "- **Sortino ratio:** like Sharpe, but only days below a target count as risk. With almost no losing days the target-zero version is infinite, "
                        "so the default target is half the average day.\n"
                        "- **PnL decomposition:** spread captured, plus adverse selection (the price move over the next few steps after each fill), plus inventory carry "
                        "(the remainder of the inventory PnL). They add up to total PnL exactly.\n"
                        "- **Inventory risk:** how many shares were held, for how long, and how much of the variation in profit they cause.")
        with st.expander("Limits"):
            st.markdown("- The market is simulated. It resembles real order flow in several measurable ways, but it is not real data, and no result here shows "
                        "that a strategy would make money in a real market.\n"
                        "- Sharpe and Sortino ratios are inflated: there are no fees, no competing market makers, quotes can be refreshed instantly, and the order book "
                        "is refilled perfectly. Compare strategies with each other, not with published figures.\n"
                        "- Fills assume a fixed amount of other traders' depth in front of each quote.")
st.caption("Simulation only. Not financial advice.")
