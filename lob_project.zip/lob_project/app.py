"""app.py -- Market Maker Simulator: dark, minimal, animated.

Run it with:   python -m streamlit run app.py

Pages            Simulator | Strategy lab (Compare, Quote policy, Fill curve) | Backtest (Market, Performance,
                 Decomposition, Inventory, Strategies) | Method
Charts           viz.py draws smooth, animated SVG charts that morph when their data changes.
"""
from contextlib import contextmanager

import numpy as np
import pandas as pd
import streamlit as st

import viz
from backtest import BacktestConfig, run_backtest
from hawkes import HawkesMarketParams, diagnostics, fano_factor, generate_market
from metrics import summarize
from sim import DEFAULT_STEPS, avg_as_spread, get_quote_table, simulate_level1, simulate_level2
from tearsheet import tear_sheets
from volatility import RegimeVolatility

# ----------------------------------------------------------------------------- design tokens (DESIGN.md, dark)
C = dict(bg="#101821", surface="#16202B", raised="#1D2935", line="#2B3A49", control="#62788F", text="#E7EDF3",
         muted="#A3B1BF", accent="#5E9BCB", accent_text="#86B6DE", positive="#5DBB8A", negative="#E8756A",
         price="#DCE4EC", bid="#4DB6A9", ask="#E3A24A", inv="#E8756A", vol="#86B6DE", base="#8895A3")
JS_THEME = dict(bg=C["bg"], raised=C["raised"], line=C["line"], control=C["control"], text=C["text"], muted=C["muted"],
                accent=C["accent"], shadow="rgba(0,0,0,0.45)")
STRATEGIES = {"sym": "Fixed gap", "as": "Textbook formula", "exact": "Exact formula", "vol_aware": "Volatility-aware"}
STRATEGY_HELP = {
    "sym": "Quotes the same gap around the price and ignores how many shares it holds.",
    "as": "The classic Avellaneda-Stoikov formula, with a fixed volatility assumption.",
    "exact": "The same model solved exactly, still with a fixed volatility assumption.",
    "vol_aware": "The exact solution, fed by a Yang-Zhang volatility estimate that updates through the day.",
}
COLOR = {"sym": C["ask"], "as": C["base"], "exact": C["bid"], "vol_aware": C["accent_text"]}


def wave_paths():
    """Three slow sine waves for the header; periods 1200, 600 and 400 so the loop repeats seamlessly."""
    out = []
    for period, amp, phase in ((1200, 15, 0.0), (600, 9, 1.3), (400, 6, 2.4)):
        xs = np.arange(0, 2401, 20)
        ys = 38 + amp * np.sin(2 * np.pi * xs / period + phase)
        out.append("M" + " L".join(f"{x},{y:.1f}" for x, y in zip(xs, ys)))
    return out


# ----------------------------------------------------------------------------- page setup and styling
st.set_page_config(page_title="Market Maker Simulator", page_icon=":material/candlestick_chart:", layout="wide")
w1, w2, w3 = wave_paths()
st.markdown(
    f"""
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Archivo:wdth,wght@62..125,100..900&family=Spline+Sans+Mono:wght@400;500;600&display=swap');
      @keyframes rise {{ from {{ opacity: 0; transform: translateY(18px); }} to {{ opacity: 1; transform: translateY(0); }} }}
      @keyframes fade {{ from {{ opacity: 0; }} to {{ opacity: 1; }} }}
      @keyframes drift {{ from {{ transform: translateX(0); }} to {{ transform: translateX(-50%); }} }}
      @keyframes glow {{ 0%, 100% {{ opacity: .35; }} 50% {{ opacity: .7; }} }}

      .stApp p, .stApp li, .stApp label, .stApp [data-testid="stWidgetLabel"] p, .stApp [data-testid="stCaptionContainer"],
      .stApp button p, .stApp [data-testid="stTab"] p, .stApp [data-testid="stMarkdownContainer"] {{
          font-family: 'Archivo', 'Arial Narrow', system-ui, sans-serif; }}
      .stApp h1, .stApp h2, .stApp h3, .stApp h4 {{ font-family: 'Archivo', 'Arial Narrow', system-ui, sans-serif;
          font-stretch: 85%; font-weight: 700; letter-spacing: -0.01em; }}
      .stApp [data-testid="stMetricValue"], .stApp [data-testid="stDataFrame"], .stApp code {{
          font-family: 'Spline Sans Mono', ui-monospace, 'SF Mono', Consolas, monospace; font-variant-numeric: tabular-nums; }}
      .stApp [data-testid="stMetricValue"] {{ font-size: 1.55rem; font-weight: 500; }}
      .stApp [data-testid="stMetricLabel"] p {{ color: {C['muted']}; font-size: 0.78rem; font-weight: 500; }}
      .block-container {{ padding-top: 1.6rem; max-width: 1360px; }}
      header[data-testid="stHeader"] {{ background: transparent; }}
      [data-testid="stSidebar"] {{ border-right: 1px solid {C['line']}; }}

      /* ---- header ---- */
      .brand {{ font: 700 1.7rem/1.15 'Archivo', 'Arial Narrow', sans-serif; font-stretch: 85%; margin: 0; letter-spacing: -0.01em;
                animation: rise .7s cubic-bezier(.2,.7,.2,1) both; }}
      .tagline {{ color: {C['muted']}; margin: .25rem 0 0 0; max-width: 68ch; animation: rise .7s .08s cubic-bezier(.2,.7,.2,1) both; }}
      .wavehead {{ height: 58px; overflow: hidden; margin: .3rem 0 .4rem 0; opacity: 0; animation: fade 1.2s .3s ease forwards;
                   -webkit-mask-image: linear-gradient(90deg, transparent, #000 12%, #000 88%, transparent);
                   mask-image: linear-gradient(90deg, transparent, #000 12%, #000 88%, transparent); }}
      .wavehead svg {{ width: 200%; height: 100%; animation: drift 26s linear infinite; }}
      .wavehead path {{ fill: none; stroke: {C['accent']}; stroke-linecap: round; stroke-linejoin: round; }}
      .wavehead .a {{ stroke-width: 1.7; opacity: .6; }}
      .wavehead .b {{ stroke-width: 1.2; opacity: .35; animation: glow 7s ease-in-out infinite; }}
      .wavehead .c {{ stroke-width: 1; opacity: .22; animation: glow 9s 1s ease-in-out infinite; }}

      /* ---- tab transitions: each tab panel mounts fresh, so these play on every switch ---- */
      [data-testid="stTabPanel"][role="tabpanel"] {{ animation: fade .5s ease both; }}
      [data-testid="stTabPanel"] > [data-testid="stVerticalBlock"] > * {{ animation: rise .65s cubic-bezier(.2,.7,.2,1) both; }}
      [data-testid="stTabPanel"] > [data-testid="stVerticalBlock"] > *:nth-child(1) {{ animation-delay: .00s; }}
      [data-testid="stTabPanel"] > [data-testid="stVerticalBlock"] > *:nth-child(2) {{ animation-delay: .06s; }}
      [data-testid="stTabPanel"] > [data-testid="stVerticalBlock"] > *:nth-child(3) {{ animation-delay: .12s; }}
      [data-testid="stTabPanel"] > [data-testid="stVerticalBlock"] > *:nth-child(4) {{ animation-delay: .18s; }}
      [data-testid="stTabPanel"] > [data-testid="stVerticalBlock"] > *:nth-child(5) {{ animation-delay: .24s; }}
      [data-testid="stTabPanel"] > [data-testid="stVerticalBlock"] > *:nth-child(6) {{ animation-delay: .30s; }}
      [data-testid="stTabPanel"] > [data-testid="stVerticalBlock"] > *:nth-child(7) {{ animation-delay: .36s; }}
      [data-testid="stTabPanel"] > [data-testid="stVerticalBlock"] > *:nth-child(n+8) {{ animation-delay: .42s; }}
      [data-testid="stTab"] {{ transition: color .3s ease, transform .3s ease; position: relative; }}
      [data-testid="stTab"]:hover {{ transform: translateY(-1px); }}
      [data-testid="stTabs"] [role="tablist"] {{ gap: 1.4rem; border-bottom: 1px solid {C['line']}; }}

      /* ---- panels, controls ---- */
      [data-testid="stVerticalBlockBorderWrapper"] {{ border-radius: 10px; border-color: {C['line']};
          transition: border-color .35s ease, background-color .35s ease; background: {C['surface']}66; }}
      [data-testid="stVerticalBlockBorderWrapper"]:hover {{ border-color: {C['control']}; }}
      .stButton button, .stDownloadButton button {{ border-radius: 6px; height: 2.25rem; box-shadow: none;
          transition: transform .2s ease, background-color .25s ease, border-color .25s ease; }}
      .stButton button:hover, .stDownloadButton button:hover {{ transform: translateY(-1px); }}
      [data-testid="stExpander"] {{ border-radius: 8px; transition: border-color .3s ease; }}
      [data-testid="stMetric"] {{ transition: transform .3s ease; }}
      [data-testid="stMetric"]:hover {{ transform: translateY(-2px); }}
      iframe {{ border: 0; }}

      .ph {{ margin: 0 0 .25rem 0; }}
      .pt {{ display: block; font: 600 .95rem 'Archivo', sans-serif; letter-spacing: -.005em; }}
      .ps {{ display: block; color: {C['muted']}; font-size: .78rem; margin-top: .1rem; }}
      .stApp p.source {{ color: {C['muted']}; font-family: 'Spline Sans Mono', monospace; font-size: .72rem !important; line-height: 1.45; margin: .2rem 0 .6rem 0; }}
      .note {{ background: {C['raised']}; border: 1px solid {C['line']}; border-left: 3px solid {C['accent_text']};
               border-radius: 6px; padding: .7rem 1rem; margin: .4rem 0 .9rem 0; font-size: .9rem; }}
      .note.warn {{ border-left-color: {C['ask']}; }}
      .section {{ color: {C['muted']}; font-size: .78rem; font-weight: 500; margin: .8rem 0 .3rem 0; }}
      @media (prefers-reduced-motion: reduce) {{ *, *::before, *::after {{ animation: none !important; transition: none !important; }}
          .wavehead {{ opacity: 1; }} }}
    </style>
    <p class="brand">Market Maker Simulator</p>
    <p class="tagline">A limit order book market maker, tested against simulated and Hawkes-process markets.</p>
    <div class="wavehead"><svg viewBox="0 0 2400 76" preserveAspectRatio="none" aria-hidden="true">
      <path class="c" d="{w3}"/><path class="b" d="{w2}"/><path class="a" d="{w1}"/></svg></div>
    """,
    unsafe_allow_html=True,
)

# ----------------------------------------------------------------------------- settings rail
DEFAULTS = dict(gamma=0.10, sigma=2.0, storms=False, storm_mult=3.0, storms_per_day=2.0, storm_len=10, A=140, k=1.5,
                seed=7, engine="Quick")
for key, val in DEFAULTS.items():
    st.session_state.setdefault(key, val)


def reset():
    st.session_state.update(DEFAULTS)


def new_seed():
    st.session_state["seed"] = int(np.random.default_rng().integers(1, 100000))


with st.sidebar:
    st.markdown("### Settings")
    st.slider("Caution about holding shares", 0.01, 1.00, key="gamma", step=0.01,
              help="Higher means the market maker works harder to keep its shares near zero: less risk, lower average profit.")
    st.slider("Price jumpiness", 0.5, 5.0, key="sigma", step=0.1, help="How violently the price moves. Higher means holding shares is riskier.")
    st.toggle("Add volatile periods", key="storms", help="The market is calm most of the time but randomly enters stormy periods.")
    if st.session_state["storms"]:
        with st.expander("Storm settings"):
            st.slider("Strength (times jumpier)", 1.5, 6.0, key="storm_mult", step=0.5)
            st.slider("Storms per day", 0.5, 5.0, key="storms_per_day", step=0.5)
            st.slider("Length (% of a day)", 3, 30, key="storm_len", step=1)
    with st.expander("Advanced"):
        st.slider("Market activity", 20, 300, key="A", step=10, help="Roughly how many buy and sell orders arrive per day.")
        st.slider("Price sensitivity of traders", 0.5, 3.0, key="k", step=0.1, help="Higher means business disappears faster as your prices get worse.")
        st.radio("Simulation type", ["Quick", "Order book"], key="engine", horizontal=True,
                 help="Quick uses a probability formula. Order book matches orders one by one (slower).")
        st.number_input("Random seed", 1, 99999, key="seed")
        st.button("New random seed", on_click=new_seed, icon=":material/refresh:", type="tertiary")
    st.button("Reset settings", on_click=reset, type="tertiary")

gamma, sigma, k, A = (st.session_state[x] for x in ("gamma", "sigma", "k", "A"))
seed, storms, ORDER_BOOK = int(st.session_state["seed"]), st.session_state["storms"], st.session_state["engine"] == "Order book"
regime_key = ((st.session_state["storm_mult"], st.session_state["storms_per_day"] / DEFAULT_STEPS,
               1.0 / (st.session_state["storm_len"] / 100 * DEFAULT_STEPS)) if storms else None)
avg_sigma = RegimeVolatility(sigma, *regime_key).average_sigma if regime_key else sigma
half_spread = avg_as_spread(gamma, avg_sigma, k, 1.0) / 2


# ----------------------------------------------------------------------------- helpers
def source(text):
    st.markdown(f'<p class="source">{text}</p>', unsafe_allow_html=True)


def note(text, warn=False):
    st.markdown(f'<div class="note{" warn" if warn else ""}">{text}</div>', unsafe_allow_html=True)


def label(text):
    st.markdown(f'<p class="section">{text}</p>', unsafe_allow_html=True)


@contextmanager
def panel(title, sub=""):
    with st.container(border=True):
        st.markdown(f'<div class="ph"><span class="pt">{title}</span><span class="ps">{sub}</span></div>', unsafe_allow_html=True)
        yield


def plot(key, chart_spec):
    viz.chart(key, chart_spec, JS_THEME)


def fmt(x, nd=1, signed=False):
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return "n/a"
    if isinstance(x, float) and np.isinf(x):
        return "no losing days"
    return f"{x:+,.{nd}f}" if signed else f"{x:,.{nd}f}"


@st.cache_data(show_spinner=False)
def run_sim(level2, strategy, n_runs, seed, gamma, sigma, k, A, regime_key, half_spread, record):
    regime = dict(stress_mult=regime_key[0], p_enter=regime_key[1], p_exit=regime_key[2]) if regime_key else None
    if level2:
        return simulate_level2(strategy, n_runs=n_runs, seed=seed, gamma=gamma, sigma=sigma, k=k, lam=float(A),
                               half_spread=half_spread, regime=regime, record_first=record)
    return simulate_level1(strategy, n_runs=n_runs, seed=seed, gamma=gamma, sigma=sigma, k=k, A=float(A),
                           half_spread=half_spread, regime=regime, record_first=record)


# ----------------------------------------------------------------------------- pages
tab_sim, tab_lab, tab_bt, tab_method = st.tabs([":material/show_chart: Simulator", ":material/science: Strategy lab",
                                                ":material/candlestick_chart: Backtest", ":material/menu_book: Method"])

# ============================================================== Simulator
with tab_sim:
    strategy = st.radio("Strategy", list(STRATEGIES), format_func=STRATEGIES.get, horizontal=True, key="watch")
    st.caption(STRATEGY_HELP[strategy])
    res = run_sim(ORDER_BOOK, strategy, 1, seed, gamma, sigma, k, A, regime_key, half_spread, True)
    p = res["path"]
    with st.container(border=True):
        c = st.columns(4)
        c[0].metric("Profit at close", fmt(float(res["pnl"][0]), 1, True))
        c[1].metric("Shares at close", f"{int(res['q'][0]):+d}")
        c[2].metric("Trades made", f"{int(res['n_fills'][0])}")
        c[3].metric("Average gap", f"{float(np.mean(p['ask'] - p['bid'])):.2f}")
    dq = np.diff(np.concatenate([[0], p["q"]]))
    buys, sells = dq > 0, dq < 0
    with panel("Price and quotes", "the shaded band is the market maker's quoted spread; dots are trades"):
        plot("sim_price", viz.spec([
            viz.band("Quoted spread", p["t"], p["bid"], p["ask"], C["accent_text"], 0.16),
            viz.line("Market price", p["t"], p["s"], C["price"], 2.1),
            viz.line("Our bid", p["t"], p["bid"], C["bid"], 1.0, smooth=False),
            viz.line("Our ask", p["t"], p["ask"], C["ask"], 1.0, smooth=False),
            viz.points("Bought", p["t"][buys], p["bid"][buys], C["bid"], 3.8),
            viz.points("Sold", p["t"][sells], p["ask"][sells], C["ask"], 3.8)],
            height=340, xlabel="Time through the trading day", ylabel="Price", xformat="num"))
    a, b = st.columns(2)
    with a:
        with panel("Shares held", "positive means owned, negative means owed"):
            plot("sim_inv", viz.spec([viz.steps("Shares held", p["t"], p["q"], C["inv"])], height=210, ylabel="Shares", legend=False))
    with b:
        with panel("Profit so far", "marked at the current price"):
            plot("sim_pnl", viz.spec([viz.area("Profit", p["t"], p["pnl"], C["price"], 0.0, 0.14)], height=210, ylabel="Profit", legend=False))
    if storms:
        with panel("Market jumpiness", "the hidden truth against what the strategy measures"):
            series = [viz.area("Actual jumpiness", p["t"], p["sigma"], C["vol"], 0.0, 0.2, 1.4, smooth=False)]
            if strategy == "vol_aware":
                series.append(viz.line("Strategy's estimate", p["t"], p["sigma_hat"], C["price"], 1.8))
            plot("sim_vol", viz.spec(series, height=200, ylabel="Jumpiness", ymin=0))
    source(f"Source: simulation, {'order-book' if ORDER_BOOK else 'quick'} engine, {STRATEGIES[strategy].lower()}, seed {seed}. Simulated prices, not market data.")

# ============================================================== Strategy lab
with tab_lab:
    sub_cmp, sub_pol, sub_fill = st.tabs(["Compare", "Quote policy", "Fill curve"])

    # ---- Compare
    with sub_cmp:
        if ORDER_BOOK:
            n_days = st.slider("Days to simulate", 20, 150, 40, step=10, key="cmp_days_ob")
            go = st.button("Run comparison", type="primary", icon=":material/play_arrow:")
            key = (n_days, seed, gamma, sigma, k, A, regime_key)
            if go:
                with st.spinner("Simulating"):
                    st.session_state["cmp"] = (key, {s: run_sim(True, s, n_days, seed, gamma, sigma, k, A, regime_key, half_spread, False) for s in STRATEGIES})
            stored = st.session_state.get("cmp")
            results = stored[1] if stored and stored[0] == key else None
            if results is None:
                note("Press Run comparison. Changing a setting clears the previous result.")
        else:
            n_days = st.slider("Days to simulate", 200, 4000, 2000, step=200, key="cmp_days")
            results = {s: run_sim(False, s, n_days, seed, gamma, sigma, k, A, regime_key, half_spread, False) for s in STRATEGIES}
        if results is not None:
            stats = {s: summarize(r, gamma) for s, r in results.items()}
            best = max(stats, key=lambda s: stats[s]["score"])
            with st.container(border=True):
                st.dataframe(pd.DataFrame({"Strategy": [STRATEGIES[s] for s in stats], "Average profit": [fmt(v["mean"]) for v in stats.values()],
                                           "Typical swing": [fmt(v["std"]) for v in stats.values()], "Worst day": [fmt(v["worst"]) for v in stats.values()],
                                           "Shares left over": [fmt(v["mean_abs_q"]) for v in stats.values()],
                                           "Risk-adjusted score": [fmt(v["score"]) for v in stats.values()]}), hide_index=True)
            note(f"{STRATEGIES[best]} has the best risk-adjusted score: average profit minus a penalty for ups and downs, heavier as caution rises.")
            a, b = st.columns(2)
            allp = np.concatenate([results[s]["pnl"] for s in stats])
            allq = np.concatenate([results[s]["q"] for s in stats])
            with a:
                with panel("Profit distribution", "narrower and taller means more predictable"):
                    ser = []
                    for s in stats:
                        g, d = viz.kde(results[s]["pnl"], lo=allp.min(), hi=allp.max())
                        ser.append(viz.area(STRATEGIES[s], g, d, COLOR[s], 0.0, 0.10, 2.0))
                    plot("cmp_pnl", viz.spec(ser, height=250, xlabel="Profit at close", ylabel="Density", ymin=0))
            with b:
                with panel("Shares left over", "how much inventory each strategy carries out of the day"):
                    ser = []
                    for s in stats:
                        g, d = viz.kde(results[s]["q"], lo=allq.min(), hi=allq.max())
                        ser.append(viz.area(STRATEGIES[s], g, d, COLOR[s], 0.0, 0.10, 2.0))
                    plot("cmp_q", viz.spec(ser, height=250, xlabel="Shares held at close", ylabel="Density", ymin=0))
            with panel("Risk and reward", "each dot is a strategy: further up is more profit, further left is steadier"):
                plot("cmp_rr", viz.spec([viz.points(STRATEGIES[s], [stats[s]["std"]], [stats[s]["mean"]], COLOR[s], 8) for s in stats],
                                        height=240, xlabel="Typical swing in daily profit", ylabel="Average profit"))
            source(f"Source: simulation, {n_days} days per strategy, seed {seed}, identical random numbers for every strategy.")

    # ---- Quote policy
    with sub_pol:
        table = get_quote_table(gamma, k, float(A), 1.0, DEFAULT_STEPS, 20)
        qs = np.arange(-10, 11)
        cols = np.arange(0, DEFAULT_STEPS, 4)
        bid_z = np.array([[float(table.distances(int(i), int(q), avg_sigma)[0]) for i in cols] for q in qs])
        ask_z = np.array([[float(table.distances(int(i), int(q), avg_sigma)[1]) for i in cols] for q in qs])
        zmax = float(max(bid_z.max(), ask_z.max()))
        zmin = float(min(bid_z.min(), ask_z.min()))
        ramp = [C["raised"], C["accent"]]
        note("The exact quotes depend on how many shares are held and how much of the day is left. A long position pushes the bid away "
             "(buying less) and pulls the ask in (selling more).")
        a, b = st.columns(2)
        with a:
            with panel("Bid distance from the price", "darker is closer to the price"):
                plot("pol_bid", viz.heatmap(cols / DEFAULT_STEPS, qs, bid_z, ramp, 300, "Time through the day", "Shares held", "Bid distance", zmin, zmax))
        with b:
            with panel("Ask distance from the price", "darker is closer to the price"):
                plot("pol_ask", viz.heatmap(cols / DEFAULT_STEPS, qs, ask_z, ramp, 300, "Time through the day", "Shares held", "Ask distance", zmin, zmax))
        when = st.slider("Time of day", 0, 95, 0, step=5, format="%d%% through the day", key="pol_when")
        step_i = int(when / 100 * DEFAULT_STEPS)
        tau = 1.0 - step_i / DEFAULT_STEPS
        qf = np.linspace(-10, 10, 41)
        eb, ea = table.distances(step_i, qf.astype(int), avg_sigma)
        spread = gamma * avg_sigma ** 2 * tau + 2 / gamma * np.log1p(gamma / k)
        tb, ta = spread / 2 + qf * gamma * avg_sigma ** 2 * tau, spread / 2 - qf * gamma * avg_sigma ** 2 * tau
        with panel("Quote distance against inventory", "the textbook formula keeps skewing, the exact solution flattens"):
            plot("pol_lines", viz.spec([
                viz.line("Exact bid", qf, eb, C["bid"], 2.2), viz.line("Exact ask", qf, ea, C["ask"], 2.2),
                viz.line("Textbook bid", qf, tb, C["bid"], 1.4, dash="5 4"), viz.line("Textbook ask", qf, ta, C["ask"], 1.4, dash="5 4")],
                height=290, xlabel="Shares held", ylabel="Distance from the price"))
        source(f"Source: exact solution of the model, volatility {avg_sigma:.2f}, caution {gamma:.2f}, price sensitivity {k:.1f}, market activity {A}.")

    # ---- Fill curve
    with sub_fill:
        d = np.linspace(0, 4, 160)
        lam = A * np.exp(-k * d)
        profit_rate = d * lam
        d_star = 1 / k
        a, b = st.columns(2)
        with a:
            with panel("How often a quote is hit", "falls exponentially with distance from the price"):
                plot("fill_rate", viz.spec([viz.area("Fills per day", d, lam, C["accent_text"], 0.0, 0.15, 2.2)],
                                           height=270, xlabel="Distance from the price", ylabel="Fills per day", ymin=0, legend=False))
        with b:
            with panel("Profit per day from one side", "gap earned times how often it is earned"):
                plot("fill_profit", viz.spec([viz.area("Profit per day", d, profit_rate, C["bid"], 0.0, 0.15, 2.2),
                                              viz.points("Best distance", [d_star], [d_star * A * np.exp(-1)], C["price"], 6)],
                                             height=270, xlabel="Distance from the price", ylabel="Profit per day", ymin=0))
        note(f"With these settings the best distance for a risk-neutral market maker is 1/k = {d_star:.2f}. "
             "Quoting closer earns less per trade; quoting farther trades too rarely. Caution pushes real quotes farther out.")
        source("Source: model, fill rate = A exp(-k distance). Change market activity and price sensitivity under Advanced in the settings rail.")

# ============================================================== Backtest
with tab_bt:
    st.markdown("Test the market maker against a synthetic market whose order flow comes from a **Hawkes process**: trades cluster, "
                "buys and sells excite each other, and orders move the price. Every strategy trades the same history.")
    with st.container(border=True):
        c1, c2, c3, c4 = st.columns(4)
        bt_days = c1.slider("Days of history", 80, 300, 160, step=10)
        train_days = c2.slider("Calibration days", 20, 60, 40, step=5, help="Used only to calibrate the fill curve and volatility.")
        bt_seed = c3.number_input("History seed", 1, 99999, 11)
        c4.write("")
        run_it = c4.button("Run backtest", type="primary", icon=":material/play_arrow:")
        with st.expander("Market realism"):
            e1, e2, e3, e4 = st.columns(4)
            branching = e1.slider("Order clustering", 0.0, 0.9, 0.75, step=0.05, help="Average number of further orders each order triggers. Zero means orders arrive at random.")
            self_share = e2.slider("Same-side share", 0.5, 1.0, 0.85, step=0.05, help="How much of the clustering stays on the same side.")
            impact = e3.slider("Price impact", 0.0, 0.30, 0.10, step=0.01, help="How far each order moves the price.")
            act_vol = e4.slider("Day-to-day swings", 0.0, 0.8, 0.40, step=0.05, help="How much busy and quiet days differ.")
    bt_key = (bt_days, train_days, int(bt_seed), branching, self_share, impact, act_vol, gamma)
    if run_it:
        params = HawkesMarketParams(branching=branching, self_share=self_share, impact=impact, activity_vol=act_vol)
        bar = st.progress(0, text="Generating the Hawkes market")
        history = generate_market(bt_days, seed=int(bt_seed), params=params)
        result = run_backtest(history, BacktestConfig(gamma=gamma, train_days=train_days),
                              progress=lambda done, total: bar.progress(done / total, text="Trading the history"))
        bar.empty()
        poisson_fano = fano_factor(generate_market(40, seed=int(bt_seed), params=HawkesMarketParams(branching=0.0)))
        st.session_state["bt"] = dict(key=bt_key, history=history, result=result, facts=diagnostics(history), poisson_fano=poisson_fano)
    bt = st.session_state.get("bt")
    if not bt or bt["key"] != bt_key:
        note("Press Run backtest. Changing a setting clears the previous result.")
    else:
        history, result, facts = bt["history"], bt["result"], bt["facts"]
        n_test, cfg = len(result["test_days"]), result["config"]
        note("Prices and orders come from the Hawkes process, not from downloaded data. Fills are simulated against the order book. Ratios here are far "
             "higher than any real market maker could achieve: there are no fees, no competing market makers and the book refills perfectly. "
             "Compare strategies with each other, not with real figures.", warn=True)
        pick = st.radio("Strategy shown", list(STRATEGIES), format_func=STRATEGIES.get, horizontal=True, index=3, key="tear_pick")
        target_mode = st.radio("Sortino target", ["Half of the average day", "Zero"], horizontal=True, key="sortino_target",
                               help="Days below the target count as bad days. With almost no losing days the zero target gives an infinite ratio.")
        sheets = tear_sheets(result, sortino_target="half_mean" if target_mode.startswith("Half") else 0.0)
        ts = sheets[pick]
        s, d, iv, ser = ts["summary"], ts["decomposition"], ts["inventory"], ts["series"]
        days = np.arange(1, n_test + 1)
        cal = result["calibration"]
        src = (f"Source: Hawkes market, seed {int(bt_seed)}, {bt_days} days ({train_days} calibration, {n_test} test), "
               f"{STRATEGIES[pick].lower()}.")

        t_mkt, t_perf, t_dec, t_inv, t_all = st.tabs(["Market", "Performance", "Decomposition", "Inventory", "Strategies"])

        with t_mkt:
            with st.container(border=True):
                c = st.columns(5)
                c[0].metric("Orders per day", f"{facts['orders_per_day']:.0f}")
                c[1].metric("Order clustering", f"{facts['fano_factor']:.2f}", help=f"1.00 means orders arrive at random. Unclustered reference: {bt['poisson_fano']:.2f}.")
                c[2].metric("Buy/sell persistence", f"{facts['sign_autocorrelation']:+.2f}", help="Correlation between consecutive order directions.")
                c[3].metric("Daily volatility", f"{facts['daily_vol_mean']:.2f}")
                c[4].metric("Volatility clustering", f"{facts['abs_return_autocorrelation']:.2f}", help="Correlation of consecutive absolute price moves.")
            day = st.slider("Day to inspect", 1, bt_days, min(cfg.train_days + 10, bt_days), key="flow_day")
            tape = history.days[day - 1]
            counts_b = np.array([(tape.events(i)[0] > 0).sum() for i in range(history.params.n_steps)], float)
            counts_s = np.array([(tape.events(i)[0] < 0).sum() for i in range(history.params.n_steps)], float)
            smooth = lambda v: np.convolve(np.pad(v, 2, mode="edge"), np.ones(5) / 5, mode="valid")
            tt = np.arange(history.params.n_steps) / history.params.n_steps
            a, b = st.columns(2)
            with a:
                with panel("Order flow through the day", "buys above the line, sells below; bursts are the Hawkes clustering"):
                    plot("mkt_flow", viz.spec([viz.area("Market buys", tt, smooth(counts_b), C["bid"], 0.0, 0.2, 1.8),
                                               viz.area("Market sells", tt, -smooth(counts_s), C["ask"], 0.0, 0.2, 1.8)],
                                              height=250, xlabel="Time through the day", ylabel="Orders per step"))
            with b:
                with panel("Price on the same day", "orders push the price, partly for good and partly for a while"):
                    plot("mkt_price", viz.spec([viz.area("Price", np.arange(len(tape.mid)) / history.params.n_steps, tape.mid, C["price"],
                                                         float(tape.mid.min()) - 0.3, 0.10, 2.0)],
                                               height=250, xlabel="Time through the day", ylabel="Price", legend=False))
            vol = result["volatility"]
            a, b = st.columns(2)
            with a:
                with panel("Volatility tracking", "Yang-Zhang estimate known at each open, against what happened"):
                    plot("mkt_vol", viz.spec([viz.line("Actual that day", days, vol["realized"], C["muted"], 1.3),
                                              viz.line(f"Yang-Zhang ({cfg.yz_window}-day)", days, vol["yang_zhang"], C["vol"], 2.4),
                                              viz.line("Fixed assumption", days, np.full(n_test, vol["static"]), C["base"], 1.3, dash="5 4")],
                                             height=250, xlabel="Test day", ylabel="Volatility"))
            with b:
                with panel("Fill curve fitted from the data", f"A = {cal['A']:.0f}, k = {cal['k']:.2f}, R squared {cal['r2']:.3f}"):
                    dd = np.linspace(cal["delta"].min(), cal["delta"].max(), 80)
                    plot("mkt_fill", viz.spec([viz.line("Fitted curve", dd, cal["A"] * np.exp(-cal["k"] * dd), C["accent_text"], 2.2),
                                               viz.points("Measured", cal["delta"], cal["rate"], C["price"], 3.6)],
                                              height=250, xlabel="Distance from the price", ylabel="Fills per day", ymin=0))
            source(src + f" Day {day} shown above.")

        with t_perf:
            with st.container(border=True):
                c = st.columns(6)
                c[0].metric("Average daily PnL", fmt(s["mean_daily"], 1, True))
                c[1].metric("Sharpe ratio", fmt(s["sharpe"], 1), help=f"Annualised with 252 days. Standard error about {s['sharpe_se']:.1f}.")
                c[2].metric("Sortino ratio", fmt(s["sortino"], 1), help=f"Target {s['sortino_target']:.1f} per day; {s['downside_days']:.0%} of days fell below it.")
                c[3].metric("Max drawdown", fmt(s["max_drawdown"], 1))
                c[4].metric("Worst day", fmt(s["worst_day"], 1, True))
                c[5].metric("Profit days", f"{s['win_rate']:.0%}")
            with panel("Cumulative profit", "all strategies, the selected one in full colour"):
                plot("perf_cum", viz.spec([viz.line(STRATEGIES[n], days, sh["series"]["cum_pnl"], COLOR[n], 3.0 if n == pick else 1.4)
                                           for n, sh in sheets.items()], height=300, xlabel="Test day", ylabel="Cumulative PnL"))
            a, b = st.columns(2)
            with a:
                with panel("Daily profit distribution", "each strategy's spread of day results"):
                    lo = min(float(r["pnl"].min()) for r in result["strategies"].values()); hi = max(float(r["pnl"].max()) for r in result["strategies"].values())
                    sr = []
                    for n, r in result["strategies"].items():
                        g, dens = viz.kde(r["pnl"], lo=lo, hi=hi)
                        sr.append(viz.area(STRATEGIES[n], g, dens, COLOR[n], 0.0, 0.08, 2.4 if n == pick else 1.3))
                    plot("perf_dist", viz.spec(sr, height=250, xlabel="Daily PnL", ylabel="Density", ymin=0))
            with b:
                with panel("Drawdown", "how far cumulative profit sits below its best so far"):
                    plot("perf_dd", viz.spec([viz.area("Drawdown", days, -ser["drawdown"], C["negative"], 0.0, 0.2, 1.8)],
                                             height=250, xlabel="Test day", ylabel="Below peak", ymin=-1.15 * max(s["max_drawdown"], 1.0), ymax=0.15 * max(s["max_drawdown"], 1.0), legend=False))
            source(src + f" Sharpe and Sortino use daily PnL with constant capital, annualised with 252 days (Sharpe standard error {s['sharpe_se']:.1f}).")

        with t_dec:
            a, b = st.columns([2, 3])
            with a:
                with panel("PnL decomposition", "per day, and share of day-to-day variance"):
                    st.dataframe(pd.DataFrame({"Component": ["Spread captured", "Adverse selection", "Inventory carry", "Total"],
                                               "Per day": [fmt(d[x]["per_day"], 2, True) for x in ("spread", "adverse_selection", "inventory_carry", "total")],
                                               "Variance share": [f"{d[x]['variance_share']:.0%}" for x in ("spread", "adverse_selection", "inventory_carry", "total")]}),
                                 hide_index=True)
                    st.caption(f"Adverse selection is the price move over the next {cfg.markout_steps} steps after each fill. "
                               "Inventory carry is the rest of the profit and loss from holding shares. The parts add up exactly to the total.")
            with b:
                with panel("Where the profit builds up", "cumulative, by component"):
                    plot("dec_cum", viz.spec([viz.area("Spread captured", days, ser["cum_spread"], C["bid"], 0.0, 0.16, 2.2),
                                              viz.area("Adverse selection", days, ser["cum_adverse"], C["ask"], 0.0, 0.16, 2.2),
                                              viz.area("Inventory carry", days, ser["cum_carry"], C["inv"], 0.0, 0.16, 2.2),
                                              viz.line("Total", days, ser["cum_pnl"], C["price"], 2.0, dash="5 4")],
                                             height=300, xlabel="Test day", ylabel="Cumulative"))
            names = list(STRATEGIES)
            xs = np.arange(len(names))
            with panel("Components per day, by strategy", "grouped by component"):
                comp = lambda key_: [sheets[n]["decomposition"][key_]["per_day"] for n in names]
                plot("dec_bars", viz.spec([viz.bars("Spread captured", xs - 0.27, comp("spread"), C["bid"], 0.22),
                                           viz.bars("Adverse selection", xs, comp("adverse_selection"), C["ask"], 0.22),
                                           viz.bars("Inventory carry", xs + 0.27, comp("inventory_carry"), C["inv"], 0.22)],
                                          height=270, ylabel="PnL per day", xticks=[dict(pos=i, label=STRATEGIES[n]) for i, n in enumerate(names)]))
            source(src)

        with t_inv:
            with st.container(border=True):
                c = st.columns(6)
                c[0].metric("Avg shares", f"{iv['mean_abs']:.1f}", help="Mean absolute number of shares held over every decision step.")
                c[1].metric("RMS shares", f"{iv['rms']:.1f}", help="Root mean square: weights large positions more.")
                c[2].metric("Peak", f"{iv['peak_abs']:.0f}")
                c[3].metric("Time flat", f"{iv['pct_flat']:.0%}")
                c[4].metric("Time at limit", f"{iv['pct_at_limit']:.1%}")
                c[5].metric("Variance share", f"{iv['inv_pnl_variance_share']:.0%}", help="Share of the day-to-day variation in profit that comes from price moves on held shares.")
            qmax = 12
            grid = np.arange(-qmax, qmax + 1)
            with panel("How long each strategy sits at each inventory", "share of time, shares capped at 12 either way"):
                sr = []
                for n in STRATEGIES:
                    counts = np.bincount(np.clip(result["strategies"][n]["q_path"].ravel(), -qmax, qmax) + qmax, minlength=2 * qmax + 1)
                    sr.append(viz.area(STRATEGIES[n], grid, counts / counts.sum(), COLOR[n], 0.0, 0.08, 2.6 if n == pick else 1.3))
                plot("inv_dist", viz.spec(sr, height=270, xlabel="Shares held", ylabel="Share of time", ymin=0))
            inv_day = st.slider("Day to inspect", 1, n_test, 1, key="inv_day")
            qp = result["strategies"][pick]["q_path"][inv_day - 1]
            with panel("Inventory through one day", f"{STRATEGIES[pick].lower()}, test day {inv_day}"):
                plot("inv_path", viz.spec([viz.steps("Shares held", np.arange(len(qp)) / len(qp), qp, C["inv"])], height=220,
                                          xlabel="Time through the day", ylabel="Shares", legend=False))
            source(src)

        with t_all:
            rows = []
            for n, sh in sheets.items():
                su, de, iv_ = sh["summary"], sh["decomposition"], sh["inventory"]
                rows.append({"Strategy": STRATEGIES[n], "PnL per day": fmt(su["mean_daily"]), "Swing": fmt(su["std_daily"]), "Sharpe": fmt(su["sharpe"]),
                             "Sortino": fmt(su["sortino"]), "Max drawdown": fmt(su["max_drawdown"]), "Spread": fmt(de["spread"]["per_day"]),
                             "Adverse": fmt(de["adverse_selection"]["per_day"]), "Carry": fmt(de["inventory_carry"]["per_day"]),
                             "Avg shares": fmt(iv_["mean_abs"]), "Trades": fmt(su["fills_per_day"], 0)})
            with st.container(border=True):
                st.dataframe(pd.DataFrame(rows), hide_index=True)
            names = list(STRATEGIES)
            xt = [dict(pos=i, label=STRATEGIES[n]) for i, n in enumerate(names)]
            a, b = st.columns(2)
            with a:
                with panel("Sharpe ratio", "annualised; the standard error is in the tear sheet"):
                    plot("all_sharpe", viz.spec([viz.bars("Sharpe", range(4), [sheets[n]["summary"]["sharpe"] for n in names], C["accent"], 0.6,
                                                          colors=[COLOR[n] for n in names])], height=260, xticks=xt, ymin=0, legend=False))
            with b:
                with panel("Risk and reward", "swing in daily profit against average daily profit"):
                    plot("all_rr", viz.spec([viz.points(STRATEGIES[n], [sheets[n]["summary"]["std_daily"]], [sheets[n]["summary"]["mean_daily"]], COLOR[n], 8)
                                             for n in names], height=260, xlabel="Swing in daily profit", ylabel="Average daily profit"))
            raw = result["strategies"][pick]
            export = pd.DataFrame({"test_day": days, "pnl": raw["pnl"], "spread": raw["edge"], "adverse_selection": raw["markout"],
                                   "inventory_carry": raw["inv_pnl"] - raw["markout"], "fills": raw["fills"], "mean_abs_shares": np.abs(raw["q_path"]).mean(axis=1)})
            st.download_button("Download daily results", export.to_csv(index=False), f"backtest_{pick}.csv", "text/csv", icon=":material/download:")
            source(src)

# ============================================================== Method
with tab_method:
    left, right = st.columns([1, 2])
    with left:
        st.markdown("### Method")
        st.caption("How the market maker, the market and the report work.")
    with right:
        with st.expander("What a market maker does", expanded=True):
            st.markdown("A market maker keeps a **bid** (a price to buy) and an **ask** (a price to sell) in the order book, and earns the gap between them each "
                        "time both are used. The risk is the shares it ends up holding: if the price moves against that inventory, it loses money.")
        with st.expander("The four strategies"):
            st.markdown("- **Fixed gap** quotes symmetrically around the price.\n"
                        "- **Textbook formula** is the Avellaneda-Stoikov closed form. It shifts both quotes against its inventory.\n"
                        "- **Exact formula** solves the same model without the small-inventory approximation. The textbook gap grows too wide when volatility is high.\n"
                        "- **Volatility-aware** is the exact solution fed with a running volatility estimate.")
            st.latex(r"r = s - q\,\gamma\,\sigma^{2}(T-t),\qquad \text{gap} = \gamma\sigma^{2}(T-t) + \tfrac{2}{\gamma}\ln\!\left(1+\tfrac{\gamma}{k}\right)")
        with st.expander("Yang-Zhang volatility"):
            st.markdown("The estimate combines three pieces from daily open, high, low and close prices: the variance of overnight gaps, the variance of open-to-close returns, "
                        "and the Rogers-Satchell range term. The backtest drops the overnight term, because the market maker is flat overnight, and uses the estimate from "
                        "earlier days as the starting volatility each morning. A moving average then updates it through the day.")
            st.latex(r"\sigma^{2}_{YZ} = \sigma^{2}_{o} + k\,\sigma^{2}_{c} + (1-k)\,\sigma^{2}_{RS},\qquad k = \frac{0.34}{1.34 + (n+1)/(n-1)}")
        with st.expander("The Hawkes market"):
            st.markdown("A Hawkes process is a random sequence of events in which each event raises the chance of more events for a while. Here buys and sells both excite "
                        "buys and sells, with most of the excitation staying on the same side. The generated market also has a busy open and close, heavy-tailed order sizes, "
                        "price impact that is partly permanent and partly temporary, busy and quiet days that persist, and overnight gaps. It is generated once, so every strategy sees identical orders and prices.")
        with st.expander("The tear sheet"):
            st.markdown("- **Sharpe ratio:** average daily PnL over its standard deviation, annualised with 252 days.\n"
                        "- **Sortino ratio:** like Sharpe, but only days below a target count as risk.\n"
                        "- **PnL decomposition:** spread captured, plus adverse selection (the price move over the next few steps after each fill), plus inventory carry. They add up exactly to total PnL.\n"
                        "- **Inventory risk:** how many shares were held, for how long, and how much of the variation in profit they cause.")
        with st.expander("About the charts"):
            st.markdown("Curves are smoothed for display with a monotone spline, so lines flow without overshooting. Tooltips and tables show the exact numbers. "
                        "A chart morphs from its old shape when its data changes, and redraws when you open its tab.")
        with st.expander("Limits"):
            st.markdown("- The market is simulated. It resembles real order flow in several measurable ways, but it is not real data, and no result here shows that a strategy would make money in a real market.\n"
                        "- Sharpe and Sortino ratios are inflated: no fees, no competing market makers, instant quote refresh and a perfectly refilled book.\n"
                        "- Fills assume a fixed amount of other traders' depth in front of each quote.")
st.caption("Simulation only. Not financial advice.")
