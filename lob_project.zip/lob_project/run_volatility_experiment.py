"""run_volatility_experiment.py -- does the volatility handling actually help?

Scenario A  constant volatility that the strategy KNOWS (sigma = 2, 4, 6): textbook formula vs exact quotes
Scenario B  calm markets with random storms: symmetric / textbook / exact / volatility-aware
Scenario C  the same storm market in the full order-book simulator (Level 2)

Every comparison uses identical random numbers for all strategies (common random numbers).
The score is the certainty equivalent at the market maker's own risk aversion (higher = better).
Writes results_volatility.json and two figures into figs_vol/.
"""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from metrics import certainty_equivalent, summarize
from sim import avg_as_spread, simulate_level1, simulate_level2
from volatility import DEFAULT_REGIME, RegimeVolatility

os.makedirs("figs_vol", exist_ok=True)
GAMMA, SIGMA, K, A = 0.1, 2.0, 1.5, 140.0
MILD = DEFAULT_REGIME                                              # 3x storms, ~2 per day, ~10% of a day each
SEVERE = dict(stress_mult=5.0, p_enter=0.01, p_exit=0.033)         # 5x storms, ~2 per day, ~15% of a day each
NAVY, TEAL, ORANGE, RED, GRAY = "#1f3a5f", "#2a9d8f", "#e07a1f", "#c0392b", "#6b7280"
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.alpha": 0.25, "savefig.dpi": 200})
rows = lambda d: {k: float(v) for k, v in d.items()}
results = {}


def bootstrap_ce_gain(pnl_a, pnl_b, n_boot=400, seed=0):
    """Mean and 95% interval of CE(a) - CE(b), resampling days in pairs."""
    rng = np.random.default_rng(seed)
    n = len(pnl_a)
    diffs = []
    for _ in range(n_boot):
        idx = rng.integers(0, n, n)
        diffs.append(certainty_equivalent(pnl_a[idx], GAMMA) - certainty_equivalent(pnl_b[idx], GAMMA))
    return float(np.mean(diffs)), float(np.percentile(diffs, 2.5)), float(np.percentile(diffs, 97.5))


# ---------------------------------------------------------------------------- Scenario A
results["A"] = {}
for sigma in (2.0, 4.0, 6.0):
    runs = {s: simulate_level1(s, n_runs=3000, seed=5, sigma=sigma, gamma=GAMMA, k=K, A=A) for s in ("as", "exact")}
    results["A"][str(sigma)] = {s: rows(summarize(r, GAMMA)) for s, r in runs.items()}
    results["A"][str(sigma)]["gain"] = bootstrap_ce_gain(runs["exact"]["pnl"], runs["as"]["pnl"])

# ---------------------------------------------------------------------------- Scenario B
results["B"] = {}
for name, regime in (("mild", MILD), ("severe", SEVERE)):
    avg_sigma = RegimeVolatility(SIGMA, **regime).average_sigma
    half = avg_as_spread(GAMMA, avg_sigma, K, 1.0) / 2           # symmetric baseline: same average spread
    runs = {s: simulate_level1(s, n_runs=4000, seed=9, sigma=SIGMA, gamma=GAMMA, k=K, A=A, regime=regime, half_spread=half)
            for s in ("sym", "as", "exact", "vol_aware")}
    entry = {s: rows(summarize(r, GAMMA)) for s, r in runs.items()}
    entry["gain_vol_aware_vs_exact"] = bootstrap_ce_gain(runs["vol_aware"]["pnl"], runs["exact"]["pnl"])
    entry["gain_vol_aware_vs_as"] = bootstrap_ce_gain(runs["vol_aware"]["pnl"], runs["as"]["pnl"])
    results["B"][name] = entry

# ---------------------------------------------------------------------------- Scenario C (order book)
l2 = {s: simulate_level2(s, n_runs=120, seed=300, sigma=SIGMA, gamma=GAMMA, k=K, regime=SEVERE)
      for s in ("as", "exact", "vol_aware")}
results["C"] = {s: rows(summarize(r, GAMMA)) for s, r in l2.items()}
results["C"]["gain_vol_aware_vs_exact"] = bootstrap_ce_gain(l2["vol_aware"]["pnl"], l2["exact"]["pnl"])
results["C"]["gain_vol_aware_vs_as"] = bootstrap_ce_gain(l2["vol_aware"]["pnl"], l2["as"]["pnl"])

json.dump(results, open("results_volatility.json", "w"), indent=1)

# ---------------------------------------------------------------------------- figure 1: one stormy day
best_seed, best_storm = 0, -1
for seed in range(1, 60):                                          # find a day with a clear storm to show
    day = simulate_level1("vol_aware", n_runs=1, seed=seed, gamma=GAMMA, k=K, A=A, regime=SEVERE, record_first=True)
    storm = float((day["path"]["sigma"] > SIGMA * 2).mean())
    if 0.1 < storm < 0.35 and storm > best_storm:
        best_seed, best_storm = seed, storm
path = simulate_level1("vol_aware", n_runs=1, seed=best_seed, gamma=GAMMA, k=K, A=A, regime=SEVERE, record_first=True)["path"]
fig, ax = plt.subplots(3, 1, figsize=(7.4, 7), sharex=True, gridspec_kw={"height_ratios": [2.2, 1, 1.3]})
ax[0].plot(path["t"], path["s"], color=NAVY, lw=1.5, label="market price")
ax[0].plot(path["t"], path["bid"], color=TEAL, lw=0.9, label="our bid")
ax[0].plot(path["t"], path["ask"], color=ORANGE, lw=0.9, label="our ask")
ax[0].set_ylabel("price"); ax[0].legend(ncol=3, frameon=False, loc="upper left")
ax[1].step(path["t"], path["q"], color=RED, where="post"); ax[1].axhline(0, color="k", lw=0.6); ax[1].set_ylabel("shares held")
ax[2].step(path["t"], path["sigma"], color=GRAY, where="post", label="true volatility (hidden)")
ax[2].plot(path["t"], path["sigma_hat"], color=NAVY, lw=1.4, label="strategy's running estimate")
ax[2].set_ylabel("volatility"); ax[2].set_xlabel("time (one trading day)"); ax[2].legend(frameon=False, loc="upper left")
fig.tight_layout(); fig.savefig("figs_vol/fig_vol_day.png"); plt.close(fig)

# ---------------------------------------------------------------------------- figure 2: scores
labels = ["constant\nsigma=2", "constant\nsigma=4", "constant\nsigma=6", "mild\nstorms", "severe\nstorms"]
series = {
    "textbook formula": [results["A"][s]["as"]["score"] for s in ("2.0", "4.0", "6.0")] + [results["B"][m]["as"]["score"] for m in ("mild", "severe")],
    "exact quotes": [results["A"][s]["exact"]["score"] for s in ("2.0", "4.0", "6.0")] + [results["B"][m]["exact"]["score"] for m in ("mild", "severe")],
    "exact + volatility-aware": [None] * 3 + [results["B"][m]["vol_aware"]["score"] for m in ("mild", "severe")],
}
fig, ax = plt.subplots(figsize=(7.4, 3.4))
width = 0.26
for j, (name, color) in enumerate(zip(series, (ORANGE, TEAL, NAVY))):
    xs = [i + (j - 1) * width for i, v in enumerate(series[name]) if v is not None]
    ys = [v for v in series[name] if v is not None]
    ax.bar(xs, ys, width, color=color, label=name)
ax.set_xticks(range(5)); ax.set_xticklabels(labels); ax.set_ylabel("risk-adjusted score (higher is better)")
ax.legend(frameon=False, ncol=3, loc="upper center", bbox_to_anchor=(0.5, 1.14))
fig.tight_layout(); fig.savefig("figs_vol/fig_vol_scores.png"); plt.close(fig)

print(json.dumps(results, indent=1))
