"""sim.py -- market-making simulators built around the Avellaneda-Stoikov (AS) model.

Level 1: fills are random events with probability ~ A*exp(-k*delta)*dt  (the model's own world).
Level 2: fills come from real market orders sweeping a real limit order book (orderbook.py).

Strategies (the `strategy` argument)
    "sym"        symmetric quotes around the mid price with a fixed half-spread (the baseline)
    "as"         the textbook closed-form Avellaneda-Stoikov quotes, with a FIXED volatility
    "exact"      the exact optimal quotes of the same model (optimal.py), with a FIXED volatility
    "vol_aware"  the exact quotes, but the volatility is re-measured every step (volatility.py)

Market volatility (the `regime` argument)
    None                          constant volatility `sigma` (the textbook model)
    dict(stress_mult, p_enter,    calm periods at `sigma`, with random storms in which prices are
         p_exit)                  `stress_mult` times jumpier (see volatility.py)
"""
import math
from functools import lru_cache

import numpy as np

from optimal import ExactQuoteTable
from orderbook import OrderBook
from volatility import EwmaVolatility, RegimeVolatility

DEFAULT_STEPS = 200
DEFAULT_INVENTORY_LIMIT = 20            # the exact strategies never hold more than this many shares
STRATEGIES = ("sym", "as", "exact", "vol_aware")


# ----------------------------------------------------------------------------- closed-form AS
def as_quotes(mid, q, tau, gamma, sigma, k):
    """Textbook Avellaneda-Stoikov quotes. Works for floats or numpy arrays.
    Returns (bid, ask, reservation_price, total_spread)."""
    reservation = mid - q * gamma * sigma ** 2 * tau
    spread = gamma * sigma ** 2 * tau + (2.0 / gamma) * np.log1p(gamma / k)
    return reservation - spread / 2, reservation + spread / 2, reservation, spread


def avg_as_spread(gamma, sigma, k, T):
    """Time-average of the closed-form AS spread over [0, T] (for a fair symmetric baseline)."""
    return gamma * sigma ** 2 * T / 2 + (2.0 / gamma) * math.log1p(gamma / k)


# ----------------------------------------------------------------------------- strategy objects
@lru_cache(maxsize=8)
def get_quote_table(gamma, k, A, T, n_steps, q_max):
    """The exact-quote table is slightly expensive to build, so build each one only once."""
    return ExactQuoteTable(gamma, k, A, T, n_steps, q_max)


class Quoter:
    """Turns (time step, mid price, inventory, volatility estimate) into a (bid, ask) pair for one
    named strategy. Both simulators use it, so a strategy is implemented in exactly one place."""

    def __init__(self, strategy, gamma, k, A, T, n_steps, sigma_assumed, half_spread=None, q_limit=None):
        if strategy not in STRATEGIES:
            raise ValueError(f"strategy must be one of {STRATEGIES}, got {strategy!r}")
        if strategy == "sym" and half_spread is None:
            raise ValueError("the 'sym' strategy needs a half_spread")
        self.strategy, self.gamma, self.k = strategy, gamma, k
        self.T, self.dt = T, T / n_steps
        self.sigma_assumed, self.half_spread = sigma_assumed, half_spread
        self.table = None
        if strategy in ("exact", "vol_aware"):
            self.table = get_quote_table(gamma, k, A, T, n_steps, q_limit or DEFAULT_INVENTORY_LIMIT)

    def quotes(self, step, mid, q, estimator):
        if self.strategy == "sym":
            return mid - self.half_spread, mid + self.half_spread
        if self.strategy == "as":
            bid, ask, _, _ = as_quotes(mid, q, self.T - step * self.dt, self.gamma, self.sigma_assumed, self.k)
            return bid, ask
        sigma = estimator.sigma if self.strategy == "vol_aware" else self.sigma_assumed
        bid_dist, ask_dist = self.table.distances(step, q, sigma)
        return mid - bid_dist, mid + ask_dist


# ----------------------------------------------------------------------------- Level 1
def simulate_level1(strategy, n_runs=1000, T=1.0, n_steps=DEFAULT_STEPS, s0=100.0, sigma=2.0,
                    A=140.0, k=1.5, gamma=0.1, half_spread=None, eta=0.0, q_max=None,
                    regime=None, sigma_assumed=None, ewma_decay=0.95, seed=0, record_first=False):
    """Vectorised Monte Carlo over n_runs independent days (one array entry per day).

    sigma          the TRUE volatility (the calm level when `regime` is given)
    sigma_assumed  the volatility the strategy believes at the start (default: `sigma`)
    eta            adverse selection: after our ask is hit the price rises by eta, after our bid is
                   hit it falls by eta, on top of the ordinary random move."""
    rng = np.random.default_rng(seed)
    dt = T / n_steps
    sigma_assumed = sigma if sigma_assumed is None else sigma_assumed
    quoter = Quoter(strategy, gamma, k, A, T, n_steps, sigma_assumed, half_spread, q_max)
    market = RegimeVolatility(sigma, size=n_runs, **regime) if regime else None
    estimator = EwmaVolatility(sigma_assumed, ewma_decay, size=n_runs)

    s = np.full(n_runs, s0)
    q, cash = np.zeros(n_runs), np.zeros(n_runs)
    edge = np.zeros(n_runs)          # sum of (distance from mid) over all fills = "spread PnL"
    inv_pnl = np.zeros(n_runs)       # sum of q * (price change)            = "inventory PnL"
    n_fills = np.zeros(n_runs)
    keys = ("t", "s", "bid", "ask", "q", "pnl", "sigma", "sigma_hat")
    path = {key: [] for key in keys} if record_first else None

    for i in range(n_steps):
        true_sigma = market.sigma if market else np.full(n_runs, sigma)
        bid, ask = quoter.quotes(i, s, q, estimator)
        d_b, d_a = s - bid, ask - s                                  # distances from mid
        p_b = np.clip(1 - np.exp(-A * np.exp(-k * d_b) * dt), 0, 1)  # P(bid is hit this step)
        p_a = np.clip(1 - np.exp(-A * np.exp(-k * d_a) * dt), 0, 1)
        hit_b = rng.random(n_runs) < p_b
        hit_a = rng.random(n_runs) < p_a
        if q_max is not None:                                        # hard inventory limits
            hit_b &= q < q_max
            hit_a &= q > -q_max
        cash -= hit_b * bid;  q += hit_b;  edge += hit_b * d_b
        cash += hit_a * ask;  q -= hit_a;  edge += hit_a * d_a
        n_fills += hit_b + hit_a
        if record_first:
            for key, val in zip(keys, (i * dt, s[0], np.ravel(bid)[0], np.ravel(ask)[0], q[0],
                                       cash[0] + q[0] * s[0], true_sigma[0], estimator.sigma[0])):
                path[key].append(val)
        ds = true_sigma * math.sqrt(dt) * rng.standard_normal(n_runs) + eta * (hit_a.astype(float) - hit_b)
        inv_pnl += q * ds
        s = s + ds
        estimator.update(ds, dt)                                     # the strategy sees the move...
        if market:
            market.step(rng)                                         # ...and the market may change mood

    pnl = cash + q * s
    assert np.allclose(pnl, edge + inv_pnl), "PnL decomposition identity failed"
    out = dict(pnl=pnl, q=q, edge=edge, inv_pnl=inv_pnl, n_fills=n_fills, s_final=s)
    if record_first:
        out["path"] = {key: np.array(v) for key, v in path.items()}
    return out


# ----------------------------------------------------------------------------- Level 2
def _fresh_book(B, levels, bg_depth, bid_i, ask_i):
    """Other participants' resting orders (bg_depth shares on each tick level around the background
    mid B) plus our live quotes (1 share each; None = not quoting). Built before EVERY market order,
    which mimics other participants instantly replenishing the book after each trade."""
    book = OrderBook()
    for j in range(1, levels + 1):
        book.add_limit("bid", B - j, bg_depth, "bg")
        book.add_limit("ask", B + j, bg_depth, "bg")
    if bid_i is not None:
        book.add_limit("bid", bid_i, 1, "MM")      # added last => at the BACK of its price queue
    if ask_i is not None:
        book.add_limit("ask", ask_i, 1, "MM")
    return book


def _run_level2_once(quoter, rng, T, n_steps, s0, sigma, tick, bg_depth, mean_mo, lam,
                     levels, informed_rate, q_max, regime, sigma_assumed, ewma_decay, record):
    dt = T / n_steps
    market = RegimeVolatility(sigma, **regime) if regime else None
    estimator = EwmaVolatility(sigma_assumed, ewma_decay)
    S, q, cash, edge, inv_pnl, n_fills = s0, 0, 0.0, 0.0, 0.0, 0
    keys = ("t", "s", "bid", "ask", "q", "pnl", "sigma", "sigma_hat")
    path = {key: [] for key in keys} if record else None

    for i in range(n_steps):
        true_sigma = float(market.sigma) if market else sigma
        B = int(round(S / tick))                                     # background mid, in ticks

        # --- our quotes (prices in ticks; size 1 share each) ---
        bid, ask = quoter.quotes(i, S, q, estimator)
        bid_i = min(int(math.floor(bid / tick + 1e-9)), B)           # round away from the mid,
        ask_i = max(int(math.ceil(ask / tick - 1e-9)), B)            # never cross the background
        if ask_i <= bid_i:
            ask_i = bid_i + 1
        bid_live = bid_i if (q_max is None or q < q_max) else None   # inventory limits
        ask_live = ask_i if (q_max is None or q > -q_max) else None

        # --- the random world for this step (drawn in a strategy-independent order) ---
        n_buy, n_sell = rng.poisson(lam * dt), rng.poisson(lam * dt)
        sizes_buy = np.ceil(rng.exponential(mean_mo, n_buy)).astype(int)
        sizes_sell = np.ceil(rng.exponential(mean_mo, n_sell)).astype(int)
        z = rng.standard_normal()
        informed = rng.random() < informed_rate * dt
        inf_size = int(math.ceil(rng.exponential(mean_mo)))

        orders = [("bid", m) for m in sizes_buy] + [("ask", m) for m in sizes_sell]
        if informed:                                                 # trades in the direction of the
            orders.append(("bid" if z > 0 else "ask", inf_size))     # coming price move
        for side, m in orders:
            book = _fresh_book(B, levels, bg_depth, bid_live, ask_live)
            for f in book.add_market(side, int(m), "noise"):
                if f.resting_owner != "MM":
                    continue
                px = f.price * tick
                if f.resting_side == "bid":
                    cash -= px * f.qty; q += f.qty; edge += (S - px) * f.qty; bid_live = None
                else:
                    cash += px * f.qty; q -= f.qty; edge += (px - S) * f.qty; ask_live = None
                n_fills += f.qty
        if record:
            for key, val in zip(keys, (i * dt, S, bid_i * tick, ask_i * tick, q, cash + q * S,
                                       true_sigma, float(estimator.sigma))):
                path[key].append(val)
        ds = true_sigma * math.sqrt(dt) * z
        inv_pnl += q * ds
        S += ds
        estimator.update(ds, dt)
        if market:
            market.step(rng)                    # drawn last, so with regime=None the random stream is unchanged

    pnl = cash + q * S
    assert abs(pnl - (edge + inv_pnl)) < 1e-6
    res = dict(pnl=pnl, q=q, edge=edge, inv_pnl=inv_pnl, n_fills=n_fills)
    if record:
        res["path"] = {key: np.array(v) for key, v in path.items()}
    return res


def simulate_level2(strategy, n_runs=100, seed=0, T=1.0, n_steps=DEFAULT_STEPS, s0=100.0, sigma=2.0,
                    tick=0.1, bg_depth=15, mean_mo=100.0, lam=140.0, gamma=0.1, k=1.5,
                    half_spread=None, levels=40, informed_rate=0.0, q_max=None,
                    regime=None, sigma_assumed=None, ewma_decay=0.95, record_first=False):
    """Run n_runs full order-book simulations. Run r uses RNG seed (seed + r) for EVERY strategy,
    so the random market is identical -- a 'common random numbers' comparison."""
    sigma_assumed = sigma if sigma_assumed is None else sigma_assumed
    quoter = Quoter(strategy, gamma, k, lam, T, n_steps, sigma_assumed, half_spread, q_max)
    keys = ["pnl", "q", "edge", "inv_pnl", "n_fills"]
    acc = {key: [] for key in keys}
    first_path = None
    for r in range(n_runs):
        rng = np.random.default_rng(seed + r)
        res = _run_level2_once(quoter, rng, T, n_steps, s0, sigma, tick, bg_depth, mean_mo, lam, levels,
                               informed_rate, q_max, regime, sigma_assumed, ewma_decay, record_first and r == 0)
        for key in keys:
            acc[key].append(res[key])
        if record_first and r == 0:
            first_path = res["path"]
    out = {key: np.array(v) for key, v in acc.items()}
    if first_path is not None:
        out["path"] = first_path
    return out


def measure_fill_rate(dist_ticks, n_steps=4000, dt=0.005, tick=0.1, bg_depth=15, mean_mo=100.0,
                      lam=140.0, seed=1):
    """Empirically measure how often a 1-share ask placed `dist_ticks` above the background mid
    is filled by buy market orders. Returns (fill rate per unit time, fraction of steps with a fill)."""
    rng = np.random.default_rng(seed + dist_ticks)
    filled = 0
    for _ in range(n_steps):
        hit = False
        for m in np.ceil(rng.exponential(mean_mo, rng.poisson(lam * dt))).astype(int):
            book = _fresh_book(0, dist_ticks + 6, bg_depth, None, dist_ticks)
            if any(f.resting_owner == "MM" for f in book.add_market("bid", int(m), "noise")):
                hit = True
        filled += hit
    frac = filled / n_steps
    return -math.log(1 - frac) / dt, frac
