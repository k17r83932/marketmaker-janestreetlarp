"""metrics.py -- summary numbers for a batch of simulated days."""
import numpy as np


def certainty_equivalent(pnl, gamma):
    """The sure daily profit a risk-averse market maker (risk aversion gamma) would swap for this
    uncertain profit:  CE = -(1/gamma) * ln E[exp(-gamma * PnL)].  Higher is better; it equals the
    average profit minus a penalty for risk. No assumption that profits are normally distributed."""
    pnl = np.asarray(pnl, float)
    m = pnl.mean()
    return m - np.log(np.mean(np.exp(-gamma * (pnl - m)))) / gamma


def summarize(result, gamma):
    """Headline statistics of a result dict returned by simulate_level1 / simulate_level2."""
    pnl = np.asarray(result["pnl"], float)
    return dict(mean=pnl.mean(), std=pnl.std(ddof=1), p5=np.percentile(pnl, 5), worst=pnl.min(),
                mean_abs_q=np.abs(result["q"]).mean(), fills=np.mean(result["n_fills"]),
                score=certainty_equivalent(pnl, gamma))
