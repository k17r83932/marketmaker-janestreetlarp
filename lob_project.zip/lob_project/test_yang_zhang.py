"""test_yang_zhang.py -- tests for the Yang-Zhang volatility estimator (run:  python test_yang_zhang.py)"""
import numpy as np
from volatility import close_to_close, yang_zhang

SIGMA_INTRADAY, SIGMA_GAP, STEPS = 0.020, 0.010, 390          # log-return volatilities per day


def simulate_bars(n_days, rng, drift=0.0):
    """Daily OHLC bars from a fine intraday geometric random walk, with overnight gaps."""
    o, h, l, c = [], [], [], []
    price = 100.0
    for _ in range(n_days):
        price *= np.exp(rng.normal(0, SIGMA_GAP))                          # overnight gap
        steps = rng.normal(drift / STEPS, SIGMA_INTRADAY / np.sqrt(STEPS), STEPS)
        path = price * np.exp(np.concatenate([[0.0], np.cumsum(steps)]))
        o.append(path[0]); h.append(path.max()); l.append(path.min()); c.append(path[-1])
        price = path[-1]
    return np.array(o), np.array(h), np.array(l), np.array(c)


def test_recovers_true_volatility_including_overnight_gaps():
    true_total = np.sqrt(SIGMA_INTRADAY ** 2 + SIGMA_GAP ** 2)
    rng = np.random.default_rng(0)
    estimates = [yang_zhang(*simulate_bars(40, rng), window=30)[-1] for _ in range(200)]
    assert abs(np.mean(estimates) - true_total) / true_total < 0.05


def test_more_efficient_than_close_to_close():
    rng = np.random.default_rng(1)
    yz, cc = [], []
    for _ in range(300):
        o, h, l, c = simulate_bars(40, rng)
        yz.append(yang_zhang(o, h, l, c, window=20)[-1])
        cc.append(close_to_close(c, window=20)[-1])
    assert np.std(yz) < 0.85 * np.std(cc)                  # tighter spread of estimates


def test_unbiased_when_prices_drift():
    rng = np.random.default_rng(2)
    true_total = np.sqrt(SIGMA_INTRADAY ** 2 + SIGMA_GAP ** 2)
    estimates = [yang_zhang(*simulate_bars(40, rng, drift=0.03), window=30)[-1] for _ in range(150)]
    assert abs(np.mean(estimates) - true_total) / true_total < 0.07


def test_warm_up_is_nan_and_formula_matches_by_hand():
    o = np.array([100, 101, 100.5, 102.0]); c = np.array([101, 100.5, 102, 101.5])
    h = np.array([101.5, 101.4, 102.5, 102.4]); l = np.array([99.8, 100.1, 100.4, 101.0])
    out = yang_zhang(o, h, l, c, window=2)
    assert np.isnan(out[:2]).all() and np.isfinite(out[2:]).all()
    t, w = 2, 2
    ov = np.log(o[1:] / c[:-1])[t - w:t]
    oc = np.log(c / o)[t - w + 1:t + 1]
    rs = (np.log(h / c) * np.log(h / o) + np.log(l / c) * np.log(l / o))[t - w + 1:t + 1]
    k = 0.34 / (1.34 + (w + 1) / (w - 1))
    expected = np.sqrt(np.var(ov, ddof=1) + k * np.var(oc, ddof=1) + (1 - k) * rs.mean())
    assert abs(out[t] - expected) < 1e-12


def test_intraday_only_option_ignores_overnight_gaps():
    rng = np.random.default_rng(4)
    estimates = [yang_zhang(*simulate_bars(40, rng), window=30, overnight=False)[-1] for _ in range(200)]
    assert abs(np.mean(estimates) - SIGMA_INTRADAY) / SIGMA_INTRADAY < 0.06      # recovers the intraday part only


def test_scale_invariance_of_price_level():
    rng = np.random.default_rng(3)
    o, h, l, c = simulate_bars(30, rng)
    a = yang_zhang(o, h, l, c, 10)
    b = yang_zhang(5 * o, 5 * h, 5 * l, 5 * c, 10)          # relative returns do not depend on the price level
    assert np.allclose(a[10:], b[10:])


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print("PASS", t.__name__)
    print(f"All {len(tests)} tests passed.")
