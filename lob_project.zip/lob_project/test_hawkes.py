"""test_hawkes.py -- tests for the Hawkes market generator (run:  python test_hawkes.py)"""
import numpy as np
from hawkes import HawkesMarketParams, _seasonality, diagnostics, generate_market


def test_same_seed_same_market_and_different_seed_differs():
    a, b, c = generate_market(5, seed=1), generate_market(5, seed=1), generate_market(5, seed=2)
    assert all(np.array_equal(x.mid, y.mid) and np.array_equal(x.ev_size, y.ev_size) for x, y in zip(a.days, b.days))
    assert not np.array_equal(a.days[0].mid, c.days[0].mid)


def test_unstable_parameters_are_rejected():
    for bad in (1.0, 1.3):
        try:
            HawkesMarketParams(branching=bad)
        except ValueError:
            continue
        raise AssertionError("branching >= 1 should be rejected")


def test_mean_arrival_rate_is_close_to_target():
    h = generate_market(150, seed=5)
    ratio = np.mean([len(d.ev_side) / (280 * d.activity) for d in h.days])   # 140 per side, two sides, per unit of activity
    assert 0.93 < ratio < 1.07


def test_orders_are_clustered_but_poisson_limit_is_not():
    hawkes = diagnostics(generate_market(150, seed=7))
    poisson = diagnostics(generate_market(150, seed=7, params=HawkesMarketParams(branching=0.0)))
    assert hawkes["fano_factor"] > 1.2
    assert 0.9 < poisson["fano_factor"] < 1.1


def test_order_signs_persist_only_with_excitation():
    hawkes = diagnostics(generate_market(150, seed=8))
    poisson = diagnostics(generate_market(150, seed=8, params=HawkesMarketParams(branching=0.0)))
    assert hawkes["sign_autocorrelation"] > 0.05
    assert abs(poisson["sign_autocorrelation"]) < 0.03


def test_volatility_clusters():
    """Busy days follow busy days and intraday activity is U-shaped, so absolute returns are autocorrelated."""
    d = diagnostics(generate_market(200, seed=9))
    assert d["abs_return_autocorrelation"] > 0.10                  # iid returns would give about 0
    assert d["daily_vol_dispersion"] > 0.15                        # some days are clearly busier than others


def test_prices_are_efficient_enough():
    """Price should be close to a random walk over a day: variance ratio near 1 (not strongly trending or reverting)."""
    h = generate_market(250, seed=11)
    step_var = np.var(np.concatenate([np.diff(d.mid) for d in h.days]))
    day_var = np.var([d.mid[-1] - d.mid[0] for d in h.days])
    assert 0.7 < day_var / (200 * step_var) < 1.3


def test_bars_and_tape_are_consistent():
    h = generate_market(20, seed=12)
    for d, o, hi, lo, c in zip(h.days, *(h.ohlc[k] for k in ("open", "high", "low", "close"))):
        assert lo <= min(o, c) and hi >= max(o, c)
        assert d.ev_ptr[0] == 0 and d.ev_ptr[-1] == len(d.ev_side) == len(d.ev_size)
        assert set(np.unique(d.ev_side)) <= {-1, 1} and d.ev_size.min() >= 1
        assert len(d.mid) == h.params.n_steps + 1 and d.mid.min() >= 1.0


def test_seasonality_averages_one_and_is_u_shaped():
    s = _seasonality(0.8)
    assert abs(s.mean() - 1) < 1e-9 and s[0] > s[len(s) // 2] and s[-1] > s[len(s) // 2]


def test_order_sizes_have_the_requested_mean_and_a_heavy_tail():
    h = generate_market(100, seed=13)
    sizes = np.concatenate([d.ev_size for d in h.days])
    assert abs(sizes.mean() - 100) < 8
    assert np.percentile(sizes, 99) > 4 * np.median(sizes) * 0.9    # heavier tail than exponential's ~6.6x at 99%? (log-normal)


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print("PASS", t.__name__)
    print(f"All {len(tests)} tests passed.")
