"""test_optimal.py -- tests for the exact quote table (run:  python test_optimal.py)"""
import numpy as np
from optimal import NO_QUOTE, ExactQuoteTable

GAMMA, K, A, T, STEPS = 0.1, 1.5, 140.0, 1.0, 100
TABLE = ExactQuoteTable(GAMMA, K, A, T, STEPS, q_max=10, sigma_grid=np.geomspace(0.5, 8, 12))


def test_end_of_day_distance_is_the_markup():
    """With no time left there is no inventory risk: both quotes sit at L = ln(1+gamma/k)/gamma."""
    bid, ask = TABLE.distances(STEPS, 0, 2.0)
    assert abs(float(bid) - TABLE.L) < 1e-9 and abs(float(ask) - TABLE.L) < 1e-9


def test_symmetry_between_long_and_short():
    for q in (1, 4, 9):
        bid_long, ask_long = TABLE.distances(0, q, 2.0)
        bid_short, ask_short = TABLE.distances(0, -q, 2.0)
        assert abs(float(bid_long) - float(ask_short)) < 1e-6
        assert abs(float(ask_long) - float(bid_short)) < 1e-6


def test_more_inventory_means_less_eager_to_buy():
    bids = [float(TABLE.distances(0, q, 2.0)[0]) for q in range(-9, 9)]
    asks = [float(TABLE.distances(0, q, 2.0)[1]) for q in range(-9, 9)]
    assert all(b2 > b1 for b1, b2 in zip(bids, bids[1:]))      # bid moves away as q grows
    assert all(a2 < a1 for a1, a2 in zip(asks, asks[1:]))      # ask moves in as q grows


def test_inventory_limits_switch_a_side_off():
    assert float(TABLE.distances(0, 10, 2.0)[0]) == NO_QUOTE   # long at the limit: no more buying
    assert float(TABLE.distances(0, -10, 2.0)[1]) == NO_QUOTE  # short at the limit: no more selling


def test_flat_inventory_is_symmetric_and_widens_with_volatility():
    b2, a2 = TABLE.distances(0, 0, 1.0)
    b6, a6 = TABLE.distances(0, 0, 6.0)
    assert abs(float(b2) - float(a2)) < 1e-9
    assert float(b6) > float(b2)                               # higher volatility -> wider quotes


def test_vectorised_lookup_matches_scalar_lookup():
    qs, sigmas = np.array([-3, 0, 5]), np.array([1.0, 2.5, 4.0])
    bids, asks = TABLE.distances(10, qs, sigmas)
    for i in range(3):
        b, a = TABLE.distances(10, int(qs[i]), float(sigmas[i]))
        assert abs(bids[i] - float(b)) < 1e-12 and abs(asks[i] - float(a)) < 1e-12


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print("PASS", t.__name__)
    print(f"All {len(tests)} tests passed.")
