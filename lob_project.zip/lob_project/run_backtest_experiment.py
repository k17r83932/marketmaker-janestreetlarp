"""run_backtest_experiment.py -- test the market maker against several independent Hawkes markets.

For each of N_HISTORIES synthetic markets: calibrate on the first 40 days, trade the next 120 days with
every strategy, build the tear sheet. Then compare the strategies across histories.
Writes results_backtest.json.
"""
import json

import numpy as np

from backtest import BacktestConfig, run_backtest
from hawkes import diagnostics, generate_market
from tearsheet import tear_sheets

N_HISTORIES, DAYS = 8, 160
cfg = BacktestConfig(train_days=40)
names = cfg.strategies
rows = {n: [] for n in names}
pnl_days = {n: [] for n in names}
market_facts, calibrations = [], []

for h in range(N_HISTORIES):
    history = generate_market(DAYS, seed=100 + h)
    result = run_backtest(history, cfg)
    sheets = tear_sheets(result, sortino_target="half_mean")
    market_facts.append(diagnostics(history))
    calibrations.append({k: result["calibration"][k] for k in ("A", "k", "r2")})
    for n in names:
        ts = sheets[n]
        rows[n].append({**ts["summary"], **{f"dec_{k}": v["per_day"] for k, v in ts["decomposition"].items()},
                        **{f"inv_{k}": v for k, v in ts["inventory"].items()}})
        pnl_days[n].append(result["strategies"][n]["pnl"])

def mean_se(values):
    v = np.array(values, float)
    return float(v.mean()), float(v.std(ddof=1) / np.sqrt(len(v)))

out = {"n_histories": N_HISTORIES, "days_tested": DAYS - cfg.train_days, "strategies": {}, "paired": {}}
for n in names:
    keys = ("mean_daily", "std_daily", "sharpe", "sortino", "max_drawdown", "worst_day", "win_rate", "fills_per_day",
            "dec_spread", "dec_adverse_selection", "dec_inventory_carry", "inv_mean_abs", "inv_peak_abs", "inv_pct_flat", "downside_days")
    out["strategies"][n] = {k: dict(zip(("mean", "se"), mean_se([r[k] for r in rows[n]]))) for k in keys}
for a, b in (("vol_aware", "exact"), ("vol_aware", "as"), ("exact", "as"), ("as", "sym")):
    d_mean = [np.mean(x - y) for x, y in zip(pnl_days[a], pnl_days[b])]
    d_sharpe = [ra["sharpe"] - rb["sharpe"] for ra, rb in zip(rows[a], rows[b])]
    out["paired"][f"{a}_minus_{b}"] = {"mean_daily_pnl": dict(zip(("mean", "se"), mean_se(d_mean))),
                                       "sharpe": dict(zip(("mean", "se"), mean_se(d_sharpe)))}
out["market"] = {k: mean_se([m[k] for m in market_facts])[0] for k in market_facts[0]}
out["calibration"] = {k: mean_se([c[k] for c in calibrations])[0] for k in ("A", "k", "r2")}
json.dump(out, open("results_backtest.json", "w"), indent=1)

print("market:", {k: round(v, 3) for k, v in out["market"].items()})
print("calibration:", {k: round(v, 3) for k, v in out["calibration"].items()})
print(f"{'strategy':10s} {'PnL/day':>9s} {'sd':>6s} {'Sharpe':>7s} {'Sortino':>8s} {'maxDD':>7s} {'spread':>7s} {'adverse':>8s} {'carry':>7s} {'|q|':>5s} {'fills':>6s}")
for n in names:
    s = out["strategies"][n]
    print(f"{n:10s} {s['mean_daily']['mean']:9.2f} {s['std_daily']['mean']:6.2f} {s['sharpe']['mean']:7.1f} {s['sortino']['mean']:8.1f} {s['max_drawdown']['mean']:7.1f} "
          f"{s['dec_spread']['mean']:7.1f} {s['dec_adverse_selection']['mean']:8.2f} {s['dec_inventory_carry']['mean']:7.2f} {s['inv_mean_abs']['mean']:5.2f} {s['fills_per_day']['mean']:6.1f}")
for k, v in out["paired"].items():
    print(f"{k:22s} PnL/day diff {v['mean_daily_pnl']['mean']:+.2f} (se {v['mean_daily_pnl']['se']:.2f}) | Sharpe diff {v['sharpe']['mean']:+.1f} (se {v['sharpe']['se']:.1f})")
